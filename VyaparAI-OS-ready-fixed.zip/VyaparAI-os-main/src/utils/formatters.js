// Indian Currency, Date, and Metric Formatters

export const formatINR = (amount, options = {}) => {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  
  const { compact = false } = options;
  const num = Number(amount);
  const isNegative = num < 0;
  const absNum = Math.abs(num);

  if (compact) {
    if (absNum >= 10000000) {
      // Crores
      return `${isNegative ? '-' : ''}₹${(absNum / 10000000).toFixed(2)} Cr`;
    }
    if (absNum >= 100000) {
      // Lakhs
      return `${isNegative ? '-' : ''}₹${(absNum / 100000).toFixed(2)} L`;
    }
    if (absNum >= 1000) {
      // Thousands
      return `${isNegative ? '-' : ''}₹${(absNum / 1000).toFixed(1)}k`;
    }
    return `${isNegative ? '-' : ''}₹${Math.round(absNum)}`;
  }

  // Full Indian number formatting (e.g. 12,34,567)
  const parts = absNum.toFixed(0).split('.');
  let lastThree = parts[0].substring(parts[0].length - 3);
  const otherNumbers = parts[0].substring(0, parts[0].length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;

  return `${isNegative ? '-' : ''}₹${formatted}`;
};

export const formatPercent = (val) => {
  if (val === undefined || val === null || isNaN(val)) return '0%';
  return `${Number(val) >= 0 ? '+' : ''}${Number(val).toFixed(1)}%`;
};

export const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
};
