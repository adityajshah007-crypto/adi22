// Smart Excel/CSV Parsing & Auto-Mapping Engine for Indian SMBs
import * as XLSX from 'xlsx';

// Fuzzy header dictionary mapping common Indian and global accounting column names
const COLUMN_MAPPINGS = {
  date: ['date', 'bill_date', 'billdate', 'order_date', 'tarikh', 'invoice_date', 'txn_date'],
  customer: ['customer', 'customer_name', 'party', 'party_name', 'grahak', 'client', 'buyer', 'name'],
  item: ['item', 'item_name', 'product', 'product_name', 'description', 'sku', 'goods', 'maal'],
  category: ['category', 'group', 'type', 'dept', 'classification'],
  qty: ['qty', 'quantity', 'units', 'pcs', 'count', 'nag', 'packet', 'kg', 'nos'],
  costPrice: ['cost', 'cost_price', 'cp', 'purchase_price', 'purchase_rate', 'kharid_rate', 'kharid_bhav'],
  sellingPrice: ['price', 'selling_price', 'sp', 'unit_price', 'rate', 'bikri_rate', 'bikri_bhav', 'mrp'],
  total: ['total', 'amount', 'net_amount', 'bill_amount', 'value', 'subtotal'],
  profit: ['profit', 'margin', 'net_margin', 'munafa', 'gain'],
  paymentMode: ['payment_mode', 'mode', 'payment_type', 'method', 'payment', 'pay_type'],
  status: ['status', 'payment_status', 'bill_status', 'condition']
};

export const normalizeKey = (key) => {
  return String(key || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_');
};

export const detectColumnMapping = (headers) => {
  const mapping = {};
  const normalizedHeaders = headers.map(h => ({ original: h, normalized: normalizeKey(h) }));

  for (const [standardKey, aliases] of Object.entries(COLUMN_MAPPINGS)) {
    for (const h of normalizedHeaders) {
      if (aliases.includes(h.normalized) || aliases.some(alias => h.normalized.includes(alias))) {
        mapping[standardKey] = h.original;
        break;
      }
    }
  }

  return mapping;
};

export const parseSpreadsheetFile = async (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        
        // Grab first sheet
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        // Parse into JSON
        const rawRows = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        
        if (!rawRows || rawRows.length === 0) {
          throw new Error('Spreadsheet appears to be empty.');
        }

        const headers = Object.keys(rawRows[0]);
        const detectedMapping = detectColumnMapping(headers);

        // Transform rows to standard schema
        const normalizedTransactions = rawRows.map((row, index) => {
          const item = row[detectedMapping.item] || `Item #${index + 1}`;
          const qty = Number(row[detectedMapping.qty]) || 1;
          const sellingPrice = Number(row[detectedMapping.sellingPrice]) || Number(row[detectedMapping.total]) / qty || 0;
          const costPrice = Number(row[detectedMapping.costPrice]) || Math.round(sellingPrice * 0.75); // fallback 25% margin
          const total = Number(row[detectedMapping.total]) || (qty * sellingPrice);
          const profit = Number(row[detectedMapping.profit]) || (total - (costPrice * qty));
          
          let paymentMode = row[detectedMapping.paymentMode] || 'UPI';
          // Clean common Indian payment modes
          const modeLower = String(paymentMode).toLowerCase();
          if (modeLower.includes('upi') || modeLower.includes('gpay') || modeLower.includes('phonepe') || modeLower.includes('paytm')) {
            paymentMode = 'UPI';
          } else if (modeLower.includes('cash') || modeLower.includes('rokad')) {
            paymentMode = 'Cash (Rokad)';
          } else if (modeLower.includes('credit') || modeLower.includes('udhar') || modeLower.includes('khata') || modeLower.includes('pending')) {
            paymentMode = 'Udhar / Credit';
          } else if (modeLower.includes('bank') || modeLower.includes('neft') || modeLower.includes('rtgs')) {
            paymentMode = 'Bank Transfer';
          }

          const customer = row[detectedMapping.customer] || 'Counter Walk-in';
          const date = row[detectedMapping.date] ? String(row[detectedMapping.date]).split('T')[0] : new Date().toISOString().split('T')[0];
          const status = row[detectedMapping.status] || (paymentMode === 'Udhar / Credit' ? 'Pending' : 'Paid');

          return {
            id: `TXN-IMP-${index + 101}`,
            date,
            customer,
            item,
            category: row[detectedMapping.category] || 'General Goods',
            qty,
            costPrice,
            unitPrice: sellingPrice,
            total,
            profit,
            paymentMode,
            status
          };
        });

        // Auto-generate inventory from transactions if not present
        const inventoryMap = {};
        normalizedTransactions.forEach((txn) => {
          if (!inventoryMap[txn.item]) {
            inventoryMap[txn.item] = {
              id: `INV-IMP-${Object.keys(inventoryMap).length + 101}`,
              name: txn.item,
              category: txn.category || 'General Store',
              stock: Math.floor(Math.random() * 25) + 5,
              minStock: 15,
              costPrice: txn.costPrice,
              sellingPrice: txn.unitPrice,
              supplier: 'Local Mandi / Direct Distributor',
              leadTimeDays: 3,
              lastRestocked: txn.date,
              salesVelocity: 'High'
            };
          }
        });

        // Auto-generate customer balances from pending Udhar transactions
        const customerMap = {};
        normalizedTransactions.forEach((txn) => {
          if (txn.status === 'Pending' || txn.paymentMode === 'Udhar / Credit') {
            if (!customerMap[txn.customer]) {
              customerMap[txn.customer] = {
                id: `CUST-IMP-${Object.keys(customerMap).length + 101}`,
                name: txn.customer,
                phone: `+91 ${98000 + Math.floor(Math.random() * 1000)} ${10000 + Math.floor(Math.random() * 90000)}`,
                pendingAmount: 0,
                overdueDays: Math.floor(Math.random() * 45) + 3,
                creditLimit: 25000,
                trustScore: 'Moderate',
                notes: 'Imported from uploaded ledger.'
              };
            }
            customerMap[txn.customer].pendingAmount += txn.total;
          }
        });

        resolve({
          fileName: file.name,
          headers,
          detectedMapping,
          totalRows: normalizedTransactions.length,
          transactions: normalizedTransactions,
          inventory: Object.values(inventoryMap),
          customers: Object.values(customerMap)
        });
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
};

// Generates and downloads a clean sample CSV template for businesses
export const downloadSampleTemplate = () => {
  const sampleData = [
    {
      Date: '2026-09-01',
      Customer: 'Sharma General Store',
      Item: 'Basmati Rice Premium 10kg',
      Category: 'Grains & Staples',
      Qty: 5,
      Cost_Price: 900,
      Selling_Price: 1100,
      Total_Amount: 5500,
      Payment_Mode: 'UPI',
      Status: 'Paid'
    },
    {
      Date: '2026-09-02',
      Customer: 'Gupta Sweets',
      Item: 'Sunflower Oil 5L Can',
      Category: 'Edible Oils',
      Qty: 8,
      Cost_Price: 550,
      Selling_Price: 650,
      Total_Amount: 5200,
      Payment_Mode: 'Udhar / Credit',
      Status: 'Pending'
    },
    {
      Date: '2026-09-03',
      Customer: 'Verma PG Hostel',
      Item: 'Tata Salt 1kg',
      Category: 'Spices & Salts',
      Qty: 20,
      Cost_Price: 20,
      Selling_Price: 28,
      Total_Amount: 560,
      Payment_Mode: 'Cash',
      Status: 'Paid'
    },
    {
      Date: '2026-09-04',
      Customer: 'Anil Tea Stall',
      Item: 'Chai Masala 200g',
      Category: 'Spices',
      Qty: 4,
      Cost_Price: 60,
      Selling_Price: 85,
      Total_Amount: 340,
      Payment_Mode: 'UPI',
      Status: 'Paid'
    }
  ];

  const ws = XLSX.utils.json_to_sheet(sampleData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sales_Template');
  XLSX.writeFile(wb, 'VyaparAI_Business_Template.xlsx');
};
