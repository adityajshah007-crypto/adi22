import React, { useState } from 'react';
import { 
  Store, 
  CreditCard, 
  Check, 
  ArrowUpRight,
  Calculator,
} from 'lucide-react';
import { useDataStore } from '../context/DataStore';
import { formatINR } from '../utils/formatters';

export const SettingsView = ({ onOpenSubscriptionModal, onShowToast }) => {
  const { businessProfile, setBusinessProfile } = useDataStore();

  const [activeTab, setActiveTab] = useState('store'); // 'store' | 'billing' | 'roi'
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: businessProfile.name || '',
    owner: businessProfile.owner || '',
    upiId: businessProfile.upiId || businessProfile.upi_id || '',
    gstin: businessProfile.gstin || '',
    location: businessProfile.location || '',
    type: businessProfile.type || businessProfile.business_type || 'Supermart & Wholesale FMCG'
  });

  // ROI Calculator State
  const [monthlyRevenue, setMonthlyRevenue] = useState(1500000); // 15 Lakhs
  const [trappedUdhar, setTrappedUdhar] = useState(250000); // 2.5 Lakhs

  // Derived ROI Metrics
  const estimatedRecoveredPerYear = Math.round(trappedUdhar * 0.78); // 78% faster recovery
  const _estimatedHoursSavedPerYear = 240; // 20 hrs/month
  const annualSubCost = 11988; // ₹999 x 12
  const netRoiMultiplier = ((estimatedRecoveredPerYear / annualSubCost)).toFixed(1);

  const handleSaveProfile = (e) => {
    e.preventDefault();
    setBusinessProfile(prev => ({
      ...prev,
      ...formData,
      upi_id: formData.upiId,
      business_type: formData.type
    }));
    setSavedSuccess(true);
    if (onShowToast) onShowToast({ message: 'Store profile & GST credentials updated!', type: 'success' });
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="page-container" style={{ maxWidth: '1000px', margin: '0 auto' }}>
      {/* Page Header */}
      <div className="page-header" style={{ marginBottom: '20px' }}>
        <div>
          <h1 className="page-title">Enterprise Business Settings</h1>
          <p className="page-subtitle">Configure store identity, commercial SaaS subscription, and estimate platform ROI.</p>
        </div>
      </div>

      {/* Settings Navigation Tabs */}
      <div style={{
        display: 'flex',
        gap: '8px',
        borderBottom: '1px solid var(--border-color)',
        marginBottom: '24px'
      }}>
        <button
          onClick={() => setActiveTab('store')}
          style={{
            padding: '10px 16px',
            border: 'none',
            background: 'none',
            borderBottom: activeTab === 'store' ? '2px solid var(--brand-saffron)' : '2px solid transparent',
            color: activeTab === 'store' ? 'var(--brand-saffron)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'store' ? 700 : 500,
            fontSize: '13.5px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <Store size={16} />
          <span>Store & GST Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('billing')}
          style={{
            padding: '10px 16px',
            border: 'none',
            background: 'none',
            borderBottom: activeTab === 'billing' ? '2px solid var(--brand-saffron)' : '2px solid transparent',
            color: activeTab === 'billing' ? 'var(--brand-saffron)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'billing' ? 700 : 500,
            fontSize: '13.5px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <CreditCard size={16} />
          <span>Plan & Commercial Billing</span>
        </button>

        <button
          onClick={() => setActiveTab('roi')}
          style={{
            padding: '10px 16px',
            border: 'none',
            background: 'none',
            borderBottom: activeTab === 'roi' ? '2px solid var(--brand-saffron)' : '2px solid transparent',
            color: activeTab === 'roi' ? 'var(--brand-saffron)' : 'var(--text-secondary)',
            fontWeight: activeTab === 'roi' ? 700 : 500,
            fontSize: '13.5px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          <Calculator size={16} />
          <span>Vyapar ROI Calculator</span>
        </button>
      </div>

      {/* ===================== TAB 1: STORE PROFILE ===================== */}
      {activeTab === 'store' && (
        <div className="dashboard-card" style={{ maxWidth: '720px' }}>
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading">Store & Banking Details</h2>
              <p className="card-subheading">Automatically applied to WhatsApp billing reminders, invoices, and purchase orders</p>
            </div>
          </div>

          {savedSuccess && (
            <div style={{
              padding: '10px 14px',
              borderRadius: '8px',
              backgroundColor: 'var(--badge-bg-green)',
              color: 'var(--badge-text-green)',
              fontSize: '13px',
              fontWeight: 600,
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <Check size={16} />
              <span>Business settings updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Business / Store Name
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Proprietor / Owner Name
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  required
                  value={formData.owner}
                  onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  UPI ID (VPA for Auto-Khata QR)
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  placeholder="storename@upi"
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  GSTIN Identification
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  placeholder="07AAAAA0000A1Z5"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  City / Mandi Location
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Industry Category
                </label>
                <input 
                  type="text" 
                  className="ai-input" 
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  style={{ width: '100%' }} 
                />
              </div>
            </div>

            <div style={{ marginTop: '8px' }}>
              <button type="submit" className="btn-primary" style={{ padding: '9px 18px' }}>
                <span>Save Business Profile</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ===================== TAB 2: BILLING & SUBSCRIPTION ===================== */}
      {activeTab === 'billing' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: '780px' }}>
          {/* Active Plan Card */}
          <div style={{
            padding: '24px',
            borderRadius: '12px',
            backgroundColor: 'var(--bg-card)',
            border: '2px solid var(--brand-saffron)',
            boxShadow: 'var(--card-shadow)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px', marginBottom: '16px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                  <h3 style={{ fontSize: '18px', fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>
                    Vyapar Pro Growth (Commercial Pilot)
                  </h3>
                  <span style={{
                    fontSize: '11px',
                    fontWeight: 700,
                    padding: '2px 8px',
                    borderRadius: '10px',
                    backgroundColor: 'var(--badge-bg-green)',
                    color: 'var(--brand-green)'
                  }}>
                    ACTIVE TRIAL
                  </span>
                </div>
                <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                  14-Day Full Access Pilot • Renews at ₹999/month
                </div>
              </div>

              <button
                onClick={() => onOpenSubscriptionModal && onOpenSubscriptionModal()}
                className="btn-primary"
                style={{ padding: '8px 16px', fontSize: '12.5px' }}
              >
                <span>Manage / Change Plan</span>
                <ArrowUpRight size={15} />
              </button>
            </div>

            {/* Usage Meters */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', paddingTop: '16px', borderTop: '1px solid var(--border-color)' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>WhatsApp Credits</span>
                  <span style={{ fontWeight: 700 }}>42 / 500</span>
                </div>
                <div style={{ width: '100%', height: '6px', backgroundColor: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ width: '8.4%', height: '100%', backgroundColor: 'var(--brand-green)' }}></div>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>AI Co-Pilot Queries</span>
                  <span style={{ fontWeight: 700 }}>18 / 100</span>
                </div>
                <div style={{ width: '100%', height: '6px', backgroundColor: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ width: '18%', height: '100%', backgroundColor: 'var(--brand-blue)' }}></div>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', marginBottom: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Monthly GMV Volume</span>
                  <span style={{ fontWeight: 700 }}>₹24.8L / ₹50L</span>
                </div>
                <div style={{ width: '100%', height: '6px', backgroundColor: 'var(--border-color)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ width: '49.6%', height: '100%', backgroundColor: 'var(--brand-saffron)' }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Invoice History Mock */}
          <div className="dashboard-card">
            <div className="card-title-bar">
              <h2 className="card-heading">Subscription Invoices & GST Receipts</h2>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', backgroundColor: 'var(--bg-card-subtle)', borderRadius: '8px', fontSize: '12.5px' }}>
                <div>
                  <div style={{ fontWeight: 600 }}>Vyapar Pro Pilot Initiation</div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>12 Sep 2026 • Receipt #VY-2026-091</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span style={{ fontWeight: 700, color: 'var(--brand-green)' }}>₹0 (Trial)</span>
                  <span style={{ color: 'var(--brand-blue)', cursor: 'pointer', fontWeight: 600, fontSize: '12px' }}>Download GST Tax Invoice</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 3: ROI CALCULATOR ===================== */}
      {activeTab === 'roi' && (
        <div style={{ maxWidth: '850px' }}>
          <div className="dashboard-card" style={{ marginBottom: '20px' }}>
            <div className="card-title-bar">
              <div>
                <h2 className="card-heading">Merchant Return on Investment (ROI) Calculator</h2>
                <p className="card-subheading">Demonstrate to store owners and investors how VyaparAI OS pays for itself within weeks</p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '24px', alignItems: 'center' }}>
              {/* Sliders Side */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>
                      Monthly Store Revenue (Turnover)
                    </label>
                    <span style={{ fontWeight: 700, color: 'var(--brand-saffron)' }}>
                      {formatINR(monthlyRevenue)}
                    </span>
                  </div>
                  <input 
                    type="range" 
                    min="500000" 
                    max="10000000" 
                    step="250000"
                    value={monthlyRevenue}
                    onChange={(e) => setMonthlyRevenue(Number(e.target.value))}
                    style={{ width: '100%', accentColor: 'var(--brand-saffron)' }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--text-muted)' }}>
                    <span>₹5 Lakh</span>
                    <span>₹50 Lakh</span>
                    <span>₹1 Crore</span>
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <label style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>
                      Average Uncollected Customer Udhar Trapped
                    </label>
                    <span style={{ fontWeight: 700, color: 'var(--brand-green)' }}>
                      {formatINR(trappedUdhar)}
                    </span>
                  </div>
                  <input 
                    type="range" 
                    min="50000" 
                    max="2000000" 
                    step="50000"
                    value={trappedUdhar}
                    onChange={(e) => setTrappedUdhar(Number(e.target.value))}
                    style={{ width: '100%', accentColor: 'var(--brand-green)' }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--text-muted)' }}>
                    <span>₹50,000</span>
                    <span>₹10 Lakh</span>
                    <span>₹20 Lakh</span>
                  </div>
                </div>
              </div>

              {/* Computed Value Box */}
              <div style={{
                padding: '24px',
                borderRadius: '12px',
                backgroundColor: 'rgba(0, 229, 255, 0.08)',
                border: '1px solid rgba(0, 229, 255, 0.3)',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px'
              }}>
                <div>
                  <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--brand-saffron)', textTransform: 'uppercase' }}>
                    Annual Net Return
                  </div>
                  <div style={{ fontSize: '36px', fontWeight: 900, color: 'var(--text-primary)', margin: '4px 0' }}>
                    {netRoiMultiplier}x ROI
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                    Recovers {formatINR(estimatedRecoveredPerYear)} in delayed credit annually
                  </div>
                </div>

                <div style={{ paddingTop: '12px', borderTop: '1px solid rgba(0, 229, 255, 0.2)', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Pro Subscription (Annual):</span>
                    <span style={{ fontWeight: 600 }}>₹11,988/yr</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Working Hours Reclaimed:</span>
                    <span style={{ fontWeight: 600, color: 'var(--brand-green)' }}>240 Hours/yr</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Payback Break-Even:</span>
                    <span style={{ fontWeight: 700, color: 'var(--brand-saffron)' }}>Day 16 of Month 1</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
