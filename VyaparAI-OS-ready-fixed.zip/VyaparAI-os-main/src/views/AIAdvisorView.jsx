import React, { useMemo } from 'react';
import { AIAdvisorView as AIAdvisorComponent } from '../components/AIAdvisorView';
import { useDataStore } from '../context/DataStore';
import { sampleBusinesses } from '../data/sampleDatasets';

export const AIAdvisorView = ({ onOpenWhatsApp, onOpenPOModal, onNavigateTab, onShowToast }) => {
  const { businessProfile, sales, inventory, customers, derivedKPIs, lowStockItems } = useDataStore();
  const fallback = sampleBusinesses[0] || {};

  // Construct dynamic live business context reflecting actual store state
  const liveBusiness = useMemo(() => {
    return {
      id: businessProfile?.id || fallback.id || 'BIZ-001',
      name: businessProfile?.name || fallback.name || 'Bharat Supermart',
      owner: businessProfile?.owner || fallback.owner || 'Rajesh Sharma',
      business_type: businessProfile?.type || fallback.business_type || 'Supermart & Wholesale FMCG',
      gstin: businessProfile?.gstin || fallback.gstin || '07AAAAA0000A1Z5',
      upiId: businessProfile?.upiId || fallback.upiId || 'bharatenterprises@upi',
      location: businessProfile?.location || fallback.location || 'Delhi, India',
      inventory: (inventory && inventory.length > 0) ? inventory.map((i, idx) => ({
        id: i.sku || `SKU-${idx + 101}`,
        name: i.product || i.name || 'General Product',
        sku: i.sku || `SKU-${idx + 101}`,
        stock: Number(i.currentStock || i.stock) || 0,
        minStock: Number(i.reorderLevel || i.minStock) || 10,
        costPrice: Number(i.costPrice) || 0,
        sellingPrice: Number(i.sellingPrice) || 0,
        category: i.category || 'General',
        supplier: i.supplier || 'Primary Distributor',
        salesVelocity: (Number(i.currentStock || i.stock) <= (Number(i.reorderLevel || i.minStock) || 10)) ? 'High (Near Depletion)' : 'Normal',
        leadTimeDays: 3
      })) : (fallback.inventory || []),
      customers: (customers && customers.length > 0) ? customers.map(c => ({
        id: c.id,
        name: c.customerName || c.name || 'Customer',
        phone: c.phone || '',
        email: c.email || '',
        pendingAmount: Number(c.amountDue || c.pendingAmount) || 0,
        totalPurchases: Number(c.totalPurchases) || 0,
        overdueDays: c.overdueDays || (Number(c.amountDue || c.pendingAmount) > 0 ? 14 : 0),
        trustScore: Number(c.amountDue || c.pendingAmount) > 20000 ? 'Needs Follow-up' : 'Good'
      })) : (fallback.customers || []),
      transactions: (sales && sales.length > 0) ? sales.map(s => {
        const total = Number(s.revenue || s.amount || s.total || ((Number(s.quantity) || 1) * (Number(s.sellingPrice) || 0))) || 0;
        const cost = Number(s.cost || ((Number(s.quantity) || 1) * (Number(s.costPrice) || 0))) || Math.round(total * 0.78);
        const profit = Number(s.profit || (total - cost)) || Math.round(total * 0.22);
        return {
          id: s.invoiceNo || s.invoiceId || s.id,
          customer: s.customerName || s.customer || 'Counter Customer',
          item: s.product || s.items || 'General Goods',
          category: s.category || 'General',
          quantity: Number(s.quantity) || 1,
          total,
          cost,
          profit,
          paymentMode: s.paymentMode || 'Cash',
          status: s.status || (s.paymentMode?.includes('Udhar') ? 'Pending' : 'Paid'),
          date: s.date || 'Today'
        };
      }) : (fallback.transactions || []),
      stats: {
        monthlySalesTarget: derivedKPIs?.monthlyRevenue?.raw || fallback.stats?.monthlySalesTarget || 1000000,
        currentSales: derivedKPIs?.monthlyRevenue?.raw || 0,
        totalPendingUdhar: derivedKPIs?.outstandingPayments?.raw || 0,
        inventoryValuation: derivedKPIs?.inventoryValue?.raw || 0,
        lowStockCount: lowStockItems?.length || 0,
        todaySales: (sales && sales.length > 0) ? sales.reduce((sum, s) => sum + (Number(s.revenue || s.amount || s.total) || 0), 0) : 14365,
        todayProfit: (sales && sales.length > 0) ? sales.reduce((sum, s) => sum + (Number(s.profit) || Math.round((Number(s.revenue || s.amount || s.total) || 0) * 0.22)), 0) : 2400,
        todayOrders: (sales && sales.length > 0) ? sales.length : 5
      }
    };
  }, [businessProfile, sales, inventory, customers, derivedKPIs, lowStockItems, fallback]);

  return (
    <AIAdvisorComponent
      business={liveBusiness}
      onOpenWhatsApp={onOpenWhatsApp}
      onGeneratePO={onOpenPOModal}
      onNavigateTab={onNavigateTab}
      onShowToast={onShowToast}
    />
  );
};
