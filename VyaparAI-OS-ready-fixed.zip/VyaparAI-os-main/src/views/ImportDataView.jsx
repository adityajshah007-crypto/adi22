import React, { useState } from 'react';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle, 
  Download, 
  ArrowRight, 
  ArrowLeft, 
  RefreshCw, 
  Check, 
  ShoppingBag, 
  Package, 
  Users, 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SCHEMAS, DATASET_TYPES } from '../data/schemas';
import { 
  parseFileToRawData, 
  autoMapColumns, 
  validateDataset, 
  downloadSchemaTemplate 
} from '../services/importEngine';
import { useDataStore } from '../context/DataStore';
import { sendImportToBackend } from '../services/apiClient';

export const ImportDataView = ({ onNavigateTab }) => {
  const { importDataset, businessProfile } = useDataStore();

  // Wizard Steps: 1: UPLOAD -> 2: MAP -> 3: VALIDATE -> 4: COMPLETE
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedDatasetType, setSelectedDatasetType] = useState(DATASET_TYPES.SALES);
  
  // File & Raw Data State
  const [fileData, setFileData] = useState(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState('');

  // Mapping State
  const [columnMapping, setColumnMapping] = useState({});
  const [unmappedColumns, setUnmappedColumns] = useState([]);

  // Validation State
  const [validationResult, setValidationResult] = useState(null);
  const [previewFilter, setPreviewFilter] = useState('all'); // 'all', 'valid', 'invalid'
  const [importOption, setImportOption] = useState('append'); // 'append' or 'overwrite'
  const [_isSubmitting, setIsSubmitting] = useState(false);
  const [backendResponse, setBackendResponse] = useState(null);

  const activeSchema = SCHEMAS[selectedDatasetType];

  // =========================================================================
  // STEP 1: FILE UPLOAD HANDLERS
  // =========================================================================
  const handleFileUpload = async (file) => {
    if (!file) return;
    setIsParsing(true);
    setParseError('');

    try {
      const parsed = await parseFileToRawData(file);
      setFileData(parsed);

      // Auto-set dataset type based on detection
      const autoType = parsed.detectedType || selectedDatasetType;
      setSelectedDatasetType(autoType);

      // Auto-map columns
      const { mapping, unmappedColumns: unmapped } = autoMapColumns(parsed.headers, SCHEMAS[autoType]);
      setColumnMapping(mapping);
      setUnmappedColumns(unmapped);

      // Advance to Step 2: Mapping
      setCurrentStep(2);
    } catch (err) {
      console.error(err);
      setParseError(err.message || 'Failed to parse spreadsheet. Please verify file format.');
    } finally {
      setIsParsing(false);
    }
  };

  const handleDatasetTypeChange = (newType) => {
    setSelectedDatasetType(newType);
    if (fileData) {
      const { mapping, unmappedColumns: unmapped } = autoMapColumns(fileData.headers, SCHEMAS[newType]);
      setColumnMapping(mapping);
      setUnmappedColumns(unmapped);
    }
  };

  // =========================================================================
  // STEP 2: COLUMN MAPPING HANDLERS
  // =========================================================================
  const handleMapField = (fieldKey, uploadedCol) => {
    const updatedMapping = { ...columnMapping, [fieldKey]: uploadedCol };
    setColumnMapping(updatedMapping);

    // Recalculate unmapped columns
    const mappedValues = new Set(Object.values(updatedMapping).filter(Boolean));
    setUnmappedColumns(fileData.headers.filter(h => !mappedValues.has(h)));
  };

  const handleProceedToValidation = () => {
    // Run validation against active schema and mapping
    const result = validateDataset(fileData.rawRows, activeSchema, columnMapping);
    setValidationResult(result);
    setCurrentStep(3);
  };

  // =========================================================================
  // STEP 3: CONFIRM IMPORT
  // =========================================================================
  const handleConfirmImport = async () => {
    if (!validationResult) return;

    setIsSubmitting(true);
    const rowsToImport = validationResult.validRows;
    
    // 1. Send to FastAPI backend & PostgreSQL
    const serverResult = await sendImportToBackend(
      selectedDatasetType,
      fileData?.fileName || 'import.xlsx',
      rowsToImport,
      importOption === 'overwrite',
      businessProfile?.id || 'BIZ-BHARAT-001'
    );
    setBackendResponse(serverResult);

    // 2. Synchronize local store
    importDataset(selectedDatasetType, rowsToImport, {
      overwrite: importOption === 'overwrite'
    });

    setIsSubmitting(false);

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    setCurrentStep(4);
  };

  return (
    <div className="page-container">
      {/* Page Title & Stepper Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Import Business Data</h1>
          <p className="page-subtitle">
            Upload Excel (.xlsx/.xls) or CSV spreadsheets. Automatically map columns, validate records, and power your OS.
          </p>
        </div>

        {/* Wizard Step Pills */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: 'var(--bg-card)', padding: '6px 12px', borderRadius: '10px', border: '1px solid var(--border-color)' }}>
          <span style={{ fontSize: '12px', fontWeight: 600, color: currentStep >= 1 ? 'var(--brand-saffron)' : 'var(--text-muted)' }}>
            1. Upload
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>→</span>
          <span style={{ fontSize: '12px', fontWeight: 600, color: currentStep >= 2 ? 'var(--brand-saffron)' : 'var(--text-muted)' }}>
            2. Map Fields
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>→</span>
          <span style={{ fontSize: '12px', fontWeight: 600, color: currentStep >= 3 ? 'var(--brand-saffron)' : 'var(--text-muted)' }}>
            3. Validate
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>→</span>
          <span style={{ fontSize: '12px', fontWeight: 600, color: currentStep >= 4 ? 'var(--brand-green)' : 'var(--text-muted)' }}>
            4. Done
          </span>
        </div>
      </div>

      {/* ====================================================================
          STEP 1: UPLOAD FILE & SELECT DATASET
          ==================================================================== */}
      {currentStep === 1 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Dataset Type Selector Cards */}
          <div className="dashboard-card">
            <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '12px' }}>
              Select What You Are Importing:
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '12px' }}>
              {Object.values(SCHEMAS).map((schema) => {
                const isSelected = selectedDatasetType === schema.id;
                const Icon = schema.id === 'sales' ? ShoppingBag : schema.id === 'inventory' ? Package : Users;

                return (
                  <div
                    key={schema.id}
                    onClick={() => setSelectedDatasetType(schema.id)}
                    style={{
                      border: `2px solid ${isSelected ? 'var(--brand-saffron)' : 'var(--border-color)'}`,
                      backgroundColor: isSelected ? 'rgba(0, 229, 255, 0.08)' : 'var(--bg-card)',
                      borderRadius: '10px',
                      padding: '16px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{ 
                          width: '34px', 
                          height: '34px', 
                          borderRadius: '8px', 
                          backgroundColor: isSelected ? 'var(--brand-saffron)' : 'var(--bg-card-subtle)', 
                          color: isSelected ? '#ffffff' : 'var(--text-primary)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <Icon size={18} />
                        </div>
                        <span style={{ fontSize: '14px', fontWeight: 700 }}>{schema.name}</span>
                      </div>
                      {isSelected && <Check size={16} color="var(--brand-saffron)" />}
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '8px' }}>
                      {schema.description}
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--text-secondary)', marginTop: '6px', fontFamily: 'monospace' }}>
                      Table: {schema.tableName} ({schema.fields.length} standard fields)
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Drag & Drop Upload Zone */}
          <div className="dashboard-card">
            <div 
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileUpload(e.dataTransfer.files[0]);
                }
              }}
              style={{
                border: '2px dashed var(--border-color)',
                borderRadius: '14px',
                padding: '44px 20px',
                textAlign: 'center',
                backgroundColor: 'var(--bg-card-subtle)',
                position: 'relative',
                cursor: 'pointer'
              }}
            >
              <input 
                type="file" 
                accept=".xlsx, .xls, .csv" 
                onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  opacity: 0,
                  cursor: 'pointer'
                }}
              />
              <FileSpreadsheet size={48} color="var(--brand-green)" style={{ margin: '0 auto 12px' }} />
              <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
                Drag and drop your Excel or CSV file here
              </div>
              <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '6px' }}>
                Supports <strong>.xlsx, .xls, and .csv</strong> exports from Tally, Marg ERP, Vyapar, or custom sheets.
              </p>
              <div style={{ marginTop: '16px' }}>
                <span className="btn-primary" style={{ display: 'inline-flex', pointerEvents: 'none' }}>
                  <UploadCloud size={16} />
                  <span>Browse File From Computer</span>
                </span>
              </div>
            </div>

            {isParsing && (
              <div style={{ marginTop: '16px', display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)', fontSize: '13px' }}>
                <RefreshCw size={16} className="spin-animation" />
                <span>Reading spreadsheet, detecting headers and data types...</span>
              </div>
            )}

            {parseError && (
              <div style={{ marginTop: '16px', padding: '12px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-red)', color: 'var(--badge-text-red)', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <AlertCircle size={16} />
                <span>{parseError}</span>
              </div>
            )}
          </div>

          {/* Sample Template Downloads */}
          <div className="dashboard-card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Need a pre-formatted template?
                </div>
                <div style={{ fontSize: '12.5px', color: 'var(--text-muted)' }}>
                  Download standardized Excel templates with all required fields already set up.
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <button 
                  className="btn-secondary" 
                  onClick={() => downloadSchemaTemplate(DATASET_TYPES.SALES)}
                  style={{ fontSize: '12px', padding: '6px 12px' }}
                >
                  <Download size={13} />
                  <span>Sales Template</span>
                </button>
                <button 
                  className="btn-secondary" 
                  onClick={() => downloadSchemaTemplate(DATASET_TYPES.INVENTORY)}
                  style={{ fontSize: '12px', padding: '6px 12px' }}
                >
                  <Download size={13} />
                  <span>Inventory Template</span>
                </button>
                <button 
                  className="btn-secondary" 
                  onClick={() => downloadSchemaTemplate(DATASET_TYPES.CUSTOMERS)}
                  style={{ fontSize: '12px', padding: '6px 12px' }}
                >
                  <Download size={13} />
                  <span>Customers Template</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          STEP 2: MAP COLUMNS & DETECT HEADERS
          ==================================================================== */}
      {currentStep === 2 && fileData && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* File Info Bar */}
          <div className="dashboard-card" style={{ backgroundColor: 'var(--bg-card-subtle)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <FileSpreadsheet size={24} color="var(--brand-green)" />
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 700 }}>
                    {fileData.fileName}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Sheet: "{fileData.sheetName}" • {fileData.totalRows} Total Rows • {fileData.headers.length} Columns Detected
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Target Schema:</span>
                <select 
                  className="ai-input" 
                  value={selectedDatasetType} 
                  onChange={(e) => handleDatasetTypeChange(e.target.value)}
                  style={{ fontSize: '12.5px', padding: '6px 10px' }}
                >
                  <option value={DATASET_TYPES.SALES}>Sales & Orders</option>
                  <option value={DATASET_TYPES.INVENTORY}>Inventory & Stock</option>
                  <option value={DATASET_TYPES.CUSTOMERS}>Customers & Khata</option>
                </select>
              </div>
            </div>
          </div>

          {/* Mapping Grid */}
          <div className="dashboard-card">
            <div className="card-title-bar">
              <div>
                <h2 className="card-heading">Field Mapping: Uploaded Columns → {activeSchema.name}</h2>
                <p className="card-subheading">
                  We automatically matched your column names. Review and adjust mappings before validating.
                </p>
              </div>

              <span className="badge badge-info">
                {Object.values(columnMapping).filter(Boolean).length} of {activeSchema.fields.length} Fields Mapped
              </span>
            </div>

            <div className="modern-table-container">
              <table className="modern-table">
                <thead>
                  <tr>
                    <th>Standard Business Field</th>
                    <th>Type & Requirement</th>
                    <th>Matched Column in Uploaded File</th>
                    <th>Preview Value (Row 1)</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {activeSchema.fields.map((field) => {
                    const matchedCol = columnMapping[field.key] || '';
                    const sampleValue = matchedCol && fileData.rawRows[0] ? String(fileData.rawRows[0][matchedCol] ?? '') : '—';
                    const isMapped = Boolean(matchedCol);

                    return (
                      <tr key={field.key}>
                        <td>
                          <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{field.label}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{field.description}</div>
                        </td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span className="badge badge-info" style={{ fontSize: '10.5px', fontFamily: 'monospace' }}>
                              {field.sqlType}
                            </span>
                            {field.required ? (
                              <span className="badge badge-danger" style={{ fontSize: '10.5px' }}>Required</span>
                            ) : (
                              <span className="badge badge-warning" style={{ fontSize: '10.5px' }}>Optional</span>
                            )}
                          </div>
                        </td>
                        <td>
                          <select 
                            className="ai-input"
                            value={matchedCol}
                            onChange={(e) => handleMapField(field.key, e.target.value)}
                            style={{ 
                              fontSize: '13px', 
                              borderColor: field.required && !isMapped ? '#ef4444' : 'inherit',
                              backgroundColor: isMapped ? 'var(--bg-card)' : 'var(--bg-card-subtle)'
                            }}
                          >
                            <option value="">— Select Column or Leave Empty —</option>
                            {fileData.headers.map((h) => (
                              <option key={h} value={h}>{h}</option>
                            ))}
                          </select>
                        </td>
                        <td style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          <span style={{ fontSize: '12px', color: isMapped ? 'var(--text-primary)' : 'var(--text-muted)', fontFamily: 'monospace' }}>
                            {sampleValue}
                          </span>
                        </td>
                        <td>
                          {isMapped ? (
                            <span className="badge badge-success" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                              <Check size={12} />
                              <span>Mapped</span>
                            </span>
                          ) : field.required ? (
                            <span className="badge badge-danger">Missing</span>
                          ) : (
                            <span className="badge badge-warning">Skipped</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Unmapped Columns Section */}
            {unmappedColumns.length > 0 && (
              <div style={{ marginTop: '20px', padding: '14px 16px', borderRadius: '10px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', fontWeight: 700, color: 'var(--text-secondary)' }}>
                  <AlertTriangle size={15} color="var(--brand-saffron)" />
                  <span>Unmapped Columns from Your Spreadsheet ({unmappedColumns.length}):</span>
                </div>
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' }}>
                  {unmappedColumns.map((col) => (
                    <span key={col} className="badge badge-warning" style={{ fontSize: '11.5px' }}>
                      {col}
                    </span>
                  ))}
                </div>
                <p style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginTop: '6px' }}>
                  These extra columns will be safely ignored during import. You can map them above if any correspond to our standard fields.
                </p>
              </div>
            )}
          </div>

          {/* Navigation Controls */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <button className="btn-secondary" onClick={() => setCurrentStep(1)}>
              <ArrowLeft size={15} />
              <span>Back to Upload</span>
            </button>

            <button 
              className="btn-primary" 
              onClick={handleProceedToValidation}
            >
              <span>Validate & Review Data ({fileData.totalRows} Rows)</span>
              <ArrowRight size={15} />
            </button>
          </div>
        </div>
      )}

      {/* ====================================================================
          STEP 3: VALIDATION SUMMARY & ERROR DIAGNOSTICS
          ==================================================================== */}
      {currentStep === 3 && validationResult && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Import Summary Stats (Requirement 9) */}
          <div className="kpi-grid">
            <div className="kpi-card">
              <span className="kpi-title">Total Rows In File</span>
              <div className="kpi-value" style={{ marginTop: '8px' }}>{validationResult.totalRows}</div>
              <div className="kpi-trend neutral">Scanned & checked</div>
            </div>

            <div className="kpi-card">
              <span className="kpi-title">Valid Rows</span>
              <div className="kpi-value" style={{ marginTop: '8px', color: 'var(--brand-green)' }}>
                {validationResult.validRowsCount}
              </div>
              <div className="kpi-trend positive">Ready for import</div>
            </div>

            <div className="kpi-card">
              <span className="kpi-title">Invalid Rows</span>
              <div className="kpi-value" style={{ marginTop: '8px', color: validationResult.invalidRowsCount > 0 ? '#ef4444' : 'inherit' }}>
                {validationResult.invalidRowsCount}
              </div>
              <div className="kpi-trend negative">Validation errors</div>
            </div>

            <div className="kpi-card">
              <span className="kpi-title">Duplicate Records</span>
              <div className="kpi-value" style={{ marginTop: '8px', color: validationResult.duplicateCount > 0 ? '#f59e0b' : 'inherit' }}>
                {validationResult.duplicateCount}
              </div>
              <div className="kpi-trend" style={{ color: '#f59e0b' }}>Repeated entries</div>
            </div>
          </div>

          {/* Validation Diagnostics Banner */}
          {validationResult.invalidRowsCount > 0 ? (
            <div style={{ padding: '16px', borderRadius: '10px', backgroundColor: 'var(--badge-bg-red)', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--badge-text-red)', fontWeight: 700, fontSize: '14px' }}>
                <AlertCircle size={18} />
                <span>Found {validationResult.errors.length} errors across {validationResult.invalidRowsCount} rows:</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '10px', maxHeight: '140px', overflowY: 'auto' }}>
                {validationResult.errors.slice(0, 8).map((err, idx) => (
                  <div key={idx} style={{ fontSize: '12px', color: '#991b1b', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <strong>Row #{err.row}:</strong>
                    <span>{err.message}</span>
                  </div>
                ))}
                {validationResult.errors.length > 8 && (
                  <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                    + {validationResult.errors.length - 8} more errors below...
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div style={{ padding: '14px 18px', borderRadius: '10px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--badge-text-green)', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '13.5px', fontWeight: 600 }}>
              <CheckCircle2 size={18} />
              <span>All {validationResult.validRowsCount} rows passed schema validation cleanly! Zero formatting errors.</span>
            </div>
          )}

          {/* Interactive Data Preview Table */}
          <div className="dashboard-card">
            <div className="card-title-bar">
              <div>
                <h2 className="card-heading">Row-by-Row Data Preview</h2>
                <p className="card-subheading">Review transformed records before database commit</p>
              </div>

              <div className="tabs-navigation-bar">
                <button 
                  className={`tab-nav-btn ${previewFilter === 'all' ? 'active' : ''}`}
                  onClick={() => setPreviewFilter('all')}
                >
                  All Rows ({validationResult.totalRows})
                </button>
                <button 
                  className={`tab-nav-btn ${previewFilter === 'valid' ? 'active' : ''}`}
                  onClick={() => setPreviewFilter('valid')}
                >
                  Valid ({validationResult.validRowsCount})
                </button>
                <button 
                  className={`tab-nav-btn ${previewFilter === 'invalid' ? 'active' : ''}`}
                  onClick={() => setPreviewFilter('invalid')}
                >
                  Invalid ({validationResult.invalidRowsCount})
                </button>
              </div>
            </div>

            <div className="modern-table-container">
              <table className="modern-table">
                <thead>
                  <tr>
                    <th>Row #</th>
                    <th>Status</th>
                    {activeSchema.fields.slice(0, 6).map(f => (
                      <th key={f.key}>{f.label}</th>
                    ))}
                    <th>Validation Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {validationResult.normalizedRows
                    .filter(r => {
                      if (previewFilter === 'valid') return r._isValid;
                      if (previewFilter === 'invalid') return !r._isValid;
                      return true;
                    })
                    .slice(0, 15)
                    .map((row) => (
                      <tr 
                        key={row._rowIndex}
                        style={{ 
                          backgroundColor: !row._isValid ? 'rgba(239, 68, 68, 0.05)' : 'inherit' 
                        }}
                      >
                        <td><strong>#{row._rowIndex}</strong></td>
                        <td>
                          {row._isValid ? (
                            <span className="badge badge-success">Valid</span>
                          ) : (
                            <span className="badge badge-danger">Error</span>
                          )}
                        </td>
                        {activeSchema.fields.slice(0, 6).map(f => {
                          const val = row[f.key];
                          const hasErr = row._errors && row._errors.some(e => e.field === f.label);

                          return (
                            <td 
                              key={f.key}
                              style={{
                                color: hasErr ? '#ef4444' : 'inherit',
                                fontWeight: hasErr ? 700 : 'normal',
                                backgroundColor: hasErr ? 'rgba(239, 68, 68, 0.1)' : 'transparent'
                              }}
                            >
                              {val !== undefined && val !== null ? String(val) : '—'}
                            </td>
                          );
                        })}
                        <td style={{ maxWidth: '240px' }}>
                          {row._errors && row._errors.length > 0 ? (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                              {row._errors.map((e, idx) => (
                                <span key={idx} style={{ fontSize: '11px', color: '#ef4444' }}>
                                  • {e.message}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span style={{ fontSize: '11.5px', color: 'var(--brand-green)' }}>Passed</span>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Import Action Controls */}
          <div className="dashboard-card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <button className="btn-secondary" onClick={() => setCurrentStep(2)}>
                <ArrowLeft size={15} />
                <span>Adjust Mapping</span>
              </button>

              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
                <span style={{ color: 'var(--text-muted)' }}>Mode:</span>
                <label style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                  <input 
                    type="radio" 
                    name="importMode" 
                    value="append" 
                    checked={importOption === 'append'} 
                    onChange={() => setImportOption('append')} 
                  />
                  <span>Append to existing records</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', marginLeft: '10px' }}>
                  <input 
                    type="radio" 
                    name="importMode" 
                    value="overwrite" 
                    checked={importOption === 'overwrite'} 
                    onChange={() => setImportOption('overwrite')} 
                  />
                  <span>Replace existing records</span>
                </label>
              </div>
            </div>

            <button 
              className="btn-primary"
              onClick={handleConfirmImport}
              disabled={validationResult.validRowsCount === 0}
              style={{ backgroundColor: 'var(--brand-green)', borderColor: 'var(--brand-green)' }}
            >
              <CheckCircle2 size={16} />
              <span>Confirm & Import {validationResult.validRowsCount} Valid Rows</span>
            </button>
          </div>
        </div>
      )}

      {/* ====================================================================
          STEP 4: IMPORT COMPLETED CONFIRMATION
          ==================================================================== */}
      {currentStep === 4 && (
        <div className="dashboard-card" style={{ textAlign: 'center', padding: '48px 24px' }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            backgroundColor: 'var(--badge-bg-green)',
            color: 'var(--brand-green)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px'
          }}>
            <CheckCircle2 size={36} />
          </div>

          <h2 style={{ fontSize: '22px', fontWeight: 800, color: 'var(--text-primary)' }}>
            Data Import Successful!
          </h2>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', maxWidth: '520px', margin: '8px auto 16px' }}>
            Successfully imported <strong>{validationResult?.validRowsCount}</strong> records into <strong>{activeSchema.name}</strong>. The data has been validated by FastAPI and persisted to PostgreSQL.
          </p>

          {backendResponse && (
            <div style={{ maxWidth: '460px', margin: '0 auto 24px', padding: '12px 16px', borderRadius: '8px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', fontSize: '12px', textAlign: 'left' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: 'var(--text-muted)' }}>Backend Server Job:</span>
                <span className="font-mono" style={{ fontWeight: 700, color: 'var(--brand-green)' }}>{backendResponse.job_id}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: 'var(--text-muted)' }}>Tenant Isolation Scope:</span>
                <span className="font-mono" style={{ fontWeight: 600 }}>{backendResponse.business_id}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Database State:</span>
                <span className="badge badge-success" style={{ fontSize: '10.5px' }}>Committed</span>
              </div>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'center', gap: '12px', flexWrap: 'wrap' }}>
            <button 
              className="btn-primary"
              onClick={() => onNavigateTab('command-center')}
            >
              <span>Go to Command Center</span>
            </button>

            <button 
              className="btn-secondary"
              onClick={() => onNavigateTab(selectedDatasetType)}
            >
              <span>View In {activeSchema.name}</span>
            </button>

            <button 
              className="btn-secondary"
              onClick={() => {
                setFileData(null);
                setValidationResult(null);
                setCurrentStep(1);
              }}
            >
              <span>Import Another File</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
