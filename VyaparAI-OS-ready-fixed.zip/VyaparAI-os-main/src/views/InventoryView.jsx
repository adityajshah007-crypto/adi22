import React, { useState } from 'react';
import { 
  Search, 
  FileText, 
  Download,
  FileSpreadsheet,
  Plus,
  Minus,
  X,
  CheckCircle2,
  Boxes
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDataStore } from '../context/DataStore';
import { downloadSchemaTemplate } from '../services/importEngine';
import { DATASET_TYPES } from '../data/schemas';

export const InventoryView = ({ onOpenPOModal, onShowToast }) => {
  const [filter, setFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    product: '',
    sku: '',
    category: 'General',
    currentStock: '',
    costPrice: '',
    sellingPrice: '',
    supplier: '',
    reorderLevel: '10'
  });

  const { inventory, lowStockItems, derivedKPIs, importDataset, adjustStock } = useDataStore();

  const categories = ['All', ...new Set(inventory.map(i => i.category || 'General'))];

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = (item.product && item.product.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase())) ||
                          (item.supplier && item.supplier.toLowerCase().includes(searchTerm.toLowerCase()));
    if (!matchesSearch) return false;

    if (categoryFilter !== 'All' && (item.category || 'General') !== categoryFilter) return false;

    const isLow = (Number(item.currentStock) || 0) <= (Number(item.reorderLevel) || 10);
    if (filter === 'low') return isLow;
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Product', 'SKU', 'Category', 'Current Stock', 'Cost Price', 'Selling Price', 'Supplier', 'Reorder Level'];
    const rows = filteredInventory.map(i => [
      `"${i.product || ''}"`,
      `"${i.sku || ''}"`,
      `"${i.category || ''}"`,
      i.currentStock || 0,
      i.costPrice || 0,
      i.sellingPrice || 0,
      `"${i.supplier || ''}"`,
      i.reorderLevel || 10
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `inventory_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleQuickAdjust = (item, delta) => {
    const current = Number(item.currentStock) || 0;
    if (delta < 0 && current <= 0) return;
    const newStock = Math.max(0, current + delta);
    adjustStock(item.sku, delta);
    if (onShowToast) {
      onShowToast({
        message: `${item.product} stock updated to ${newStock} pcs`,
        type: 'info'
      });
    }
  };

  const handleAddItem = (e) => {
    e.preventDefault();
    if (!formData.product.trim()) {
      if (onShowToast) {
        onShowToast({ message: 'Product name is required.', type: 'error' });
      }
      return;
    }

    const generatedSku = formData.sku.trim() || `SKU-${Date.now().toString().slice(-4)}`;
    const newItem = {
      sku: generatedSku,
      product: formData.product.trim(),
      category: formData.category.trim() || 'General',
      currentStock: Number(formData.currentStock) || 0,
      costPrice: Number(formData.costPrice) || 0,
      sellingPrice: Number(formData.sellingPrice) || 0,
      supplier: formData.supplier.trim() || 'Primary Distributor',
      reorderLevel: Number(formData.reorderLevel) || 10
    };

    importDataset(DATASET_TYPES.INVENTORY, [newItem], { overwrite: false });
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
    if (onShowToast) {
      onShowToast({
        message: `Item "${newItem.product}" (${newItem.sku}) added to inventory!`,
        type: 'success'
      });
    }

    setFormData({
      product: '',
      sku: '',
      category: 'General',
      currentStock: '',
      costPrice: '',
      sellingPrice: '',
      supplier: '',
      reorderLevel: '10'
    });
    setShowAddModal(false);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Inventory</h1>
          <p className="page-subtitle">Track stock valuation, reorder thresholds, safety buffers, and supplier catalogues.</p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-secondary" 
            onClick={handleExportCSV}
            style={{ fontSize: '13px' }}
            title="Export filtered inventory records as CSV"
          >
            <FileSpreadsheet size={14} />
            <span>Export CSV</span>
          </button>

          <button 
            className="btn-secondary" 
            onClick={() => downloadSchemaTemplate(DATASET_TYPES.INVENTORY)}
            style={{ fontSize: '13px' }}
          >
            <Download size={14} />
            <span>Download Template</span>
          </button>

          <button 
            className="btn-secondary"
            onClick={() => onOpenPOModal && onOpenPOModal(lowStockItems)}
            style={{ fontSize: '13px' }}
          >
            <FileText size={15} />
            <span>Reorder PO ({lowStockItems.length})</span>
          </button>

          <button 
            className="btn-primary"
            onClick={() => setShowAddModal(true)}
            style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}
          >
            <Plus size={15} />
            <span>+ Add Item</span>
          </button>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <span className="kpi-title">Inventory Valuation</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>{derivedKPIs.inventoryValue.formatted}</div>
          <div className="kpi-trend positive">{inventory.length} Total SKUs</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Low Stock SKUs</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: lowStockItems.length > 0 ? '#ef4444' : 'inherit' }}>
            {lowStockItems.length} Items
          </div>
          <div className="kpi-trend negative">Below safety buffer</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Total Units in Stock</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>
            {inventory.reduce((sum, i) => sum + (Number(i.currentStock) || 0), 0)} pcs
          </div>
          <div className="kpi-trend positive">Across warehouse</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Avg Unit Cost</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>
            ₹{inventory.length > 0 ? Math.round(inventory.reduce((sum, i) => sum + (Number(i.costPrice) || 0), 0) / inventory.length).toLocaleString('en-IN') : '0'}
          </div>
          <div className="kpi-trend neutral">Wholesale procurement</div>
        </div>
      </div>

      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Stock Inventory Matrix ({filteredInventory.length} Items)</h2>
            <p className="card-subheading">Live inventory levels, safety margins, and reorder alerts</p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <div className="tabs-navigation-bar">
              <button className={`tab-nav-btn ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>
                All ({inventory.length})
              </button>
              <button className={`tab-nav-btn ${filter === 'low' ? 'active' : ''}`} onClick={() => setFilter('low')}>
                Low Stock ({lowStockItems.length})
              </button>
            </div>

            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="ai-input"
              style={{ fontSize: '12.5px', padding: '6px 10px', height: '36px' }}
            >
              {categories.map((cat, i) => (
                <option key={i} value={cat}>{cat === 'All' ? 'All Categories' : cat}</option>
              ))}
            </select>

            <div style={{ position: 'relative', width: '200px' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
              <input 
                type="text" 
                placeholder="Search item or SKU..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)}
                className="ai-input" 
                style={{ paddingLeft: '32px', fontSize: '13px' }} 
              />
            </div>
          </div>
        </div>

        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Category</th>
                <th>In Stock / Reorder Point</th>
                <th>Cost Price</th>
                <th>Selling Price</th>
                <th>Supplier</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredInventory.map((item, idx) => {
                const isLow = (Number(item.currentStock) || 0) <= (Number(item.reorderLevel) || 10);
                return (
                  <tr key={idx}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{item.product}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>SKU: {item.sku || `SKU-${idx + 101}`}</div>
                    </td>
                    <td><span className="badge badge-info">{item.category || 'General'}</span></td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div>
                          <strong style={{ color: isLow ? '#ef4444' : 'inherit' }}>
                            {item.currentStock} pcs
                          </strong>
                          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}> (min: {item.reorderLevel || 10})</span>
                        </div>
                        <div style={{ display: 'flex', gap: '3px', marginLeft: 'auto' }}>
                          <button
                            type="button"
                            title="Decrease stock by 1"
                            onClick={() => handleQuickAdjust(item, -1)}
                            disabled={(Number(item.currentStock) || 0) <= 0}
                            style={{
                              border: '1px solid var(--border-color)',
                              background: 'rgba(255, 255, 255, 0.04)',
                              color: 'var(--text-secondary)',
                              borderRadius: '4px',
                              width: '22px',
                              height: '22px',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: (Number(item.currentStock) || 0) <= 0 ? 'not-allowed' : 'pointer',
                              padding: 0
                            }}
                          >
                            <Minus size={11} />
                          </button>
                          <button
                            type="button"
                            title="Increase stock by 1"
                            onClick={() => handleQuickAdjust(item, 1)}
                            style={{
                              border: '1px solid var(--border-color)',
                              background: 'rgba(255, 255, 255, 0.04)',
                              color: 'var(--text-secondary)',
                              borderRadius: '4px',
                              width: '22px',
                              height: '22px',
                              display: 'inline-flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              cursor: 'pointer',
                              padding: 0
                            }}
                          >
                            <Plus size={11} />
                          </button>
                        </div>
                      </div>
                    </td>
                    <td>₹{Number(item.costPrice || 0).toLocaleString('en-IN')}</td>
                    <td><strong>₹{Number(item.sellingPrice || 0).toLocaleString('en-IN')}</strong></td>
                    <td>
                      <div>{item.supplier || 'Primary Distributor'}</div>
                    </td>
                    <td>
                      {isLow ? (
                        <span className="badge badge-danger">Reorder Alert</span>
                      ) : (
                        <span className="badge badge-success">Healthy</span>
                      )}
                    </td>
                    <td>
                      <button 
                        className="btn-secondary" 
                        style={{ padding: '4px 10px', fontSize: '12px' }}
                        onClick={() => onOpenPOModal && onOpenPOModal([item])}
                      >
                        Reorder
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Inventory Item Modal */}
      {showAddModal && (
        <div className="modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="modal-container" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '520px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ 
                  width: '36px', 
                  height: '36px', 
                  borderRadius: '10px', 
                  background: 'rgba(0, 240, 255, 0.15)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  color: 'var(--brand-cyan)'
                }}>
                  <Boxes size={20} />
                </div>
                <div>
                  <h3 className="modal-title">Add Inventory SKU</h3>
                  <p className="modal-subtitle" style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Add new product SKU, wholesale procurement costs &amp; selling prices
                  </p>
                </div>
              </div>
              <button className="modal-close-btn" onClick={() => setShowAddModal(false)}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddItem}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px', padding: '20px 24px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                    Product Name *
                  </label>
                  <input 
                    type="text"
                    required
                    autoFocus
                    placeholder="e.g. Copper Induction Motor 2HP"
                    value={formData.product}
                    onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                    className="ai-input"
                    style={{ width: '100%', fontSize: '13px' }}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      SKU Code (Auto-generated if blank)
                    </label>
                    <input 
                      type="text"
                      placeholder="e.g. MOT-IND-2HP"
                      value={formData.sku}
                      onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Category
                    </label>
                    <input 
                      type="text"
                      placeholder="e.g. Motors, Pumps, Cables"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Opening Stock (Units) *
                    </label>
                    <input 
                      type="number"
                      min="0"
                      required
                      placeholder="0"
                      value={formData.currentStock}
                      onChange={(e) => setFormData({ ...formData, currentStock: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Reorder Threshold (Units)
                    </label>
                    <input 
                      type="number"
                      min="1"
                      placeholder="10"
                      value={formData.reorderLevel}
                      onChange={(e) => setFormData({ ...formData, reorderLevel: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Cost Price / Unit (₹) *
                    </label>
                    <input 
                      type="number"
                      min="0"
                      step="any"
                      required
                      placeholder="0.00"
                      value={formData.costPrice}
                      onChange={(e) => setFormData({ ...formData, costPrice: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Selling Price / Unit (₹) *
                    </label>
                    <input 
                      type="number"
                      min="0"
                      step="any"
                      required
                      placeholder="0.00"
                      value={formData.sellingPrice}
                      onChange={(e) => setFormData({ ...formData, sellingPrice: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                    Supplier / Manufacturer
                  </label>
                  <input 
                    type="text"
                    placeholder="e.g. Apex Electricals Wholesalers"
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    className="ai-input"
                    style={{ width: '100%', fontSize: '13px' }}
                  />
                </div>
              </div>

              <div className="modal-footer" style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', padding: '16px 24px', borderTop: '1px solid var(--border-color)' }}>
                <button type="button" className="btn-secondary" onClick={() => setShowAddModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                  <CheckCircle2 size={15} />
                  <span>Save Product</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
