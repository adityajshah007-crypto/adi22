import React, { useState } from 'react';
import { 
  Search, 
  Download, 
  MessageCircle,
  FileSpreadsheet,
  UserPlus,
  X,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDataStore } from '../context/DataStore';
import { downloadSchemaTemplate } from '../services/importEngine';
import { DATASET_TYPES } from '../data/schemas';

export const CustomersView = ({ onOpenWhatsApp, onShowToast }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // 'all' | 'due' | 'cleared'
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    totalPurchases: '',
    amountDue: '',
    dueDate: '30 Days'
  });

  const { customers, derivedKPIs, importDataset } = useDataStore();

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = 
      (c.customerName && c.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (c.phone && c.phone.includes(searchTerm)) ||
      (c.email && c.email.toLowerCase().includes(searchTerm.toLowerCase()));
    if (!matchesSearch) return false;

    const due = Number(c.amountDue) || 0;
    if (statusFilter === 'due') return due > 0;
    if (statusFilter === 'cleared') return due === 0;
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Customer Name', 'Phone', 'Email', 'Total Purchases', 'Amount Paid', 'Amount Due', 'Due Date'];
    const rows = filteredCustomers.map(c => [
      `"${c.customerName || c.name || ''}"`,
      `"${c.phone || ''}"`,
      `"${c.email || ''}"`,
      c.totalPurchases || 0,
      c.amountPaid || 0,
      c.amountDue || 0,
      `"${c.dueDate || ''}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `customers_directory_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddCustomer = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      if (onShowToast) {
        onShowToast({ message: 'Customer Name and Phone Number are required.', type: 'error' });
      }
      return;
    }

    const due = parseFloat(formData.amountDue) || 0;
    const purchases = parseFloat(formData.totalPurchases) || due;

    const newCustomer = {
      id: `cust_${Date.now()}`,
      customerName: formData.name.trim(),
      phone: formData.phone.trim(),
      email: formData.email.trim() || `${formData.name.toLowerCase().replace(/\s+/g, '')}@example.com`,
      totalPurchases: purchases,
      amountPaid: 0,
      amountDue: due,
      dueDate: formData.dueDate || '30 Days',
      overdueDays: due > 0 ? 7 : 0
    };

    importDataset(DATASET_TYPES.CUSTOMERS, [newCustomer], { overwrite: false });
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
    if (onShowToast) {
      onShowToast({
        message: `Customer "${newCustomer.customerName}" added to directory successfully!`,
        type: 'success'
      });
    }

    setFormData({
      name: '',
      phone: '',
      email: '',
      totalPurchases: '',
      amountDue: '',
      dueDate: '30 Days'
    });
    setShowAddModal(false);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Customers</h1>
          <p className="page-subtitle">Customer relationship directory, purchase volumes, and account status.</p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-secondary" 
            onClick={handleExportCSV}
            style={{ fontSize: '13px' }}
            title="Export customer directory to CSV"
          >
            <FileSpreadsheet size={14} />
            <span>Export CSV</span>
          </button>

          <button 
            className="btn-secondary" 
            onClick={() => downloadSchemaTemplate(DATASET_TYPES.CUSTOMERS)}
            style={{ fontSize: '13px' }}
          >
            <Download size={14} />
            <span>Download Template</span>
          </button>

          <button 
            className="btn-primary" 
            onClick={() => setShowAddModal(true)}
            style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}
          >
            <UserPlus size={15} />
            <span>+ Add Customer</span>
          </button>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <span className="kpi-title">Total Customer Accounts</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>{customers.length} Parties</div>
          <div className="kpi-trend positive">Active ledger</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Total Outstanding Udhar</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: '#ef4444' }}>
            {derivedKPIs.outstandingPayments.formatted}
          </div>
          <div className="kpi-trend negative">Pending collection</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Total Lifetime Collections</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: 'var(--brand-green)' }}>
            ₹{customers.reduce((sum, c) => sum + (Number(c.amountPaid) || 0), 0).toLocaleString('en-IN')}
          </div>
          <div className="kpi-trend positive">Settled payments</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Parties with Pending Dues</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>
            {customers.filter(c => Number(c.amountDue) > 0).length} Accounts
          </div>
          <div className="kpi-trend neutral">Follow-up needed</div>
        </div>
      </div>

      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Customer Directory ({filteredCustomers.length} Records)</h2>
            <p className="card-subheading">Manage business contacts, credit limits, and purchase histories</p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <div className="tabs-navigation-bar">
              <button 
                className={`tab-nav-btn ${statusFilter === 'all' ? 'active' : ''}`}
                onClick={() => setStatusFilter('all')}
              >
                All ({customers.length})
              </button>
              <button 
                className={`tab-nav-btn ${statusFilter === 'due' ? 'active' : ''}`}
                onClick={() => setStatusFilter('due')}
              >
                Has Udhar ({customers.filter(c => Number(c.amountDue) > 0).length})
              </button>
              <button 
                className={`tab-nav-btn ${statusFilter === 'cleared' ? 'active' : ''}`}
                onClick={() => setStatusFilter('cleared')}
              >
                Cleared ({customers.filter(c => Number(c.amountDue) === 0).length})
              </button>
            </div>

            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
              <input 
                type="text" 
                placeholder="Search customer or phone..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="ai-input" 
                style={{ paddingLeft: '32px', fontSize: '13px' }} 
              />
            </div>
          </div>
        </div>

        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Customer / Firm</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Total Purchases</th>
                <th>Amount Paid</th>
                <th>Amount Due (Udhar)</th>
                <th>Due Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((c, idx) => {
                const due = Number(c.amountDue) || 0;
                return (
                  <tr key={idx}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{c.customerName || c.name}</div>
                    </td>
                    <td>{c.phone || '—'}</td>
                    <td>{c.email || '—'}</td>
                    <td>₹{Number(c.totalPurchases || 0).toLocaleString('en-IN')}</td>
                    <td>
                      <span style={{ color: 'var(--brand-green)', fontWeight: 600 }}>
                        ₹{Number(c.amountPaid || 0).toLocaleString('en-IN')}
                      </span>
                    </td>
                    <td>
                      <strong style={{ color: due > 0 ? '#ef4444' : 'inherit' }}>
                        ₹{due.toLocaleString('en-IN')}
                      </strong>
                    </td>
                    <td>{c.dueDate || '—'}</td>
                    <td>
                      <button 
                        className="btn-whatsapp" 
                        style={{ padding: '4px 10px', fontSize: '12px', borderRadius: '6px' }}
                        onClick={() => onOpenWhatsApp && onOpenWhatsApp({ 
                          name: c.customerName || c.name, 
                          phone: c.phone || '+91 98000 00000', 
                          pendingAmount: due, 
                          overdueDays: 14 
                        })}
                      >
                        <MessageCircle size={13} />
                        <span>WhatsApp</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="modal-container" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '500px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ 
                  width: '36px', 
                  height: '36px', 
                  borderRadius: '10px', 
                  background: 'rgba(0, 240, 255, 0.15)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  color: 'var(--brand-cyan)'
                }}>
                  <UserPlus size={20} />
                </div>
                <div>
                  <h3 className="modal-title">Add New Customer Party</h3>
                  <p className="modal-subtitle" style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Create party ledger entry for credit tracking and invoices
                  </p>
                </div>
              </div>
              <button className="modal-close-btn" onClick={() => setShowAddModal(false)}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddCustomer}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px', padding: '20px 24px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                    Customer / Business Name *
                  </label>
                  <input 
                    type="text"
                    required
                    autoFocus
                    placeholder="e.g. Metro Electronics Pvt Ltd"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="ai-input"
                    style={{ width: '100%', fontSize: '13px' }}
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Phone / WhatsApp *
                    </label>
                    <input 
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Email Address
                    </label>
                    <input 
                      type="email"
                      placeholder="party@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Opening Udhar Due (₹)
                    </label>
                    <input 
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.amountDue}
                      onChange={(e) => setFormData({ ...formData, amountDue: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                      Total Purchases (₹)
                    </label>
                    <input 
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.totalPurchases}
                      onChange={(e) => setFormData({ ...formData, totalPurchases: e.target.value })}
                      className="ai-input"
                      style={{ width: '100%', fontSize: '13px' }}
                    />
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '5px' }}>
                    Credit Terms / Due Duration
                  </label>
                  <select 
                    value={formData.dueDate}
                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                    className="ai-input"
                    style={{ width: '100%', fontSize: '13px' }}
                  >
                    <option value="Immediate">Immediate / Advance</option>
                    <option value="15 Days">15 Days Net</option>
                    <option value="30 Days">30 Days Net</option>
                    <option value="45 Days">45 Days Net</option>
                    <option value="60 Days">60 Days Net</option>
                  </select>
                </div>
              </div>

              <div className="modal-footer" style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', padding: '16px 24px', borderTop: '1px solid var(--border-color)' }}>
                <button type="button" className="btn-secondary" onClick={() => setShowAddModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                  <CheckCircle2 size={15} />
                  <span>Save Customer</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
