import React, { useState } from 'react';
import { 
  Store, 
  Lock, 
  Mail, 
  User, 
  ArrowRight, 
  CheckCircle2, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  Eye, 
  EyeOff, 
  Sun, 
  Moon,
  TrendingUp,
  Bot
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const BUSINESS_CATEGORIES = [
  'Supermart & Wholesale FMCG',
  'Kirana & General Grocery Store',
  'Textiles, Garments & Apparel',
  'Electronics, Mobiles & Hardware',
  'Pharmacy, Chemists & Healthcare',
  'Building Materials & Sanitaryware',
  'Auto Spares & Hardware Tools',
  'Distribution & Multi-Brand Wholesale'
];

export const AuthView = ({ theme, toggleTheme }) => {
  const { login, register, loginWithDemo, authError, setAuthError } = useAuth();

  const [activeMode, setActiveMode] = useState('login'); // 'login' | 'register'
  const [showPassword, setShowPassword] = useState(false);
  
  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginSubmitting, setLoginSubmitting] = useState(false);

  // Register Form State
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regBusinessName, setRegBusinessName] = useState('');
  const [regBusinessType, setRegBusinessType] = useState(BUSINESS_CATEGORIES[0]);
  const [regLocation, setRegLocation] = useState('');
  const [regGstin, setRegGstin] = useState('');
  const [regUpiId, setRegUpiId] = useState('');
  const [regSubmitting, setRegSubmitting] = useState(false);

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setAuthError('Please enter your email and password');
      return;
    }
    setLoginSubmitting(true);
    try {
      await login(loginEmail, loginPassword);
    } catch {
      // Error is set in AuthContext
    } finally {
      setLoginSubmitting(false);
    }
  };

  const handleDemoLogin = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    setLoginEmail('rajesh@bharat.com');
    setLoginPassword('admin123');
    setLoginSubmitting(true);
    setAuthError(null);
    try {
      await loginWithDemo();
    } catch (err) {
      setAuthError(err.message || 'Demo login could not be completed.');
    } finally {
      setLoginSubmitting(false);
    }
  };

  const handleFillDemoOnly = (e) => {
    if (e) e.stopPropagation();
    setLoginEmail('rajesh@bharat.com');
    setLoginPassword('admin123');
    setAuthError(null);
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    if (!regFullName || !regEmail || !regPassword || !regBusinessName) {
      setAuthError('Please fill in all required fields (Name, Email, Password, Business Name)');
      return;
    }
    if (regPassword.length < 6) {
      setAuthError('Password must be at least 6 characters long');
      return;
    }

    setRegSubmitting(true);
    try {
      await register({
        full_name: regFullName,
        email: regEmail,
        password: regPassword,
        business_name: regBusinessName,
        business_type: regBusinessType,
        location: regLocation,
        gstin: regGstin,
        upi_id: regUpiId,
        currency: 'INR'
      });
    } catch {
      // Handled in context
    } finally {
      setRegSubmitting(false);
    }
  };

  return (
    <div className="auth-wrapper">
      {/* Top right theme toggle */}
      <div style={{ position: 'absolute', top: '20px', right: '24px', zIndex: 10 }}>
        <button 
          className="header-icon-btn"
          onClick={toggleTheme}
          title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
          style={{
            backgroundColor: 'var(--bg-card)',
            border: '1px solid var(--border-color)',
            boxShadow: 'var(--card-shadow)'
          }}
        >
          {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
        </button>
      </div>

      {/* Left Brand Showcase Banner */}
      <div className="auth-left-banner">
        
        {/* Brand Header */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '28px' }}>
            <div style={{
              width: '44px',
              height: '44px',
              borderRadius: '12px',
              backgroundColor: 'var(--brand-saffron)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#030712',
              fontWeight: 800,
              fontSize: '22px',
              boxShadow: '0 4px 12px rgba(0, 229, 255, 0.35)'
            }}>
              V
            </div>
            <div>
              <div style={{ fontSize: '22px', fontWeight: 800, letterSpacing: '-0.5px' }}>
                VyaparAI <span style={{ color: 'var(--brand-saffron)' }}>OS</span>
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 500 }}>
                Enterprise AI Operating System for Indian SMBs
              </div>
            </div>
          </div>

          <div style={{ maxWidth: '440px', marginTop: '36px' }}>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '4px 10px',
              borderRadius: '20px',
              backgroundColor: 'rgba(0, 229, 255, 0.12)',
              color: 'var(--brand-saffron)',
              fontSize: '11.5px',
              fontWeight: 700,
              marginBottom: '16px'
            }}>
              <Sparkles size={13} />
              <span>SMART VYAPAR PLATFORM 2.0</span>
            </div>

            <h1 style={{
              fontSize: '32px',
              fontWeight: 800,
              lineHeight: 1.25,
              marginBottom: '16px',
              color: 'var(--text-primary)',
              letterSpacing: '-0.5px'
            }}>
              Run your business smarter with <span style={{ color: 'var(--brand-saffron)' }}>AI intelligence</span>.
            </h1>

            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: '32px' }}>
              Complete operating system combining real-time ledger khata, automated WhatsApp recovery reminders, inventory reorder forecasting, and autonomous AI advice.
            </p>

            {/* Feature Points */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <div style={{
                  padding: '6px',
                  borderRadius: '8px',
                  backgroundColor: 'var(--badge-bg-green)',
                  color: 'var(--brand-green)'
                }}>
                  <TrendingUp size={16} />
                </div>
                <div>
                  <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                    Auto Udhar & Khata Recovery
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Track party balances and dispatch 1-click bilingual WhatsApp reminders.
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <div style={{
                  padding: '6px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(37, 99, 235, 0.12)',
                  color: 'var(--brand-blue)'
                }}>
                  <Bot size={16} />
                </div>
                <div>
                  <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                    Autonomous AI Advisor
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Get proactive dead-stock warnings, discount strategies, and profit optimization.
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <div style={{
                  padding: '6px',
                  borderRadius: '8px',
                  backgroundColor: 'rgba(139, 92, 246, 0.12)',
                  color: 'var(--brand-purple)'
                }}>
                  <ShieldCheck size={16} />
                </div>
                <div>
                  <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                    Isolated Multi-Tenant Security
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Your business data and ledger records are completely isolated and encrypted.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Trust Indicator */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          paddingTop: '24px',
          borderTop: '1px solid var(--border-color)',
          fontSize: '11.5px',
          color: 'var(--text-muted)'
        }}>
          <span>🇮🇳 Built specifically for Indian Retailers, Wholesalers & Distributors</span>
        </div>
      </div>

      {/* Right Form Card Section */}
      <div className="auth-right-container">
        <div className="auth-card">
          {/* Mobile-Only Brand Header */}
          <div className="auth-mobile-header">
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              backgroundColor: 'var(--brand-saffron)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#030712',
              fontWeight: 800,
              fontSize: '20px',
              boxShadow: '0 4px 12px rgba(0, 229, 255, 0.35)'
            }}>
              V
            </div>
            <div>
              <div style={{ fontSize: '18px', fontWeight: 800, letterSpacing: '-0.4px', color: 'var(--text-primary)' }}>
                VyaparAI <span style={{ color: 'var(--brand-saffron)' }}>OS</span>
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 500 }}>
                Enterprise AI Operating System
              </div>
            </div>
          </div>
          {/* Mode Switch Tabs */}
          <div style={{
            display: 'flex',
            backgroundColor: 'var(--bg-card-subtle)',
            borderRadius: '10px',
            padding: '4px',
            marginBottom: '24px'
          }}>
            <button
              onClick={() => { setActiveMode('login'); setAuthError(null); }}
              style={{
                flex: 1,
                padding: '9px 12px',
                border: 'none',
                borderRadius: '8px',
                fontSize: '13px',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                backgroundColor: activeMode === 'login' ? 'var(--bg-card)' : 'transparent',
                color: activeMode === 'login' ? 'var(--text-primary)' : 'var(--text-muted)',
                boxShadow: activeMode === 'login' ? 'var(--card-shadow)' : 'none'
              }}
            >
              Sign In to Business
            </button>
            <button
              onClick={() => { setActiveMode('register'); setAuthError(null); }}
              style={{
                flex: 1,
                padding: '9px 12px',
                border: 'none',
                borderRadius: '8px',
                fontSize: '13px',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                backgroundColor: activeMode === 'register' ? 'var(--bg-card)' : 'transparent',
                color: activeMode === 'register' ? 'var(--text-primary)' : 'var(--text-muted)',
                boxShadow: activeMode === 'register' ? 'var(--card-shadow)' : 'none'
              }}
            >
              Register New Business
            </button>
          </div>

          {/* Error Message Banner */}
          {authError && (
            <div style={{
              padding: '12px 14px',
              borderRadius: '8px',
              backgroundColor: 'var(--badge-bg-red)',
              color: 'var(--badge-text-red)',
              fontSize: '13px',
              marginBottom: '20px',
              border: '1px solid rgba(239, 68, 68, 0.25)',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span>⚠️</span>
              <span>{authError}</span>
            </div>
          )}

          {/* ===================== 1. LOGIN FORM ===================== */}
          {activeMode === 'login' && (
            <div>
              <div style={{ marginBottom: '22px' }}>
                <h2 style={{ fontSize: '20px', fontWeight: 700, margin: '0 0 6px 0', color: 'var(--text-primary)' }}>
                  Welcome back, Business Owner
                </h2>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: 0 }}>
                  Enter your credentials to manage your business dashboard
                </p>
              </div>

              {/* Quick Demo Login Card */}
              <div 
                style={{
                  backgroundColor: 'rgba(0, 229, 255, 0.08)',
                  border: '1px solid rgba(0, 229, 255, 0.35)',
                  borderRadius: '12px',
                  padding: '14px 16px',
                  marginBottom: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{
                      width: '24px',
                      height: '24px',
                      borderRadius: '6px',
                      backgroundColor: 'var(--brand-saffron)',
                      color: '#030712',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '12px',
                      fontWeight: 700
                    }}>
                      ⚡
                    </div>
                    <div>
                      <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--brand-saffron)' }}>
                        Instant Demo Account
                      </div>
                      <div style={{ fontSize: '11.5px', color: 'var(--text-secondary)' }}>
                        Rajesh Sharma • Bharat Enterprises (Supermart FMCG)
                      </div>
                    </div>
                  </div>
                  <div style={{
                    fontSize: '11px',
                    padding: '2px 8px',
                    borderRadius: '12px',
                    backgroundColor: 'rgba(0, 229, 255, 0.15)',
                    color: 'var(--brand-saffron)',
                    fontWeight: 600
                  }}>
                    Ready to Test
                  </div>
                </div>

                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  paddingTop: '6px',
                  borderTop: '1px dashed rgba(0, 229, 255, 0.25)'
                }}>
                  <button
                    type="button"
                    onClick={handleDemoLogin}
                    disabled={loginSubmitting}
                    className="btn-primary"
                    style={{
                      flex: 1,
                      padding: '8px 12px',
                      fontSize: '12.5px',
                      justifyContent: 'center',
                      backgroundColor: 'var(--brand-saffron)',
                      borderColor: 'var(--brand-saffron)',
                      color: '#030712',
                      boxShadow: '0 2px 6px rgba(0, 229, 255, 0.3)'
                    }}
                  >
                    {loginSubmitting ? 'Entering Workspace...' : '⚡ 1-Click Demo Login'}
                  </button>
                  <button
                    type="button"
                    onClick={handleFillDemoOnly}
                    style={{
                      padding: '8px 12px',
                      fontSize: '12px',
                      border: '1px solid var(--border-color)',
                      backgroundColor: 'var(--bg-card)',
                      color: 'var(--text-primary)',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      fontWeight: 600,
                      whiteSpace: 'nowrap'
                    }}
                    title="Populate email and password fields"
                  >
                    Autofill Credentials
                  </button>
                </div>
              </div>

              <form onSubmit={handleLoginSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 600, marginBottom: '6px' }}>
                    Email Address
                  </label>
                  <div style={{ position: 'relative' }}>
                    <Mail size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '11px' }} />
                    <input 
                      type="email"
                      required
                      placeholder="owner@yourbusiness.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '10px 12px 10px 38px',
                        borderRadius: '8px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '13.5px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <label style={{ fontSize: '12.5px', fontWeight: 600 }}>
                      Password
                    </label>
                  </div>
                  <div style={{ position: 'relative' }}>
                    <Lock size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '11px' }} />
                    <input 
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '10px 38px 10px 38px',
                        borderRadius: '8px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '13.5px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      style={{
                        position: 'absolute',
                        right: '12px',
                        top: '10px',
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        color: 'var(--text-muted)',
                        padding: 0
                      }}
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loginSubmitting}
                  className="btn-primary"
                  style={{
                    width: '100%',
                    padding: '11px',
                    fontSize: '14px',
                    fontWeight: 600,
                    justifyContent: 'center',
                    marginTop: '8px',
                    boxShadow: '0 2px 6px rgba(15, 23, 42, 0.15)'
                  }}
                >
                  {loginSubmitting ? 'Signing in...' : 'Sign In to Workspace'}
                  {!loginSubmitting && <ArrowRight size={16} style={{ marginLeft: '6px' }} />}
                </button>
              </form>

              <div style={{ marginTop: '20px', textAlign: 'center', fontSize: '13px', color: 'var(--text-muted)' }}>
                Need to set up a new enterprise?{' '}
                <button
                  type="button"
                  onClick={() => { setActiveMode('register'); setAuthError(null); }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--brand-saffron)',
                    fontWeight: 600,
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  Register your business
                </button>
              </div>
            </div>
          )}

          {/* ===================== 2. REGISTER FORM ===================== */}
          {activeMode === 'register' && (
            <div>
              <div style={{ marginBottom: '20px' }}>
                <h2 style={{ fontSize: '20px', fontWeight: 700, margin: '0 0 6px 0', color: 'var(--text-primary)' }}>
                  Create Business Account
                </h2>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: 0 }}>
                  Set up your business workspace with instant AI ledger & inventory
                </p>
              </div>

              <form onSubmit={handleRegisterSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                {/* Section: Owner Info */}
                <div style={{
                  fontSize: '11.5px',
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  color: 'var(--brand-saffron)',
                  paddingBottom: '4px',
                  borderBottom: '1px solid var(--border-color)',
                  marginTop: '4px'
                }}>
                  1. Business Owner Profile
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      Full Name *
                    </label>
                    <div style={{ position: 'relative' }}>
                      <User size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '10px' }} />
                      <input 
                        type="text"
                        required
                        placeholder="e.g. Ramesh Patel"
                        value={regFullName}
                        onChange={(e) => setRegFullName(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '8px 10px 8px 32px',
                          borderRadius: '7px',
                          border: '1px solid var(--border-color)',
                          backgroundColor: 'var(--bg-input)',
                          color: 'var(--text-primary)',
                          fontSize: '13px',
                          outline: 'none',
                          boxSizing: 'border-box'
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      Email Address *
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Mail size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '10px' }} />
                      <input 
                        type="email"
                        required
                        placeholder="ramesh@pateltraders.com"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '8px 10px 8px 32px',
                          borderRadius: '7px',
                          border: '1px solid var(--border-color)',
                          backgroundColor: 'var(--bg-input)',
                          color: 'var(--text-primary)',
                          fontSize: '13px',
                          outline: 'none',
                          boxSizing: 'border-box'
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                    Password (min. 6 characters) *
                  </label>
                  <div style={{ position: 'relative' }}>
                    <Lock size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '10px' }} />
                    <input 
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Create a strong password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 34px 8px 32px',
                        borderRadius: '7px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '13px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      style={{
                        position: 'absolute',
                        right: '10px',
                        top: '9px',
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        color: 'var(--text-muted)',
                        padding: 0
                      }}
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* Section: Business Details */}
                <div style={{
                  fontSize: '11.5px',
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  color: 'var(--brand-saffron)',
                  paddingBottom: '4px',
                  borderBottom: '1px solid var(--border-color)',
                  marginTop: '8px'
                }}>
                  2. Business Information
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                    Business / Enterprise Name *
                  </label>
                  <div style={{ position: 'relative' }}>
                    <Store size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '10px' }} />
                    <input 
                      type="text"
                      required
                      placeholder="e.g. Patel Traders & Supermarket"
                      value={regBusinessName}
                      onChange={(e) => setRegBusinessName(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 10px 8px 32px',
                        borderRadius: '7px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '13px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      Industry / Category
                    </label>
                    <select
                      value={regBusinessType}
                      onChange={(e) => setRegBusinessType(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 10px',
                        borderRadius: '7px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '12.5px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    >
                      {BUSINESS_CATEGORIES.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      City / Mandi Location
                    </label>
                    <div style={{ position: 'relative' }}>
                      <MapPin size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '10px' }} />
                      <input 
                        type="text"
                        placeholder="e.g. Surat, Gujarat"
                        value={regLocation}
                        onChange={(e) => setRegLocation(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '8px 10px 8px 32px',
                          borderRadius: '7px',
                          border: '1px solid var(--border-color)',
                          backgroundColor: 'var(--bg-input)',
                          color: 'var(--text-primary)',
                          fontSize: '13px',
                          outline: 'none',
                          boxSizing: 'border-box'
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      GSTIN (Optional)
                    </label>
                    <input 
                      type="text"
                      placeholder="e.g. 24AAAAA0000A1Z5"
                      value={regGstin}
                      onChange={(e) => setRegGstin(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 10px',
                        borderRadius: '7px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '12.5px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '5px' }}>
                      UPI ID for Khata (Optional)
                    </label>
                    <input 
                      type="text"
                      placeholder="pateltraders@upi"
                      value={regUpiId}
                      onChange={(e) => setRegUpiId(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 10px',
                        borderRadius: '7px',
                        border: '1px solid var(--border-color)',
                        backgroundColor: 'var(--bg-input)',
                        color: 'var(--text-primary)',
                        fontSize: '12.5px',
                        outline: 'none',
                        boxSizing: 'border-box'
                      }}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={regSubmitting}
                  className="btn-primary"
                  style={{
                    width: '100%',
                    padding: '11px',
                    fontSize: '14px',
                    fontWeight: 600,
                    justifyContent: 'center',
                    marginTop: '10px',
                    backgroundColor: 'var(--brand-saffron)',
                    borderColor: 'var(--brand-saffron)',
                    color: '#030712',
                    boxShadow: '0 2px 8px rgba(0, 229, 255, 0.25)'
                  }}
                >
                  {regSubmitting ? 'Provisioning Business...' : 'Create Business & Launch Workspace'}
                  {!regSubmitting && <CheckCircle2 size={16} style={{ marginLeft: '6px' }} />}
                </button>
              </form>

              <div style={{ marginTop: '18px', textAlign: 'center', fontSize: '13px', color: 'var(--text-muted)' }}>
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => { setActiveMode('login'); setAuthError(null); }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--brand-saffron)',
                    fontWeight: 600,
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  Sign in here
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
