import React, { useState } from 'react';
import { 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  DollarSign, 
  Award, 
  CheckCircle2, 
  ArrowRight, 
  PieChart, 
  Sparkles, 
  Layers, 
  Bot, 
  MessageSquare, 
  Flame,
  ChevronRight,
  ExternalLink
} from 'lucide-react';

export const PitchDeckView = ({ onNavigateTab, onOpenSandbox }) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    { id: 'overview', title: '1. Executive Summary', tag: 'The Opportunity' },
    { id: 'problem', title: '2. The Market Problem', tag: 'Pain Points' },
    { id: 'solution', title: '3. Solution & Moat', tag: 'VyaparAI OS' },
    { id: 'tam', title: '4. Market Size (TAM)', tag: '$12B Industry' },
    { id: 'business-model', title: '5. Monetization', tag: 'Revenue Streams' },
    { id: 'unit-economics', title: '6. Unit Economics', tag: '26x LTV:CAC' },
    { id: 'traction', title: '7. Pilot Traction', tag: 'Proof of Concept' },
    { id: 'roadmap', title: '8. Growth & Moat', tag: 'Next 18 Months' }
  ];

  return (
    <div className="page-container" style={{ maxWidth: '1280px', margin: '0 auto', paddingBottom: '60px' }}>
      {/* Top Pitch Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px',
        padding: '16px 20px',
        borderRadius: '12px',
        backgroundColor: 'var(--bg-card)',
        border: '1px solid var(--border-color)',
        boxShadow: 'var(--card-shadow)',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '38px',
            height: '38px',
            borderRadius: '10px',
            backgroundColor: 'var(--brand-saffron)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#030712',
            fontWeight: 800,
            fontSize: '18px',
            boxShadow: '0 4px 10px rgba(0, 229, 255, 0.3)'
          }}>
            🚀
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '18px', fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>
                VyaparAI OS — Investor Pitch & Business Model
              </h1>
              <span style={{
                fontSize: '11px',
                fontWeight: 700,
                padding: '2px 8px',
                borderRadius: '12px',
                backgroundColor: 'rgba(0, 229, 255, 0.15)',
                color: 'var(--brand-saffron)',
                textTransform: 'uppercase'
              }}>
                Pitch Mode
              </span>
            </div>
            <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: '2px 0 0 0' }}>
              AI Operating System for 63 Million Indian MSMEs • B2B SaaS + Fintech Take-Rate Model
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            onClick={() => onOpenSandbox && onOpenSandbox()}
            className="btn-secondary"
            style={{
              padding: '7px 14px',
              fontSize: '12.5px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              borderColor: 'var(--brand-green)',
              color: 'var(--brand-green)',
              backgroundColor: 'var(--badge-bg-green)'
            }}
          >
            <Zap size={15} />
            <span>Test Drive Sandbox</span>
          </button>
          <button
            onClick={() => onNavigateTab && onNavigateTab('command-center')}
            className="btn-primary"
            style={{ padding: '7px 14px', fontSize: '12.5px' }}
          >
            <span>Live Product Demo</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Slide Navigation Tabs */}
      <div style={{
        display: 'flex',
        gap: '6px',
        overflowX: 'auto',
        paddingBottom: '12px',
        marginBottom: '16px'
      }}>
        {slides.map((s, idx) => (
          <button
            key={s.id}
            onClick={() => setActiveSlide(idx)}
            style={{
              padding: '8px 14px',
              borderRadius: '8px',
              border: activeSlide === idx ? '1px solid var(--brand-saffron)' : '1px solid var(--border-color)',
              backgroundColor: activeSlide === idx ? 'rgba(0, 229, 255, 0.12)' : 'var(--bg-card)',
              color: activeSlide === idx ? 'var(--brand-saffron)' : 'var(--text-secondary)',
              fontSize: '12.5px',
              fontWeight: activeSlide === idx ? 700 : 500,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              transition: 'all 0.15s ease',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              minWidth: '130px'
            }}
          >
            <span style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>{s.tag}</span>
            <span>{s.title}</span>
          </button>
        ))}
      </div>

      {/* Main Slide Presentation Canvas */}
      <div style={{
        backgroundColor: 'var(--bg-card)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        borderRadius: '18px',
        border: '1px solid var(--border-color)',
        borderTop: '3px solid var(--brand-saffron)',
        boxShadow: 'var(--elevated-shadow), 0 0 35px rgba(0, 229, 255, 0.08)',
        padding: '38px 38px',
        minHeight: '520px',
        position: 'relative'
      }}>

        {/* SLIDE 0: EXECUTIVE SUMMARY */}
        {activeSlide === 0 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'rgba(0, 229, 255, 0.12)', color: 'var(--brand-saffron)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <Sparkles size={13} />
              <span>THE BIG PICTURE</span>
            </div>
            <h2 style={{ fontSize: '28px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0', letterSpacing: '-0.5px' }}>
              The AI Operating System for Bharat’s 63 Million SMB Merchants
            </h2>
            <p style={{ fontSize: '15px', color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: '850px', marginBottom: '32px' }}>
              Indian SMB retailers & wholesalers represent a <strong>$12 Billion annual software & digital finance opportunity</strong>. While legacy software like Tally or Marg acts as passive desktop ledgers, <strong>VyaparAI OS</strong> is an active, autonomous platform that <strong>collects overdue credit over WhatsApp</strong>, <strong>predicts inventory stockouts</strong>, and <strong>optimizes profit margins</strong>.
            </p>

            {/* 3 Core Highlight Pillars */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px', marginBottom: '32px' }}>
              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-amber)', color: 'var(--badge-text-amber)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
                  <TrendingUp size={20} />
                </div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, margin: '0 0 6px 0' }}>₹8.5 Lakh Crore Trapped</h3>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Informal customer credit (Udhar) delays cash flow by 38+ days. VyaparAI recovers it autonomously via automated WhatsApp collections.
                </p>
              </div>

              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(37, 99, 235, 0.12)', color: 'var(--brand-blue)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
                  <Bot size={20} />
                </div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, margin: '0 0 6px 0' }}>Autonomous AI Co-Pilot</h3>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Bilingual AI Advisor detects dead stock, calculates GST liabilities in real time, and negotiates bulk supplier purchase orders.
                </p>
              </div>

              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--brand-green)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
                  <DollarSign size={20} />
                </div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, margin: '0 0 6px 0' }}>SaaS + Take-Rate Engine</h3>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  High-margin subscription tiers (₹999 - ₹2,499/mo) with negative net churn and embedded UPI invoice collection take-rates (0.3%).
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                Targeting 50,000 paid merchants across 40 wholesale Mandi hubs in Phase 1.
              </div>
              <button onClick={() => setActiveSlide(1)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: The Market Problem</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 1: THE MARKET PROBLEM */}
        {activeSlide === 1 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'var(--badge-bg-red)', color: 'var(--badge-text-red)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <span>THE PAIN POINT</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              Why Indian SMBs Lose Millions in Working Capital Every Month
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px', maxWidth: '800px' }}>
              Indian merchants are forced to juggle manual desktop software, paper Bahi-Khatas, and ad-hoc WhatsApp calls. This fragmentation directly causes:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '18px', marginBottom: '32px' }}>
              <div style={{ padding: '20px', borderRadius: '12px', border: '1px solid rgba(239, 68, 68, 0.25)', backgroundColor: 'var(--badge-bg-red)' }}>
                <div style={{ fontSize: '28px', fontWeight: 800, color: 'var(--badge-text-red)', marginBottom: '4px' }}>42 Days</div>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '6px' }}>Average Udhar Delay</div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0 }}>
                  Store owners feel awkward asking for money manually. Result: 18-24% of store receivables turn into bad debt or write-offs.
                </p>
              </div>

              <div style={{ padding: '20px', borderRadius: '12px', border: '1px solid rgba(245, 158, 11, 0.25)', backgroundColor: 'var(--badge-bg-amber)' }}>
                <div style={{ fontSize: '28px', fontWeight: 800, color: 'var(--badge-text-amber)', marginBottom: '4px' }}>18% GMV</div>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '6px' }}>Lost to Stockouts</div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0 }}>
                  Merchants order inventory based on "gut feeling". Fast-moving SKUs run out, while slow-moving capital remains stuck in dead inventory.
                </p>
              </div>

              <div style={{ padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-card-subtle)' }}>
                <div style={{ fontSize: '28px', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '4px' }}>4.5 Hours/Day</div>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '6px' }}>Wasted in Manual Reconciliation</div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0 }}>
                  Reconciling paper ledgers, calculating GST slabs, sending individual bank account numbers, and cross-checking daily cash drawers.
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(0)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(2)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: The Solution</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 2: THE SOLUTION & MOAT */}
        {activeSlide === 2 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--brand-green)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <CheckCircle2 size={13} />
              <span>THE VYAPARAI SOLUTION</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              A Unified Operating System That Drives Measurable ROI
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px', maxWidth: '850px' }}>
              We replace 4 fragmented tools with an intelligent, self-driving platform:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px', marginBottom: '32px' }}>
              <div style={{ padding: '18px', borderRadius: '10px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <MessageSquare size={18} color="var(--brand-green)" />
                  <span style={{ fontWeight: 700, fontSize: '14px' }}>Auto-Khata & 1-Click WhatsApp</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Dispatches polite, bilingual WhatsApp ledger summaries with integrated UPI QR handles. Recovers overdue payments 3.5x faster without awkward confrontations.
                </p>
              </div>

              <div style={{ padding: '18px', borderRadius: '10px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <Layers size={18} color="var(--brand-saffron)" />
                  <span style={{ fontWeight: 700, fontSize: '14px' }}>Predictive Stock Buffer Engine</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Monitors SKU run-rates and reorder thresholds. Automatically formats purchase orders for wholesale mandi suppliers before stockouts happen.
                </p>
              </div>

              <div style={{ padding: '18px', borderRadius: '10px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <Bot size={18} color="var(--brand-blue)" />
                  <span style={{ fontWeight: 700, fontSize: '14px' }}>Deep-Insight AI Business Advisor</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Answers natural language queries: "Why did my edible oil profit drop this month?", "Which 5 customers have the highest credit risk?".
                </p>
              </div>

              <div style={{ padding: '18px', borderRadius: '10px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                  <ShieldCheck size={18} color="var(--brand-purple)" />
                  <span style={{ fontWeight: 700, fontSize: '14px' }}>Zero-Friction Excel/CSV Parser</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Ingests messy supplier spreadsheets, Tally exports, or billing machine CSVs with 1 click, automatic header detection, and schema repair.
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(1)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(3)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: Market Opportunity (TAM)</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 3: MARKET SIZE (TAM / SAM / SOM) */}
        {activeSlide === 3 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'rgba(37, 99, 235, 0.12)', color: 'var(--brand-blue)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <PieChart size={13} />
              <span>MARKET SIZING</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              $12 Billion Total Addressable Market in India
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px' }}>
              India has the highest density of retail shops in the world, rapidly adopting digital payments (UPI) and cloud billing.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '32px' }}>
              <div style={{ padding: '24px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-blue)', textTransform: 'uppercase', marginBottom: '8px' }}>
                  TAM (Total Addressable)
                </div>
                <div style={{ fontSize: '36px', fontWeight: 900, color: 'var(--text-primary)', marginBottom: '6px' }}>$12.4 B</div>
                <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '8px' }}>63 Million MSMEs</div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>
                  Total software, cloud ledger, and digital workflow spend potential across Indian retailers and wholesalers.
                </p>
              </div>

              <div style={{ padding: '24px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--brand-saffron)', textAlign: 'center' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-saffron)', textTransform: 'uppercase', marginBottom: '8px' }}>
                  SAM (Serviceable Addressable)
                </div>
                <div style={{ fontSize: '36px', fontWeight: 900, color: 'var(--brand-saffron)', marginBottom: '6px' }}>$2.8 B</div>
                <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '8px' }}>14 Million High-GMV Merchants</div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>
                  Kiranas, supermarkets, FMCG wholesalers, apparel, and hardware stores doing ₹25L to ₹5 Cr annual turnover.
                </p>
              </div>

              <div style={{ padding: '24px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-green)', textTransform: 'uppercase', marginBottom: '8px' }}>
                  SOM (Initial 3-Year Target)
                </div>
                <div style={{ fontSize: '36px', fontWeight: 900, color: 'var(--brand-green)', marginBottom: '6px' }}>$420 M</div>
                <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '8px' }}>250,000 Paid Merchants</div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>
                  Top 40 Tier-1 and Tier-2 wholesale clusters (Delhi NCR, Surat, Ahmedabad, Jaipur, Indore, Pune, Bengaluru).
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(2)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(4)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: Business Model & Monetization</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 4: BUSINESS MODEL & MONETIZATION */}
        {activeSlide === 4 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'rgba(16, 185, 129, 0.12)', color: 'var(--brand-green)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <DollarSign size={13} />
              <span>MONETIZATION ARCHITECTURE</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              Dual-Engine Revenue: High-Margin SaaS + Fintech Take-Rate
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px' }}>
              We capture value at both the software tier and the settlement flow:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '18px', marginBottom: '28px' }}>
              {/* Starter */}
              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Vyapar Starter</div>
                <div style={{ fontSize: '28px', fontWeight: 900, color: 'var(--text-primary)', margin: '6px 0' }}>Free Forever</div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '14px' }}>Acquisition hook for small single-counter shops</p>
                <ul style={{ fontSize: '12.5px', color: 'var(--text-secondary)', paddingLeft: '18px', margin: 0, lineHeight: 1.6 }}>
                  <li>Up to 50 sales entries/month</li>
                  <li>Basic manual Khata</li>
                  <li>Single user access</li>
                </ul>
              </div>

              {/* Pro Growth */}
              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '2px solid var(--brand-saffron)', position: 'relative' }}>
                <div style={{ position: 'absolute', top: '-10px', right: '14px', padding: '2px 8px', borderRadius: '10px', backgroundColor: 'var(--brand-saffron)', color: '#fff', fontSize: '10px', fontWeight: 700 }}>
                  CORE REVENUE (82%)
                </div>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-saffron)', textTransform: 'uppercase' }}>Vyapar Pro</div>
                <div style={{ fontSize: '28px', fontWeight: 900, color: 'var(--text-primary)', margin: '6px 0' }}>
                  ₹999 <span style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-muted)' }}>/month</span>
                </div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '14px' }}>For established Kirana, FMCG, & retail stores</p>
                <ul style={{ fontSize: '12.5px', color: 'var(--text-secondary)', paddingLeft: '18px', margin: 0, lineHeight: 1.6 }}>
                  <li>Unlimited automated WhatsApp reminders</li>
                  <li>AI Inventory forecasting & purchase orders</li>
                  <li>Dead stock liquidation alerts</li>
                  <li>Export GST ready reports</li>
                </ul>
              </div>

              {/* Enterprise */}
              <div style={{ padding: '20px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-purple)', textTransform: 'uppercase' }}>Enterprise Multi-Store</div>
                <div style={{ fontSize: '28px', fontWeight: 900, color: 'var(--text-primary)', margin: '6px 0' }}>
                  ₹2,499 <span style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-muted)' }}>/month</span>
                </div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '14px' }}>For multi-branch mandi wholesalers & agencies</p>
                <ul style={{ fontSize: '12.5px', color: 'var(--text-secondary)', paddingLeft: '18px', margin: 0, lineHeight: 1.6 }}>
                  <li>Multi-branch & warehouse sync</li>
                  <li>Dedicated account manager & audit logs</li>
                  <li>Automated supplier credit reconciliation</li>
                  <li>Custom ERP / Tally API integrations</li>
                </ul>
              </div>
            </div>

            {/* Secondary Fintech Stream */}
            <div style={{ padding: '14px 18px', borderRadius: '10px', backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px dashed var(--brand-green)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ padding: '6px', borderRadius: '6px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--brand-green)' }}>
                  <Zap size={16} />
                </div>
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--brand-green)' }}>
                    Fintech Upsell: 0.30% Payment Settlement Take-Rate
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                    When debtors clear overdue balance via WhatsApp-embedded dynamic UPI intents, VyaparAI captures 30 bps payment facilitation fee.
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(3)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(5)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: Unit Economics</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 5: UNIT ECONOMICS */}
        {activeSlide === 5 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'rgba(0, 229, 255, 0.12)', color: 'var(--brand-saffron)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <Award size={13} />
              <span>SAAS UNIT ECONOMICS</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              World-Class SaaS Metrics: 26.6x LTV:CAC with 1.8 Month Payback
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px' }}>
              Based on validated acquisition loops via Mandi field agents and merchant WhatsApp referrals:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '32px' }}>
              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Blended CAC</div>
                <div style={{ fontSize: '30px', fontWeight: 900, color: 'var(--text-primary)', margin: '6px 0' }}>₹1,200</div>
                <div style={{ fontSize: '11.5px', color: 'var(--brand-green)', fontWeight: 600 }}>~$14.50 per merchant</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Annual ARPU</div>
                <div style={{ fontSize: '30px', fontWeight: 900, color: 'var(--brand-saffron)', margin: '6px 0' }}>₹11,988</div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>₹999 / mo average</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Merchant LTV</div>
                <div style={{ fontSize: '30px', fontWeight: 900, color: 'var(--brand-green)', margin: '6px 0' }}>₹32,000</div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>32-month avg lifetime</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>LTV / CAC Ratio</div>
                <div style={{ fontSize: '30px', fontWeight: 900, color: 'var(--brand-blue)', margin: '6px 0' }}>26.6x</div>
                <div style={{ fontSize: '11.5px', color: 'var(--brand-green)', fontWeight: 600 }}>Top 1% Global SaaS</div>
              </div>
            </div>

            {/* Additional operational KPIs */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '28px' }}>
              <div style={{ padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>CAC Payback Period:</span>
                <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--brand-green)' }}>1.8 Months</span>
              </div>
              <div style={{ padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Gross Margins:</span>
                <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>86.4%</span>
              </div>
              <div style={{ padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>Monthly Logo Churn:</span>
                <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--brand-green)' }}>&lt; 1.8%</span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(4)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(6)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: Pilot Traction</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 6: PILOT TRACTION & PROOF OF CONCEPT */}
        {activeSlide === 6 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--brand-green)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <Flame size={13} />
              <span>MARKET PROOF OF CONCEPT</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              Pilot Traction: 5 Live Stores in Delhi NCR Mandis
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px' }}>
              Tested on real business datasets spanning Kirana retail, Edible Oils distribution, and Sweet house catering supplies:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '28px' }}>
              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontWeight: 600 }}>Total Invoiced GMV</div>
                <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--brand-saffron)', margin: '4px 0' }}>₹1.42 Cr</div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>processed in pilot period</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontWeight: 600 }}>Udhar Recovery Rate</div>
                <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--brand-green)', margin: '4px 0' }}>94.2%</div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>within 14 days of WhatsApp alert</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontWeight: 600 }}>Average Recovery Time</div>
                <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--brand-blue)', margin: '4px 0' }}>6.2 Days</div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>down from 38 days prior</div>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontWeight: 600 }}>Merchant Net ROI</div>
                <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--brand-purple)', margin: '4px 0' }}>4.8x</div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>subscription cost recovered</div>
              </div>
            </div>

            {/* Testimonial Quote */}
            <div style={{ padding: '18px 24px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', borderLeft: '4px solid var(--brand-saffron)', marginBottom: '24px' }}>
              <p style={{ fontSize: '14px', fontStyle: 'italic', color: 'var(--text-primary)', margin: '0 0 8px 0', lineHeight: 1.6 }}>
                "Earlier, I spent 2 hours every evening looking at paper register notes and feeling hesitated to call customers for overdue money. With VyaparAI’s polite WhatsApp reminders, Sharmaji Caterers cleared ₹24,500 the very next morning on UPI."
              </p>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-primary)' }}>
                — Rajesh Sharma, Proprietor, Bharat Enterprises (Chandni Chowk Mandi, Delhi)
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(5)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => setActiveSlide(7)} className="btn-primary" style={{ padding: '8px 18px' }}>
                <span>Next: Competitive Moat & Roadmap</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 7: COMPETITIVE MOAT & ROADMAP */}
        {activeSlide === 7 && (
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '14px', backgroundColor: 'rgba(139, 92, 246, 0.12)', color: 'var(--brand-purple)', fontSize: '12px', fontWeight: 700, marginBottom: '14px' }}>
              <ShieldCheck size={13} />
              <span>DEFENSIBILITY & ROADMAP</span>
            </div>
            <h2 style={{ fontSize: '26px', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 12px 0' }}>
              Our Competitive Moat & 18-Month Scaling Roadmap
            </h2>
            <p style={{ fontSize: '14.5px', color: 'var(--text-secondary)', marginBottom: '28px' }}>
              Why legacy ERPs (Tally, Busy, Marg) cannot easily replicate our velocity:
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '18px', marginBottom: '32px' }}>
              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 700, margin: '0 0 6px 0', color: 'var(--brand-saffron)' }}>
                  1. Deep Multi-Modal WhatsApp AI
                </h4>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Merchants interact via natural voice notes in Hindi/English. We don't ask merchants to learn new complex desktop software.
                </p>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 700, margin: '0 0 6px 0', color: 'var(--brand-green)' }}>
                  2. Proprietary Mandi SKU Intelligence
                </h4>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Catalog knowledge of 40,000+ Indian FMCG barcodes, edible oil brands, grain mandi price fluctuations, and reorder dynamics.
                </p>
              </div>

              <div style={{ padding: '18px', borderRadius: '12px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)' }}>
                <h4 style={{ fontSize: '14px', fontWeight: 700, margin: '0 0 6px 0', color: 'var(--brand-blue)' }}>
                  3. Zero-Friction Data Migration
                </h4>
                <p style={{ fontSize: '12.5px', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                  Our automated parser imports any legacy Excel/CSV in under 30 seconds with automatic schema mapping and error correction.
                </p>
              </div>
            </div>

            {/* Next Milestone Box */}
            <div style={{ padding: '18px 20px', borderRadius: '12px', backgroundColor: 'rgba(0, 229, 255, 0.08)', border: '1px solid rgba(0, 229, 255, 0.3)', marginBottom: '24px' }}>
              <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--brand-saffron)', marginBottom: '4px' }}>
                🎯 Seed Capital Objectives ($500K - $1M Round):
              </div>
              <div style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                • Expand sales cluster teams across 15 wholesale Mandis (Delhi NCR, Ahmedabad, Jaipur, Indore)<br/>
                • Launch WhatsApp voice conversational agent for rural merchant onboarding<br/>
                • Scale to 12,000 paid stores hitting ₹1.2 Cr ($145K) Monthly Recurring Revenue (MRR).
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
              <button onClick={() => setActiveSlide(6)} className="btn-secondary" style={{ padding: '8px 16px' }}>Previous</button>
              <button onClick={() => onNavigateTab && onNavigateTab('command-center')} className="btn-primary" style={{ padding: '8px 20px', backgroundColor: 'var(--brand-saffron)', borderColor: 'var(--brand-saffron)' }}>
                <span>Launch Live Product Demo</span>
                <ExternalLink size={15} style={{ marginLeft: '6px' }} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
