import React, { useState } from 'react';
import { 
  Flame, 
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

export const ForecastsView = () => {
  const [activeSurge, setActiveSurge] = useState('diwali');

  const surgeProfiles = {
    baseline: { name: 'Normal Baseline', multiplier: 1.0, icon: '📊', bump: '+0%' },
    diwali: { name: 'Diwali & Dhanteras Festive Surge', multiplier: 1.55, icon: '🪔', bump: '+55%' },
    wedding: { name: 'Winter Wedding Season', multiplier: 1.45, icon: '💍', bump: '+45%' },
    monthend: { name: 'Month-End Payday Bump', multiplier: 1.20, icon: '💳', bump: '+20%' }
  };

  const curr = surgeProfiles[activeSurge];

  const forecastData = Array.from({ length: 30 }).map((_, i) => ({
    day: `Day ${i + 1}`,
    projectedSales: Math.round((82000 + (Math.sin(i / 2) * 15000)) * curr.multiplier)
  }));

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Forecasts</h1>
          <p className="page-subtitle">Predictive demand planning, cash flow forecasting, and Indian festival surge simulations.</p>
        </div>
      </div>

      {/* Surge Toggles */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
          <Flame size={18} color="var(--brand-saffron)" />
          <span style={{ fontSize: '14px', fontWeight: 700 }}>Select Demand Multiplier Scenario:</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
          {Object.entries(surgeProfiles).map(([key, item]) => (
            <div
              key={key}
              onClick={() => setActiveSurge(key)}
              style={{
                backgroundColor: activeSurge === key ? 'var(--accent-primary)' : 'var(--bg-card)',
                color: activeSurge === key ? 'var(--accent-primary-text)' : 'var(--text-primary)',
                border: `1px solid ${activeSurge === key ? 'transparent' : 'var(--border-color)'}`,
                borderRadius: '10px',
                padding: '12px',
                cursor: 'pointer'
              }}
            >
              <div style={{ fontSize: '18px', marginBottom: '4px' }}>{item.icon}</div>
              <div style={{ fontSize: '13px', fontWeight: 700 }}>{item.name}</div>
              <div style={{ fontSize: '11.5px', marginTop: '4px', color: activeSurge === key ? 'rgba(255, 255, 255, 0.8)' : 'var(--brand-green)', fontWeight: 600 }}>
                {item.bump} Surge
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Forecast Graph */}
      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">30-Day Forward Sales Projection</h2>
            <p className="card-subheading">Estimated daily turnover factoring {curr.name}</p>
          </div>
        </div>

        <div style={{ width: '100%', height: 320 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={forecastData}>
              <defs>
                <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00e5ff" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#00e5ff" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="var(--text-muted)" fontSize={11} interval={3} />
              <YAxis stroke="var(--text-muted)" fontSize={11} tickFormatter={(v) => `₹${Math.round(v / 1000)}k`} />
              <Tooltip formatter={(v) => [`₹${v.toLocaleString('en-IN')}`, 'Projected Demand']} />
              <Area type="monotone" dataKey="projectedSales" stroke="#00e5ff" fillOpacity={1} fill="url(#forecastGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
