import React, { useState } from 'react';
import { 
  MessageCircle, 
  Search,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  CreditCard,
  X,
  IndianRupee
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDataStore } from '../context/DataStore';
import { downloadSchemaTemplate } from '../services/importEngine';
import { DATASET_TYPES } from '../data/schemas';

export const PaymentsView = ({ onOpenWhatsApp, onShowToast }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [agingFilter, setAgingFilter] = useState('all'); // 'all' | 'high-val' | 'urgent'
  const [paymentModalCustomer, setPaymentModalCustomer] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [paymentNotes, setPaymentNotes] = useState('');
  
  const { customers, derivedKPIs, recordCustomerPayment } = useDataStore();

  // Filter customers with pending dues
  const debtors = customers.filter(c => Number(c.amountDue) > 0);
  
  const filteredDebtors = debtors.filter(d => {
    const matchesSearch = 
      (d.customerName && d.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (d.phone && d.phone.includes(searchTerm));
    if (!matchesSearch) return false;

    const due = Number(d.amountDue) || 0;
    const days = d.overdueDays || 14;

    if (agingFilter === 'high-val') return due >= 20000;
    if (agingFilter === 'urgent') return days >= 21;
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Party Name', 'Phone', 'Pending Udhar', 'Total Purchases', 'Amount Paid', 'Due Date'];
    const rows = filteredDebtors.map(d => [
      `"${d.customerName || d.name || ''}"`,
      `"${d.phone || ''}"`,
      d.amountDue || 0,
      d.totalPurchases || 0,
      d.amountPaid || 0,
      `"${d.dueDate || 'Immediate'}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `udhar_debtors_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleOpenRecordPayment = (debtor) => {
    setPaymentModalCustomer(debtor);
    setPaymentAmount(debtor.amountDue || '');
    setPaymentMethod('UPI');
    setPaymentNotes('');
  };

  const handleConfirmPayment = (e) => {
    e.preventDefault();
    if (!paymentModalCustomer) return;
    const amountNum = parseFloat(paymentAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      if (onShowToast) {
        onShowToast({ message: 'Please enter a valid positive payment amount.', type: 'error' });
      }
      return;
    }

    recordCustomerPayment(paymentModalCustomer.customerName, amountNum);
    confetti({ particleCount: 80, spread: 60, origin: { y: 0.7 } });
    if (onShowToast) {
      onShowToast({
        message: `₹${amountNum.toLocaleString('en-IN')} payment recorded for ${paymentModalCustomer.customerName}! Khata ledger updated.`,
        type: 'success'
      });
    }
    setPaymentModalCustomer(null);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Payments & Khata</h1>
          <p className="page-subtitle">Track outstanding credit (Udhar), payment collections, aging buckets, and WhatsApp reminders.</p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-secondary" 
            onClick={handleExportCSV}
            style={{ fontSize: '13px' }}
            title="Export debtors ledger as CSV"
          >
            <FileSpreadsheet size={14} />
            <span>Export CSV</span>
          </button>

          <button 
            className="btn-secondary" 
            onClick={() => downloadSchemaTemplate(DATASET_TYPES.CUSTOMERS)}
            style={{ fontSize: '13px' }}
          >
            <Download size={14} />
            <span>Download Template</span>
          </button>

          {debtors.length > 0 && (
            <button 
              className="btn-whatsapp"
              onClick={() => onOpenWhatsApp && onOpenWhatsApp({ 
                name: debtors[0].customerName, 
                phone: debtors[0].phone || '+91 98000 00000', 
                pendingAmount: Number(debtors[0].amountDue), 
                overdueDays: 21 
              })}
              style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '8px 16px', borderRadius: '8px', fontWeight: 600 }}
            >
              <MessageCircle size={16} />
              <span>Send Batch Reminders</span>
            </button>
          )}
        </div>
      </div>

      {/* Aging Buckets */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <span className="kpi-title">Total Pending Udhar</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: '#ef4444' }}>
            {derivedKPIs.outstandingPayments.formatted}
          </div>
          <div className="kpi-trend negative">Across {debtors.length} parties</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">High Priority Accounts (&gt;₹20k)</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: '#ef4444' }}>
            {debtors.filter(d => Number(d.amountDue) >= 20000).length} Accounts
          </div>
          <div className="kpi-trend negative">Focus recovery</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Total Paid / Cleared</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: 'var(--brand-green)' }}>
            ₹{customers.reduce((sum, c) => sum + (Number(c.amountPaid) || 0), 0).toLocaleString('en-IN')}
          </div>
          <div className="kpi-trend positive">Settled payments</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Accounts in Good Standing</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>
            {customers.filter(c => Number(c.amountDue) === 0).length} Parties
          </div>
          <div className="kpi-trend positive">Zero balance</div>
        </div>
      </div>

      {/* Debtors Ledger */}
      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Outstanding Credit (Udhar) Ledger ({filteredDebtors.length} Debtors)</h2>
            <p className="card-subheading">Active receivables with direct collection recording & WhatsApp triggers</p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <div className="tabs-navigation-bar">
              <button 
                className={`tab-nav-btn ${agingFilter === 'all' ? 'active' : ''}`}
                onClick={() => setAgingFilter('all')}
              >
                All Debtors ({debtors.length})
              </button>
              <button 
                className={`tab-nav-btn ${agingFilter === 'high-val' ? 'active' : ''}`}
                onClick={() => setAgingFilter('high-val')}
              >
                &gt;₹20,000 ({debtors.filter(d => Number(d.amountDue) >= 20000).length})
              </button>
              <button 
                className={`tab-nav-btn ${agingFilter === 'urgent' ? 'active' : ''}`}
                onClick={() => setAgingFilter('urgent')}
              >
                Overdue &gt;21d ({debtors.filter(d => (d.overdueDays || 14) >= 21).length})
              </button>
            </div>

            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
              <input 
                type="text" 
                placeholder="Search debtor or phone..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)}
                className="ai-input" 
                style={{ paddingLeft: '32px', fontSize: '13px' }} 
              />
            </div>
          </div>
        </div>

        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Phone</th>
                <th>Pending Amount (Udhar)</th>
                <th>Total Purchases</th>
                <th>Amount Paid</th>
                <th>Due Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredDebtors.map((d, idx) => {
                const due = Number(d.amountDue) || 0;
                return (
                  <tr key={idx}>
                    <td><strong>{d.customerName}</strong></td>
                    <td>{d.phone || '—'}</td>
                    <td>
                      <strong style={{ fontSize: '14.5px', color: '#ef4444' }}>
                        ₹{due.toLocaleString('en-IN')}
                      </strong>
                    </td>
                    <td>₹{Number(d.totalPurchases || 0).toLocaleString('en-IN')}</td>
                    <td>
                      <span style={{ color: 'var(--brand-green)', fontWeight: 600 }}>
                        ₹{Number(d.amountPaid || 0).toLocaleString('en-IN')}
                      </span>
                    </td>
                    <td>{d.dueDate || 'Immediate'}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <button 
                          className="btn-primary" 
                          style={{ padding: '4px 10px', fontSize: '12px', borderRadius: '6px', display: 'inline-flex', alignItems: 'center', gap: '5px' }}
                          onClick={() => handleOpenRecordPayment(d)}
                        >
                          <CreditCard size={13} />
                          <span>Record Payment</span>
                        </button>
                        <button 
                          className="btn-whatsapp" 
                          style={{ padding: '4px 10px', fontSize: '12px', borderRadius: '6px' }}
                          onClick={() => onOpenWhatsApp && onOpenWhatsApp({ 
                            name: d.customerName, 
                            phone: d.phone || '+91 98000 00000', 
                            pendingAmount: due, 
                            overdueDays: d.overdueDays || 21 
                          })}
                        >
                          <MessageCircle size={13} />
                          <span>WhatsApp</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {paymentModalCustomer && (
        <div className="modal-overlay" onClick={() => setPaymentModalCustomer(null)}>
          <div className="modal-container" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '460px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ 
                  width: '36px', 
                  height: '36px', 
                  borderRadius: '10px', 
                  background: 'rgba(16, 185, 129, 0.15)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  color: 'var(--brand-green)'
                }}>
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h3 className="modal-title">Record Khata Payment</h3>
                  <p className="modal-subtitle" style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                    Customer: <strong style={{ color: 'var(--brand-cyan)' }}>{paymentModalCustomer.customerName}</strong>
                  </p>
                </div>
              </div>
              <button className="modal-close-btn" onClick={() => setPaymentModalCustomer(null)}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleConfirmPayment}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px 24px' }}>
                <div style={{ 
                  padding: '12px 16px', 
                  background: 'rgba(239, 68, 68, 0.08)', 
                  border: '1px solid rgba(239, 68, 68, 0.2)', 
                  borderRadius: '10px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Current Pending Udhar:</span>
                  <span style={{ fontSize: '16px', fontWeight: 700, color: '#ef4444' }}>
                    ₹{Number(paymentModalCustomer.amountDue).toLocaleString('en-IN')}
                  </span>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '6px' }}>
                    Payment Amount Collected (₹) *
                  </label>
                  <div style={{ position: 'relative' }}>
                    <IndianRupee size={16} style={{ position: 'absolute', left: '12px', top: '12px', color: 'var(--text-muted)' }} />
                    <input 
                      type="number"
                      step="any"
                      min="1"
                      max={paymentModalCustomer.amountDue}
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      className="ai-input"
                      style={{ paddingLeft: '34px', width: '100%', fontSize: '15px', fontWeight: 600 }}
                      placeholder="Enter amount"
                      required
                      autoFocus
                    />
                  </div>
                  <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                    <button 
                      type="button" 
                      className="btn-secondary" 
                      style={{ fontSize: '11px', padding: '3px 8px' }}
                      onClick={() => setPaymentAmount(paymentModalCustomer.amountDue)}
                    >
                      Settle in Full (₹{paymentModalCustomer.amountDue})
                    </button>
                    {paymentModalCustomer.amountDue > 5000 && (
                      <button 
                        type="button" 
                        className="btn-secondary" 
                        style={{ fontSize: '11px', padding: '3px 8px' }}
                        onClick={() => setPaymentAmount(Math.round(paymentModalCustomer.amountDue / 2))}
                      >
                        50% Part-Payment
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '6px' }}>
                    Payment Mode
                  </label>
                  <select 
                    value={paymentMethod} 
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="ai-input"
                    style={{ width: '100%', fontSize: '13px' }}
                  >
                    <option value="UPI">UPI (Google Pay / PhonePe / Paytm)</option>
                    <option value="Cash">Cash at Counter</option>
                    <option value="Bank Transfer">Bank NEFT / IMPS Transfer</option>
                    <option value="Cheque">Cheque / Demand Draft</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '6px' }}>
                    Notes / Reference ID (Optional)
                  </label>
                  <input 
                    type="text"
                    value={paymentNotes}
                    onChange={(e) => setPaymentNotes(e.target.value)}
                    className="ai-input"
                    placeholder="e.g. UTR #492819, Received via cashier"
                    style={{ width: '100%', fontSize: '13px' }}
                  />
                </div>
              </div>

              <div className="modal-footer" style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', padding: '16px 24px', borderTop: '1px solid var(--border-color)' }}>
                <button type="button" className="btn-secondary" onClick={() => setPaymentModalCustomer(null)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                  <CheckCircle2 size={15} />
                  <span>Confirm &amp; Record Payment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
