import React, { useState } from 'react';
import { 
  Search, 
  Download, 
  Plus,
  FileText,
} from 'lucide-react';
import { useDataStore } from '../context/DataStore';
import { downloadSchemaTemplate } from '../services/importEngine';
import { DATASET_TYPES } from '../data/schemas';

export const SalesView = ({ onOpenQuickSale, onViewInvoice }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [sortBy, setSortBy] = useState('date-desc');
  const { sales, derivedKPIs } = useDataStore();

  const categories = ['All', ...new Set(sales.map(s => s.category || 'General'))];

  // Filtering
  let filteredSales = sales.filter(s => {
    const matchesSearch = 
      (s.customer && s.customer.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (s.product && s.product.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (s.invoiceId && s.invoiceId.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (!matchesSearch) return false;
    if (categoryFilter !== 'All' && (s.category || 'General') !== categoryFilter) return false;
    return true;
  });

  // Sorting
  filteredSales = [...filteredSales].sort((a, b) => {
    if (sortBy === 'revenue-desc') {
      const revA = Number(a.revenue || (a.quantity * a.sellingPrice)) || 0;
      const revB = Number(b.revenue || (b.quantity * b.sellingPrice)) || 0;
      return revB - revA;
    }
    if (sortBy === 'profit-desc') {
      return (Number(b.profit) || 0) - (Number(a.profit) || 0);
    }
    // Default newest date
    return (b.date || '').localeCompare(a.date || '');
  });

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Sales</h1>
          <p className="page-subtitle">Track orders, sales volume, invoices, and counter billing.</p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-secondary" 
            onClick={() => downloadSchemaTemplate(DATASET_TYPES.SALES)}
            style={{ fontSize: '13px' }}
          >
            <Download size={14} />
            <span>Download Template</span>
          </button>

          <button 
            className="btn-primary"
            onClick={() => onOpenQuickSale && onOpenQuickSale()}
            style={{ fontSize: '13px' }}
          >
            <Plus size={15} />
            <span>Quick Bill / Sale</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <span className="kpi-title">Gross Sales</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>{derivedKPIs.revenue.formatted}</div>
          <div className="kpi-trend positive">{derivedKPIs.revenue.trend} cumulative</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Total Orders</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>{sales.length} Orders</div>
          <div className="kpi-trend positive">Total units: {derivedKPIs.sales.formatted}</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Net Profit</span>
          <div className="kpi-value" style={{ marginTop: '8px', color: 'var(--brand-green)' }}>{derivedKPIs.profit.formatted}</div>
          <div className="kpi-trend positive">Margin: {derivedKPIs.profitMargin.formatted}</div>
        </div>
        <div className="kpi-card">
          <span className="kpi-title">Avg Order Value</span>
          <div className="kpi-value" style={{ marginTop: '8px' }}>
            ₹{sales.length > 0 ? Math.round(derivedKPIs.revenue.value / sales.length).toLocaleString('en-IN') : '0'}
          </div>
          <div className="kpi-trend positive">per transaction</div>
        </div>
      </div>

      {/* Sales Transactions Table */}
      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Sales & Orders Ledger ({filteredSales.length} Records)</h2>
            <p className="card-subheading">Live transactions recorded, counter bills, and imported spreadsheets</p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            {/* Category Filter */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="ai-input"
              style={{ fontSize: '12.5px', padding: '6px 10px', height: '36px' }}
            >
              {categories.map((cat, i) => (
                <option key={i} value={cat}>{cat === 'All' ? 'All Categories' : cat}</option>
              ))}
            </select>

            {/* Sort Selector */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="ai-input"
              style={{ fontSize: '12.5px', padding: '6px 10px', height: '36px' }}
            >
              <option value="date-desc">Newest First</option>
              <option value="revenue-desc">Highest Revenue</option>
              <option value="profit-desc">Highest Profit</option>
            </select>

            {/* Search */}
            <div style={{ position: 'relative', width: '220px' }}>
              <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
              <input 
                type="text" 
                placeholder="Search party or invoice..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)}
                className="ai-input" 
                style={{ paddingLeft: '32px', fontSize: '13px' }} 
              />
            </div>
          </div>
        </div>

        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Invoice / Date</th>
                <th>Party / Customer</th>
                <th>Product & Qty</th>
                <th>Unit Price</th>
                <th>Revenue</th>
                <th>Net Profit</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredSales.map((sale, idx) => (
                <tr key={idx}>
                  <td>
                    <button
                      onClick={() => onViewInvoice && onViewInvoice(sale)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: 'var(--brand-blue)',
                        cursor: 'pointer',
                        padding: 0,
                        fontWeight: 700,
                        fontSize: '13px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }}
                      title="Click to view full GST invoice"
                    >
                      <span>{sale.invoiceId || `#INV-${idx + 101}`}</span>
                    </button>
                    <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{sale.date}</div>
                  </td>
                  <td>
                    <div style={{ fontWeight: 600 }}>{sale.customer}</div>
                    <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{sale.category || 'General'}</div>
                  </td>
                  <td>
                    <div style={{ fontWeight: 500 }}>{sale.product}</div>
                    <div style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>{sale.quantity} units</div>
                  </td>
                  <td>₹{Number(sale.sellingPrice || 0).toLocaleString('en-IN')}</td>
                  <td>
                    <strong style={{ fontSize: '14px' }}>
                      ₹{Number(sale.revenue || (sale.quantity * sale.sellingPrice)).toLocaleString('en-IN')}
                    </strong>
                  </td>
                  <td>
                    <span style={{ color: 'var(--brand-green)', fontWeight: 600 }}>
                      ₹{Number(sale.profit || 0).toLocaleString('en-IN')}
                    </span>
                  </td>
                  <td>
                    <span className="badge badge-success">Completed</span>
                  </td>
                  <td>
                    <button
                      className="btn-secondary"
                      style={{ padding: '4px 8px', fontSize: '11.5px', display: 'flex', alignItems: 'center', gap: '4px' }}
                      onClick={() => onViewInvoice && onViewInvoice(sale)}
                      title="View & Print GST Invoice"
                    >
                      <FileText size={12} />
                      <span>Invoice</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
