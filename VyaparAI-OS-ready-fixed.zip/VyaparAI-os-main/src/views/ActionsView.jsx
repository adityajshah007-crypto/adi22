import React, { useState } from 'react';
import { 
  Zap, 
  CheckCircle2, 
  MessageCircle,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ActionsView = ({ onOpenWhatsApp, onOpenPOModal, onShowToast }) => {
  const [completedActions, setCompletedActions] = useState([]);

  const actionQueue = [
    {
      id: 'act-1',
      type: 'Khata Collection',
      title: 'Send WhatsApp Payment Reminder to Sharmaji Caterers',
      impact: 'Recover ₹24,500 overdue by 34 days',
      priority: 'High Priority',
      btnText: 'Send WhatsApp Reminder',
      icon: MessageCircle,
      handler: () => onOpenWhatsApp && onOpenWhatsApp({ name: 'Sharmaji Caterers', phone: '+91 98112 34567', pendingAmount: 24500, overdueDays: 34 })
    },
    {
      id: 'act-2',
      type: 'Inventory Reorder',
      title: 'Generate Purchase Order for Low Stock Edible Oils',
      impact: 'Prevent stockout on Fortune Sunflower Oil (8 units left)',
      priority: 'Urgent',
      btnText: 'Generate Reorder PO',
      icon: FileText,
      handler: () => onOpenPOModal && onOpenPOModal([{ name: 'Fortune Sunlite Sunflower Oil 5L', supplier: 'Adani Wilmar Agency', currentStock: 8, minStock: 25, costPrice: 560, suggestedOrderQty: 40 }])
    },
    {
      id: 'act-3',
      type: 'Margin Optimization',
      title: 'Apply 10% Clearance Discount to Dead Stock Spices & Gift Packs',
      impact: 'Release ₹42,000 idle capital held for >60 days',
      priority: 'Medium',
      btnText: 'Apply Promo',
      icon: Zap,
      handler: () => {
        confetti({ particleCount: 50 });
        setCompletedActions(prev => [...prev, 'act-3']);
        if (onShowToast) onShowToast({ message: '10% Clearance promotion activated for slow-moving stock!', type: 'success' });
      }
    }
  ];

  const handleComplete = (id, title) => {
    confetti({ particleCount: 60, spread: 50 });
    setCompletedActions(prev => [...prev, id]);
    if (onShowToast) onShowToast({ message: `Action executed: ${title || 'Completed'}`, type: 'success' });
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Actions</h1>
          <p className="page-subtitle">AI-prioritized operational recommendations and 1-click business tasks.</p>
        </div>
      </div>

      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Prioritized Action Queue</h2>
            <p className="card-subheading">High-impact tasks curated by VyaparAI Advisor</p>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {actionQueue.map((act) => {
            const isDone = completedActions.includes(act.id);
            const Icon = act.icon;

            return (
              <div
                key={act.id}
                style={{
                  padding: '16px',
                  borderRadius: '10px',
                  border: '1px solid var(--border-color)',
                  backgroundColor: isDone ? 'var(--bg-card-subtle)' : 'var(--bg-card)',
                  opacity: isDone ? 0.6 : 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '14px',
                  transition: 'all 0.15s ease'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '8px',
                    backgroundColor: 'var(--bg-card-subtle)',
                    border: '1px solid var(--border-color)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'var(--brand-saffron)'
                  }}>
                    <Icon size={20} />
                  </div>

                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span className="badge badge-warning" style={{ fontSize: '10.5px' }}>{act.type}</span>
                      <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)', textDecoration: isDone ? 'line-through' : 'none' }}>
                        {act.title}
                      </span>
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>
                      {act.impact}
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  {!isDone ? (
                    <>
                      <button className="btn-primary" onClick={act.handler} style={{ fontSize: '12.5px', padding: '6px 12px' }}>
                        <span>{act.btnText}</span>
                      </button>
                      <button className="btn-secondary" onClick={() => handleComplete(act.id)} style={{ fontSize: '12.5px', padding: '6px 12px' }}>
                        <CheckCircle2 size={14} color="var(--brand-green)" />
                        <span>Done</span>
                      </button>
                    </>
                  ) : (
                    <span className="badge badge-success">Completed</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
