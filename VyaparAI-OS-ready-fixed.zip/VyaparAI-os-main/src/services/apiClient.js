// ==========================================================================
// VYAPARAI OS — REST API CLIENT
// Centralized API access with environment-aware URLs and consistent errors.
// ===========================================================================

const API_BASE_URL = (import.meta.env.VITE_API_URL || '/api/v1').replace(/\/$/, '');

const getApiUrl = (endpoint) => `${API_BASE_URL}${endpoint}`;

const getHealthUrl = () => {
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL.replace(/\/api\/v1\/?$/, '') + '/health';
  }
  return '/health';
};

export const getAuthToken = () => localStorage.getItem('vyapar_auth_token') || null;

export const getBusinessId = () => {
  try {
    const business = JSON.parse(localStorage.getItem('vyapar_auth_business') || 'null');
    return business?.id || business?.business_id || 'BIZ-BHARAT-001';
  } catch {
    return 'BIZ-BHARAT-001';
  }
};

export const getHeaders = (businessId = getBusinessId()) => {
  const headers = {
    'Content-Type': 'application/json',
    'X-Business-ID': businessId
  };
  const token = getAuthToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
};

const request = async (endpoint, options = {}) => {
  let response;
  try {
    response = await fetch(getApiUrl(endpoint), options);
  } catch (error) {
    throw new Error(`Backend unavailable. Start the FastAPI server and try again. (${error.message})`);
  }

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = typeof data?.detail === 'string'
      ? data.detail
      : Array.isArray(data?.detail)
        ? data.detail.map(item => item.msg).join(', ')
        : `Request failed with status ${response.status}`;
    const error = new Error(detail);
    error.status = response.status;
    throw error;
  }
  return data;
};

// Authentication Endpoints
export const loginUser = (email, password) => request('/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});

export const registerUser = (registrationData) => request('/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(registrationData)
});

export const fetchCurrentUser = async () => {
  if (!getAuthToken()) return null;
  return request('/auth/me', {
    method: 'GET',
    headers: getHeaders()
  });
};

export const checkBackendHealth = async () => {
  try {
    const response = await fetch(getHealthUrl(), { method: 'GET' });
    const data = await response.json().catch(() => ({}));
    return response.ok ? { online: true, ...data } : { online: false, ...data };
  } catch (error) {
    return { online: false, error: error.message };
  }
};

export const sendImportToBackend = async (
  datasetType,
  fileName,
  rows,
  overwrite = false,
  businessId = getBusinessId()
) => {
  try {
    return await request('/imports/process', {
      method: 'POST',
      headers: getHeaders(businessId),
      body: JSON.stringify({
        dataset_type: datasetType,
        file_name: fileName,
        rows,
        overwrite
      })
    });
  } catch (error) {
    // The UI remains usable during offline/demo development. The validated
    // rows are still written to the local DataStore by the caller.
    return {
      job_id: `LOCAL-${Date.now()}`,
      business_id: businessId,
      dataset_type: datasetType,
      file_name: fileName,
      total_rows: rows.length,
      valid_rows: rows.length,
      invalid_rows: 0,
      status: 'LOCAL_FALLBACK',
      errors: [],
      message: `Saved locally because the backend could not be reached: ${error.message}`
    };
  }
};

export const fetchSalesFromBackend = async (businessId = getBusinessId()) =>
  request('/sales/', { headers: getHeaders(businessId) });

export const createSaleInBackend = async (sale, businessId = getBusinessId()) =>
  request('/sales/', {
    method: 'POST',
    headers: getHeaders(businessId),
    body: JSON.stringify(sale)
  });

export const fetchInventoryFromBackend = async (businessId = getBusinessId()) =>
  request('/inventory/', { headers: getHeaders(businessId) });

export const fetchCustomersFromBackend = async (businessId = getBusinessId()) =>
  request('/customers/', { headers: getHeaders(businessId) });
