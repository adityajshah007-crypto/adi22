// ==========================================================================
// VYAPARAI OS — DATA IMPORT & VALIDATION ENGINE
// Parses Excel/CSV, Auto-detects columns, Validates rows against Schemas
// ==========================================================================

import * as XLSX from 'xlsx';
import { SCHEMAS, DATASET_TYPES } from '../data/schemas.js';

// Normalize header strings for comparison
export const normalizeHeader = (header) => {
  return String(header || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_');
};

// Auto-detect which dataset type a file most likely represents
export const detectDatasetType = (headers) => {
  const normalizedHeaders = headers.map(normalizeHeader);
  let bestType = DATASET_TYPES.SALES;
  let maxScore = -1;

  for (const [typeKey, schema] of Object.entries(SCHEMAS)) {
    let score = 0;
    for (const field of schema.fields) {
      if (normalizedHeaders.some(h => field.aliases.includes(h) || field.aliases.some(alias => h.includes(alias)))) {
        score += field.required ? 3 : 1;
      }
    }
    if (score > maxScore) {
      maxScore = score;
      bestType = typeKey;
    }
  }

  return bestType;
};

// Automatically match uploaded columns to schema fields
export const autoMapColumns = (headers, schema) => {
  const mapping = {};
  const normalizedHeaders = headers.map(h => ({ original: h, normalized: normalizeHeader(h) }));
  const matchedOriginals = new Set();

  for (const field of schema.fields) {
    mapping[field.key] = ''; // default empty

    // Exact alias match
    for (const h of normalizedHeaders) {
      if (!matchedOriginals.has(h.original) && field.aliases.includes(h.normalized)) {
        mapping[field.key] = h.original;
        matchedOriginals.add(h.original);
        break;
      }
    }

    // Fallback: substring match if not matched
    if (!mapping[field.key]) {
      for (const h of normalizedHeaders) {
        if (!matchedOriginals.has(h.original) && field.aliases.some(alias => h.normalized.includes(alias) || alias.includes(h.normalized))) {
          mapping[field.key] = h.original;
          matchedOriginals.add(h.original);
          break;
        }
      }
    }
  }

  // Find unmapped columns from uploaded file
  const unmappedColumns = headers.filter(h => !matchedOriginals.has(h));

  return { mapping, unmappedColumns };
};

// Parse file buffer into raw JSON rows and headers
export const parseFileToRawData = async (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array', cellDates: true });
        
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          throw new Error('Spreadsheet has no sheets.');
        }

        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawRows = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

        if (!rawRows || rawRows.length === 0) {
          throw new Error('Spreadsheet appears to be empty. Please check the file.');
        }

        const headers = Object.keys(rawRows[0]);
        const detectedType = detectDatasetType(headers);

        resolve({
          fileName: file.name,
          fileSize: file.size,
          sheetName,
          headers,
          rawRows,
          totalRows: rawRows.length,
          detectedType
        });
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
};

// Validate raw rows against schema and active column mapping
export const validateDataset = (rawRows, schema, columnMapping) => {
  const normalizedRows = [];
  const errors = [];
  const duplicates = [];
  const seenUniqueKeys = new Set();

  rawRows.forEach((row, index) => {
    const rowIndex = index + 1; // 1-indexed for display
    const rowErrors = [];
    const normalizedItem = { _rowIndex: rowIndex, _raw: row };
    let hasFatalError = false;

    // Process each field in schema
    for (const field of schema.fields) {
      const sourceCol = columnMapping[field.key];
      let rawVal = sourceCol ? row[sourceCol] : undefined;

      if (rawVal !== undefined && typeof rawVal === 'string') {
        rawVal = rawVal.trim();
      }

      // Check 1: Missing Required Field
      if (field.required && (rawVal === undefined || rawVal === '' || rawVal === null)) {
        const errType = field.key === 'product' ? 'EMPTY_PRODUCT' : 'MISSING_REQUIRED';
        rowErrors.push({
          row: rowIndex,
          field: field.label,
          type: errType,
          message: field.key === 'product' ? 'Product name cannot be blank or empty' : `Missing required field "${field.label}"`
        });
        hasFatalError = true;
      }

      // Type-specific validations
      if (rawVal !== undefined && rawVal !== '' && rawVal !== null) {
        if (field.type === 'number') {
          // Clean currency symbols or commas (e.g. ₹1,200 or 1,200)
          const cleanNum = String(rawVal).replace(/[₹,$,\s]/g, '');
          const parsedNum = Number(cleanNum);

          if (isNaN(parsedNum)) {
            rowErrors.push({
              row: rowIndex,
              field: field.label,
              type: 'INVALID_NUMBER',
              value: rawVal,
              message: `"${field.label}" must be a valid number, got "${rawVal}"`
            });
            hasFatalError = true;
          } else if (field.min !== undefined && parsedNum < field.min) {
            rowErrors.push({
              row: rowIndex,
              field: field.label,
              type: 'NUMBER_OUT_OF_RANGE',
              value: rawVal,
              message: `"${field.label}" cannot be less than ${field.min}`
            });
            hasFatalError = true;
          } else {
            normalizedItem[field.key] = parsedNum;
          }
        } else if (field.type === 'date') {
          const dateObj = new Date(rawVal);
          if (isNaN(dateObj.getTime())) {
            rowErrors.push({
              row: rowIndex,
              field: field.label,
              type: 'INVALID_DATE',
              value: rawVal,
              message: `"${field.label}" is not a recognizable date (got "${rawVal}")`
            });
            hasFatalError = true;
          } else {
            normalizedItem[field.key] = dateObj.toISOString().split('T')[0];
          }
        } else {
          // String field
          const strVal = String(rawVal);
          if (field.key === 'product' && strVal.length === 0) {
            rowErrors.push({
              row: rowIndex,
              field: field.label,
              type: 'EMPTY_PRODUCT',
              message: 'Product name cannot be blank'
            });
            hasFatalError = true;
          }
          normalizedItem[field.key] = strVal;
        }
      } else {
        // Fallback default value if field omitted
        normalizedItem[field.key] = field.default !== undefined ? field.default : null;
      }
    }

    // Auto-compute Sales Revenue & Profit if missing
    if (schema.id === DATASET_TYPES.SALES) {
      const qty = normalizedItem.quantity || 1;
      const sp = normalizedItem.sellingPrice || 0;
      if (!normalizedItem.revenue) {
        normalizedItem.revenue = qty * sp;
      }
      if (!normalizedItem.cost) {
        normalizedItem.cost = Math.round(normalizedItem.revenue * 0.75); // estimated 25% margin default
      }
      if (!normalizedItem.profit) {
        normalizedItem.profit = normalizedItem.revenue - normalizedItem.cost;
      }
    }

    // Check Duplicate Records (using Unique key or combined product + customer + date)
    let uniqueKey = '';
    if (schema.id === DATASET_TYPES.SALES) {
      uniqueKey = normalizedItem.invoiceId || `${normalizedItem.date}_${normalizedItem.customer}_${normalizedItem.product}_${normalizedItem.quantity}`;
    } else if (schema.id === DATASET_TYPES.INVENTORY) {
      uniqueKey = normalizedItem.sku || `${normalizedItem.product}_${normalizedItem.category}`;
    } else if (schema.id === DATASET_TYPES.CUSTOMERS) {
      uniqueKey = normalizedItem.phone || normalizedItem.customerName;
    }

    if (uniqueKey && seenUniqueKeys.has(uniqueKey.toLowerCase())) {
      duplicates.push({
        row: rowIndex,
        key: uniqueKey,
        message: `Duplicate record detected (${uniqueKey})`
      });
      // Mark warning, but user can choose to skip or overwrite
      rowErrors.push({
        row: rowIndex,
        field: 'Duplicate',
        type: 'DUPLICATE_RECORD',
        message: `Duplicate entry detected: ${uniqueKey}`
      });
    } else if (uniqueKey) {
      seenUniqueKeys.add(uniqueKey.toLowerCase());
    }

    normalizedItem._isValid = !hasFatalError;
    normalizedItem._errors = rowErrors;

    if (rowErrors.length > 0) {
      errors.push(...rowErrors);
    }

    normalizedRows.push(normalizedItem);
  });

  const validRows = normalizedRows.filter(r => r._isValid && !r._errors.some(e => e.type === 'DUPLICATE_RECORD'));
  const invalidRows = normalizedRows.filter(r => !r._isValid);

  return {
    totalRows: rawRows.length,
    validRowsCount: validRows.length,
    invalidRowsCount: invalidRows.length,
    duplicateCount: duplicates.length,
    normalizedRows,
    validRows,
    invalidRows,
    errors,
    duplicates
  };
};

// Generate and download standard sample templates for each dataset type
export const downloadSchemaTemplate = (datasetType) => {
  let sampleData = [];
  let fileName = '';

  if (datasetType === DATASET_TYPES.SALES) {
    fileName = 'VyaparAI_Sales_Template.xlsx';
    sampleData = [
      {
        Date: '2026-09-01',
        Invoice_ID: 'INV-2026-001',
        Product: 'India Gate Basmati Rice 10kg',
        Category: 'Grains & Staples',
        Quantity: 5,
        Selling_Price: 1150,
        Revenue: 5750,
        Cost: 4600,
        Profit: 1150,
        Customer: 'Sharmaji Caterers'
      },
      {
        Date: '2026-09-02',
        Invoice_ID: 'INV-2026-002',
        Product: 'Fortune Sunlite Sunflower Oil 5L',
        Category: 'Edible Oils',
        Quantity: 8,
        Selling_Price: 650,
        Revenue: 5200,
        Cost: 4400,
        Profit: 800,
        Customer: 'Deepak Sweet House'
      },
      {
        Date: '2026-09-03',
        Invoice_ID: 'INV-2026-003',
        Product: 'Tata Salt 1kg',
        Category: 'Spices & Essentials',
        Quantity: 25,
        Selling_Price: 28,
        Revenue: 700,
        Cost: 525,
        Profit: 175,
        Customer: 'Verma PG Hostel'
      }
    ];
  } else if (datasetType === DATASET_TYPES.INVENTORY) {
    fileName = 'VyaparAI_Inventory_Template.xlsx';
    sampleData = [
      {
        Product: 'Fortune Sunlite Sunflower Oil 5L',
        SKU: 'OIL-SUN-5L',
        Category: 'Edible Oils',
        Current_Stock: 18,
        Cost_Price: 560,
        Selling_Price: 650,
        Supplier: 'Adani Wilmar Dist',
        Reorder_Level: 25
      },
      {
        Product: 'India Gate Basmati Rice 10kg',
        SKU: 'RICE-BAS-10K',
        Category: 'Grains & Staples',
        Current_Stock: 14,
        Cost_Price: 920,
        Selling_Price: 1150,
        Supplier: 'KRBL Agri Ltd',
        Reorder_Level: 30
      },
      {
        Product: 'Amul Butter Salted 500g',
        SKU: 'DAIRY-BUT-500',
        Category: 'Dairy & Cold',
        Current_Stock: 6,
        Cost_Price: 245,
        Selling_Price: 285,
        Supplier: 'Delhi Milk Union',
        Reorder_Level: 15
      }
    ];
  } else if (datasetType === DATASET_TYPES.CUSTOMERS) {
    fileName = 'VyaparAI_Customers_Template.xlsx';
    sampleData = [
      {
        Customer_Name: 'Sharmaji Caterers',
        Phone: '+91 98112 34567',
        Email: 'sharmaji.caterers@gmail.com',
        Total_Purchases: 485000,
        Amount_Paid: 460500,
        Amount_Due: 24500,
        Due_Date: '2026-09-15'
      },
      {
        Customer_Name: 'Aggarwal Sweets & Dairy',
        Phone: '+91 99104 88712',
        Email: 'aggarwalsweets@yahoo.com',
        Total_Purchases: 610000,
        Amount_Paid: 571800,
        Amount_Due: 38200,
        Due_Date: '2026-09-10'
      },
      {
        Customer_Name: 'Verma PG Mess',
        Phone: '+91 93120 77419',
        Email: 'vermapg@outlook.com',
        Total_Purchases: 195000,
        Amount_Paid: 186100,
        Amount_Due: 8900,
        Due_Date: '2026-09-20'
      }
    ];
  }

  const ws = XLSX.utils.json_to_sheet(sampleData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Template');
  XLSX.writeFile(wb, fileName);
};
