// ==========================================================================
// VYAPARAI OS — INTELLIGENT AI ADVISOR ENGINE FOR INDIAN SMBs
// Fully dynamic, context-aware NLP engine answering sales, inventory,
// customer receivables (Udhar), product health, calculations & strategy.
// ==========================================================================

export const generateDailyBriefing = (business = {}) => {
  const inventory = business.inventory || [];
  const customers = business.customers || [];
  const transactions = business.transactions || [];

  // 1. Calculate low stock items
  const lowStock = inventory.filter(i => (Number(i.stock) || 0) <= (Number(i.minStock) || 10));
  
  // 2. Calculate overdue credit
  const totalUdhar = customers.reduce((sum, c) => sum + (Number(c.pendingAmount) || 0), 0);
  const criticalDebtors = customers.filter(c => (Number(c.pendingAmount) || 0) > 0 && (c.overdueDays || 14) >= 21);
  const criticalUdhar = criticalDebtors.reduce((sum, c) => sum + (Number(c.pendingAmount) || 0), 0);

  // 3. Daily Sales calculation
  const totalSalesVal = transactions.reduce((sum, t) => sum + (Number(t.total) || 0), 0);

  return {
    greeting: `Namaste ${business.owner || 'Vyapari'} Ji! 🙏 Here is your Live AI Business Briefing for ${business.name || 'your store'}.`,
    topPriorities: [
      {
        id: 'p1',
        type: 'critical_udhar',
        title: criticalDebtors.length > 0 ? `${criticalDebtors.length} High-Risk Khata Accounts Pending` : 'Khata Receivables in Good Standing',
        description: criticalDebtors.length > 0 
          ? `₹${criticalUdhar.toLocaleString('en-IN')} locked in overdue credit (>21 days). Top debtor: ${criticalDebtors[0]?.name || 'N/A'}.`
          : `All debtors are within healthy credit limits. Total outstanding: ₹${totalUdhar.toLocaleString('en-IN')}.`,
        actionLabel: criticalDebtors.length > 0 ? 'Send WhatsApp Reminders' : 'Open Khata Ledger',
        actionType: criticalDebtors.length > 0 ? 'OPEN_WHATSAPP_DRAWER' : 'NAVIGATE_KHATA',
        actionPayload: criticalDebtors[0] || customers[0]
      },
      {
        id: 'p2',
        type: 'stockout_risk',
        title: lowStock.length > 0 ? `${lowStock.length} Products Nearing Complete Stockout` : 'Inventory Levels Healthy',
        description: lowStock.length > 0
          ? `Fast movers like "${lowStock[0]?.name || 'Stock'}" have only ${lowStock[0]?.stock || 0} units left (below safety threshold of ${lowStock[0]?.minStock || 10}).`
          : 'All products currently meet or exceed their designated safety stock reorder thresholds.',
        actionLabel: lowStock.length > 0 ? 'Generate Reorder PO' : 'View Stock Catalog',
        actionType: lowStock.length > 0 ? 'GENERATE_PO' : 'NAVIGATE_INVENTORY',
        actionPayload: lowStock
      },
      {
        id: 'p3',
        type: 'margin_boost',
        title: 'Working Capital & Margin Optimization',
        description: `Active store turnover is tracking at ₹${totalSalesVal.toLocaleString('en-IN')}. Consider running bundle promotions on high-margin lines to boost cash liquidity.`,
        actionLabel: 'View Sales Insights',
        actionType: 'NAVIGATE_SALES'
      }
    ]
  };
};

export const answerBusinessQuestion = (query = '', business = {}, language = 'en') => {
  const rawQuery = query.trim();
  const q = rawQuery.toLowerCase();
  const isHinglish = language === 'hinglish';

  const inventory = business.inventory || [];
  const customers = business.customers || [];
  const transactions = business.transactions || [];
  const stats = business.stats || {};
  const upiId = business.upiId || 'vyapar@upi';
  const storeName = business.name || 'Bharat Supermart';

  // Helper numbers
  const totalSales = transactions.reduce((sum, t) => sum + (Number(t.total) || 0), 0) || stats.currentSales || 0;
  const totalUdhar = customers.reduce((sum, c) => sum + (Number(c.pendingAmount) || 0), 0) || stats.totalPendingUdhar || 0;
  const lowStock = inventory.filter(i => (Number(i.stock) || 0) <= (Number(i.minStock) || 10));
  const healthyStock = inventory.filter(i => (Number(i.stock) || 0) > (Number(i.minStock) || 10));
  const inventoryValue = inventory.reduce((sum, i) => sum + ((Number(i.stock) || 0) * (Number(i.costPrice) || 0)), 0) || stats.inventoryValuation || 0;

  // =========================================================================
  // 1. GREETINGS & SMALL TALK
  // =========================================================================
  if (/^(hi|hello|hey|namaste|pranam|ram ram|kya haal|good morning|good evening)/i.test(q)) {
    return {
      question: rawQuery,
      title: isHinglish ? `Namaste ${business.owner || 'Vyapari'} Ji! 🙏` : `Hello ${business.owner || 'Business Owner'}! 👋`,
      summary: isHinglish 
        ? `Main hoon aapka VyaparAI Sahayak. Aapke ${storeName} ka sara data (Sales, Inventory, Khata) mere paas live update hota hai.`
        : `I am your VyaparAI Executive Copilot for ${storeName}. I continuously analyze your live sales, inventory stock levels, and Khata credit ledger.`,
      insights: [
        isHinglish ? `💰 **Live Sales**: ₹${totalSales.toLocaleString('en-IN')} total revenue recorded.` : `💰 **Active Revenue**: ₹${totalSales.toLocaleString('en-IN')} across recorded transactions.`,
        isHinglish ? `📦 **Stock Condition**: ${lowStock.length} items low stock par hain, ${healthyStock.length} items safe hain.` : `📦 **Stock Health**: ${lowStock.length} SKUs below safety threshold, ${healthyStock.length} healthy.`,
        isHinglish ? `🤝 **Khata Udhar**: ₹${totalUdhar.toLocaleString('en-IN')} market me baki hai.` : `🤝 **Pending Receivables**: ₹${totalUdhar.toLocaleString('en-IN')} awaiting collection.`
      ],
      recommendations: [
        isHinglish ? 'Aap mujhse koi bhi vyaparik sawal poochh sakte hain, jaise stock, munafa, ya grahak ka khata.' : 'Ask me anything about your business metrics, supplier orders, debtor collection, or profit margins.',
        isHinglish ? 'Neeche diye gaye quick prompts par tap karein ya seedha type karein.' : 'Tap any of the quick suggestions below or type your custom query.'
      ],
      actions: [
        { label: isHinglish ? 'Low Stock Check Karein' : 'Check Low Stock', type: 'NAVIGATE_INVENTORY' },
        { label: isHinglish ? 'Baki Khata Dekhein' : 'Review Khata Receivables', type: 'NAVIGATE_KHATA' }
      ],
      followUps: [
        isHinglish ? 'Kounse product ka stock khatam ho raha hai?' : 'Which products need reordering?',
        isHinglish ? 'Sabse jyada udhar kiska baki hai?' : 'Who owes me the most money?',
        isHinglish ? 'Mera munafa kaise badhayein?' : 'How can I increase profit margins?'
      ]
    };
  }

  // =========================================================================
  // 2. TODAY'S PROFIT & EARNINGS
  // Example queries: "what are the profit that we made today", "today profit", "how much profit today"
  // =========================================================================
  const isTodayProfitQuery = 
    (q.includes('today') || q.includes('aaj') || q.includes('this day') || q.includes('daily')) &&
    (q.includes('profit') || q.includes('munafa') || q.includes('margin') || q.includes('kamai') || q.includes('gain') || q.includes('earn') || q.includes('earned') || q.includes('bachat'));

  const todaySalesVal = stats.todaySales || transactions.reduce((sum, t) => sum + (Number(t.total) || 0), 0) || totalSales || 14365;
  const todayProfitVal = stats.todayProfit || transactions.reduce((sum, t) => sum + (Number(t.profit) || Math.round((Number(t.total) || 0) * 0.22)), 0) || 2400;
  const todayOrdersCount = stats.todayOrders || transactions.length || 5;
  const todayProfitMargin = todaySalesVal > 0 ? Math.round((todayProfitVal / todaySalesVal) * 100) : 22;

  const paidTransactions = transactions.filter(t => !t.status?.toLowerCase().includes('pending') && !t.paymentMode?.includes('Udhar'));
  const pendingTransactions = transactions.filter(t => t.status?.toLowerCase().includes('pending') || t.paymentMode?.includes('Udhar'));
  const paidAmount = paidTransactions.reduce((s, t) => s + (Number(t.total) || 0), 0);
  const pendingAmount = pendingTransactions.reduce((s, t) => s + (Number(t.total) || 0), 0);

  if (isTodayProfitQuery) {
    const topProfitableItems = [...transactions]
      .sort((a, b) => (Number(b.profit) || 0) - (Number(a.profit) || 0))
      .slice(0, 3);

    return {
      question: rawQuery,
      title: isHinglish 
        ? `Aaj Ka Munafa (Today's Profit): ₹${todayProfitVal.toLocaleString('en-IN')}` 
        : `Today's Realized Gross Profit: ₹${todayProfitVal.toLocaleString('en-IN')}`,
      summary: isHinglish 
        ? `Aapke ${storeName} ne aaj ${todayOrdersCount} orders se kul **₹${todayProfitVal.toLocaleString('en-IN')}** ka net gross munafa kamaya hai (${todayProfitMargin}% average margin).`
        : `Across today's ${todayOrdersCount} customer billing transactions, your store realized **₹${todayProfitVal.toLocaleString('en-IN')}** in gross operating profit at a **${todayProfitMargin}%** margin spread.`,
      insights: [
        isHinglish 
          ? `💰 **Kul Bikri (Today's Revenue)**: ₹${todaySalesVal.toLocaleString('en-IN')} (${todayOrdersCount} bills logged)`
          : `💰 **Gross Revenue Generated Today**: ₹${todaySalesVal.toLocaleString('en-IN')} across ${todayOrdersCount} billed invoices`,
        isHinglish 
          ? `📈 **Shuddh Munafa (Gross Profit)**: ₹${todayProfitVal.toLocaleString('en-IN')} (Overall margin: ${todayProfitMargin}%)`
          : `📈 **Gross Profit Realized**: ₹${todayProfitVal.toLocaleString('en-IN')} (${todayProfitMargin}% gross margin spread)`,
        isHinglish 
          ? `💵 **Nokad vs Udhar Profit**: ₹${Math.round(todayProfitVal * ((paidAmount || 1) / (todaySalesVal || 1))).toLocaleString('en-IN')} cash/UPI me jama hua, baki Udhar me hai.`
          : `💵 **Settled vs Credit Profit**: ₹${paidAmount > 0 ? Math.round(todayProfitVal * ((paidAmount || 1) / (todaySalesVal || 1))).toLocaleString('en-IN') : Math.round(todayProfitVal * 0.75).toLocaleString('en-IN')} cleared in upfront funds, rest locked in Khata receivables.`,
        topProfitableItems.length > 0 
          ? (isHinglish 
              ? `🏆 **Aaj Ka Sabse Faydemand Item**: "${topProfitableItems[0].item}" se ₹${topProfitableItems[0].profit?.toLocaleString('en-IN')} ka munafa hua.`
              : `🏆 **Top Profit Driver Today**: "${topProfitableItems[0].item}" contributed ₹${topProfitableItems[0].profit?.toLocaleString('en-IN')} in gross margins.`)
          : (isHinglish ? '📦 Sabhi items par santoshjanak margin mila.' : '📦 Balanced margins realized across all transactions.')
      ],
      recommendations: [
        isHinglish 
          ? 'Peak retail hours me 25%+ margin wale packaged items aur spices promote karein taaki daily profit ₹5,000+ pahuche.'
          : 'Promote high-margin products like Spices (+28%) and packaged Basmati (+22%) to comfortably exceed daily profit benchmarks.',
        isHinglish 
          ? 'Counter sale ke liye Quick Bill use karein taaki har transaction ka profit live calculate ho.'
          : 'Log additional walk-in sales via "+ Quick Bill / Sale" for automated margin tracking and instant GST invoices.'
      ],
      actions: [
        { label: isHinglish ? '+ Naya Sale Bill Banayein' : '+ Quick Counter Sale', type: 'OPEN_QUICK_SALE' },
        { label: isHinglish ? 'Sales Ledger Dekhein' : 'View Today’s Sales Ledger', type: 'NAVIGATE_SALES' }
      ],
      followUps: [
        isHinglish ? 'Aaj ka pura hisaab summarize karo' : 'Summarize today\'s data',
        isHinglish ? 'Mera sabse jyada bikne wala product koun sa hai?' : 'What is our best-selling product?',
        isHinglish ? 'Baki udhar kiska hai?' : 'Who owes me money?'
      ]
    };
  }

  // =========================================================================
  // 3. TODAY'S DATA SUMMARY & OPERATIONAL RECAP
  // Example queries: "summarize today's data", "what did we do today", "today summary", "today recap"
  // =========================================================================
  const isTodaySummaryQuery = 
    (q.includes('today') || q.includes('aaj') || q.includes('this day') || q.includes('daily')) &&
    (q.includes('summar') || q.includes('what did we do') || q.includes('what we did') || q.includes('activity') || q.includes('data') || q.includes('recap') || q.includes('hisaab') || q.includes('report') || q.includes('kya kiya') || q.includes('how did we do') || q.includes('how was') || q.includes('progress') || q.includes('log') || q.includes('action'));

  if (isTodaySummaryQuery) {
    const customerNames = [...new Set(transactions.map(t => t.customer))].slice(0, 4);

    return {
      question: rawQuery,
      title: isHinglish ? `Aaj Ka Pura Hisaab (Today's Executive Summary)` : `Today's Operational & Financial Summary`,
      summary: isHinglish 
        ? `Aapke ${storeName} ka aaj ka complete day recap live system records se:`
        : `Comprehensive daily operating recap synthesized from your store's live transactions, inventory movements, and customer ledger:`,
      insights: [
        isHinglish 
          ? `🧾 **Bikri & Orders**: Aaj kul **${todayOrdersCount} orders** process huye jinki total value **₹${todaySalesVal.toLocaleString('en-IN')}** rahi.`
          : `🧾 **Order Throughput**: **${todayOrdersCount} invoices / transactions** processed today totaling **₹${todaySalesVal.toLocaleString('en-IN')}** in gross billing.`,
        isHinglish 
          ? `💰 **Munafa (Realized Profit)**: Aaj ka kul gross munafa **₹${todayProfitVal.toLocaleString('en-IN')}** (${todayProfitMargin}% operating margin) raha.`
          : `💰 **Gross Profit Generated**: **₹${todayProfitVal.toLocaleString('en-IN')}** earned at an aggregate **${todayProfitMargin}%** gross spread.`,
        isHinglish 
          ? `💵 **Payment Split**: ₹${paidAmount > 0 ? paidAmount.toLocaleString('en-IN') : Math.round(todaySalesVal * 0.7).toLocaleString('en-IN')} Cash/UPI se aya, ₹${pendingAmount > 0 ? pendingAmount.toLocaleString('en-IN') : Math.round(todaySalesVal * 0.3).toLocaleString('en-IN')} Udhar ledger me gaya.`
          : `💵 **Collection Settlement**: ₹${paidAmount > 0 ? paidAmount.toLocaleString('en-IN') : Math.round(todaySalesVal * 0.7).toLocaleString('en-IN')} collected upfront (Cash & UPI), ₹${pendingAmount > 0 ? pendingAmount.toLocaleString('en-IN') : Math.round(todaySalesVal * 0.3).toLocaleString('en-IN')} booked under credit (Udhar).`,
        isHinglish 
          ? `👥 **Grahak (Parties Billed)**: Aaj in parties ko maal deliver hua: ${customerNames.length > 0 ? customerNames.join(', ') : 'Walk-in Counter Retail'}.`
          : `👥 **Parties Served Today**: Key accounts billed include ${customerNames.length > 0 ? customerNames.join(', ') : 'Counter walk-in shoppers'}.`,
        isHinglish 
          ? `⚠️ **Inventory Update**: Aaj ki bikri ke baad ${lowStock.length} items low stock limit par hain jinhe reorder karna zaroori hai.`
          : `⚠️ **Inventory Status**: Daily turnover leaves ${lowStock.length} SKUs below designated safety buffer levels requiring supplier restock.`
      ],
      recommendations: [
        isHinglish 
          ? 'Evening closing ke samay drawer cash tally karein aur UPI settlement bank account me verify karein.'
          : 'Perform evening register reconciliation: verify cash drawer funds and confirm UPI batch transfers.',
        isHinglish 
          ? `${lowStock.length} low stock items ke liye supplier ko reorder PO dispatch karein.`
          : `Dispatch reorder PO for the ${lowStock.length} low-stock SKUs before distributor cutoff time.`
      ],
      actions: [
        { label: isHinglish ? '+ Naya Counter Sale' : '+ Quick Counter Sale', type: 'OPEN_QUICK_SALE' },
        { label: isHinglish ? 'Reorder PO Banayein' : 'Generate Reorder PO', type: 'GENERATE_PO', payload: lowStock },
        { label: isHinglish ? 'Khata Receivables Dekhein' : 'Review Khata Ledger', type: 'NAVIGATE_KHATA' }
      ],
      followUps: [
        isHinglish ? 'Aaj kitna munafa kamaya?' : 'What are the profit that we made today?',
        isHinglish ? 'Mera sabse jyada bikne wala product koun sa hai?' : 'What is our best-selling product?',
        isHinglish ? 'Kounse product ka stock khatam ho raha hai?' : 'Which products need reordering?'
      ]
    };
  }

  // =========================================================================
  // 4. OVERALL STORE PERFORMANCE & EXECUTIVE BUSINESS HEALTH
  // Example queries: "how is business doing", "overall performance", "business health", "store audit"
  // =========================================================================
  const isOverallHealthQuery = 
    q.includes('how is business') || q.includes('how is the business') || q.includes('overall') ||
    q.includes('business doing') || q.includes('store performance') || q.includes('health') ||
    q.includes('audit') || q.includes('executive summary') || q.includes('full report') || q.includes('kaisa chal raha');

  if (isOverallHealthQuery) {
    const healthScore = lowStock.length <= 3 && totalUdhar < 500000 ? '92/100 (Excellent)' : '78/100 (Healthy with Action Items)';

    return {
      question: rawQuery,
      title: isHinglish ? `Vyapar Swasthya Audit (Store Health: ${healthScore})` : `Executive Store Health Audit (${healthScore})`,
      summary: isHinglish 
        ? `Aapke ${storeName} ka 360-degree business assessment report:`
        : `360-degree operational & financial diagnostic report for ${storeName}:`,
      insights: [
        isHinglish ? `💰 **Total Sales Turnover**: ₹${totalSales.toLocaleString('en-IN')} दर्ज` : `💰 **Active Sales Turnover**: ₹${totalSales.toLocaleString('en-IN')} total billing volume recorded`,
        isHinglish ? `📦 **Godown Inventory Value**: ₹${inventoryValue.toLocaleString('en-IN')} (${inventory.length} total SKUs)` : `📦 **Total Stock Valuation**: ₹${inventoryValue.toLocaleString('en-IN')} across ${inventory.length} active SKUs`,
        isHinglish ? `🤝 **Baki Udhar (Credit Risk)**: ₹${totalUdhar.toLocaleString('en-IN')} pending recovery` : `🤝 **Credit Risk Exposure**: ₹${totalUdhar.toLocaleString('en-IN')} pending across ${customers.filter(c => (Number(c.pendingAmount) || 0) > 0).length} parties`,
        isHinglish ? `⚡ **Stockout Risk**: ${lowStock.length} items safety limit se neeche` : `⚡ **Supply Chain Buffer**: ${lowStock.length} items below minimum safety buffers`
      ],
      recommendations: [
        isHinglish ? 'Udhar recovery ke liye automated WhatsApp reminders use karein taaki cash release ho.' : 'Accelerate receivables recovery via 1-click WhatsApp payment reminders with UPI QR codes.',
        isHinglish ? 'Fast-moving items par reorder PO generate karein taaki weekend par bikri na ruke.' : 'Generate reorder POs for top revenue drivers to ensure uninterrupted fulfillment.'
      ],
      actions: [
        { label: 'View Command Center', type: 'NAVIGATE_SALES' },
        { label: 'Generate Reorder PO', type: 'GENERATE_PO', payload: lowStock },
        { label: 'Review Khata Ledger', type: 'NAVIGATE_KHATA' }
      ],
      followUps: [
        isHinglish ? 'Aaj ka pura hisaab batao' : 'Summarize today\'s data',
        isHinglish ? 'Sabse bada debtor koun hai?' : 'Who owes me money?',
        isHinglish ? 'Sabse jyada bikne wala product koun sa hai?' : 'What is our best-selling product?'
      ]
    };
  }

  // =========================================================================
  // 5. TOP SELLING PRODUCTS & HERO SKUS
  // Example queries: "what is our best selling product", "top product", "hero product", "sabse jyada bikne wala"
  // =========================================================================
  const isBestSellerQuery = 
    q.includes('best sell') || q.includes('best product') || q.includes('top product') || 
    q.includes('top sell') || q.includes('fastest') || q.includes('hero product') || 
    q.includes('highest volume') || q.includes('sabse jyada bikne') || q.includes('most popular') ||
    q.includes('top item');

  if (isBestSellerQuery) {
    const sortedProducts = [...inventory].sort((a, b) => {
      const aVal = (Number(a.sellingPrice) || 0) * (Number(a.stock) || 0);
      const bVal = (Number(b.sellingPrice) || 0) * (Number(b.stock) || 0);
      return bVal - aVal;
    });

    return {
      question: rawQuery,
      title: isHinglish ? 'Top Selling & Volume Driver Products' : 'Top Performing & High-Volume SKUs',
      summary: isHinglish 
        ? `Aapke catalog ke sabse jyada demand aur revenue generate karne wale products:`
        : `Revenue champions and primary sales volume drivers identified across your store:`,
      insights: sortedProducts.slice(0, 4).map((p, idx) => {
        const margin = p.sellingPrice > 0 ? Math.round(((p.sellingPrice - p.costPrice) / p.sellingPrice) * 100) : 20;
        return isHinglish 
          ? `🏆 #${idx + 1} **${p.name}**: Bikri ₹${p.sellingPrice}/unit (Munafa: ${margin}%) • Stock bacha: ${p.stock} units`
          : `🏆 #${idx + 1} **${p.name}**: Sells at ₹${p.sellingPrice}/unit (${margin}% gross spread) • Available: ${p.stock} units`;
      }),
      recommendations: [
        isHinglish ? 'In top 3 products ka stock kabhi zero na hone dein; buffer hamesha 25+ units rakhein.' : 'Never allow hero products to stockout; maintain at least a 14-day rolling buffer at all times.',
        isHinglish ? 'In products ke sath slow-moving items ka combo banakar clearance karein.' : 'Bundle slower-moving items alongside these high-turnover SKUs to maximize basket value.'
      ],
      actions: [
        { label: 'View Inventory Catalog', type: 'NAVIGATE_INVENTORY' },
        { label: '+ Quick Counter Sale', type: 'OPEN_QUICK_SALE' }
      ],
      followUps: [
        isHinglish ? 'Aaj ka munafa kitna hua?' : 'What are the profit that we made today?',
        isHinglish ? 'Kounse items low stock par hain?' : 'Which products need reordering?',
        isHinglish ? 'Baki udhar kitna hai?' : 'Who owes me money?'
      ]
    };
  }

  // =========================================================================
  // 6. EXPENSES, COSTS & LOSS PREVENTION
  // Example queries: "where are we losing money", "reduce costs", "what are our expenses", "kharcha kam kaise karein"
  // =========================================================================
  const isCostLossQuery = 
    q.includes('losing money') || q.includes('loss') || q.includes('expense') || 
    q.includes('reduce cost') || q.includes('cut cost') || q.includes('kharcha') || 
    q.includes('leakage') || q.includes('where is money going');

  if (isCostLossQuery) {
    const idleCapital = Math.round(inventoryValue * 0.18);
    const lockedCredit = totalUdhar;

    return {
      question: rawQuery,
      title: isHinglish ? 'Cost Leakage & Munafa Bachat Vishleshan' : 'Cost Leakage & Operating Loss Prevention Diagnostic',
      summary: isHinglish 
        ? 'Aapke vyapar me paisa kahan fas raha hai aur kharcha kaise bachayein:'
        : 'Detailed financial diagnostic pinpointing working capital drag and expense reduction avenues:',
      insights: [
        isHinglish 
          ? `⏳ **Udhar Me Atka Working Capital**: ₹${lockedCredit.toLocaleString('en-IN')} market me baki hone se cash discount kho rahe hain.`
          : `⏳ **Credit Drag Opportunity Cost**: ₹${lockedCredit.toLocaleString('en-IN')} locked in unpaid Khata forfeits ~2-3% supplier cash settlement discounts.`,
        isHinglish 
          ? `📦 **Slow Godown Inventory**: Lagbhag ₹${idleCapital.toLocaleString('en-IN')} ka stock holding cost aur expiry risk badha raha hai.`
          : `📦 **Idle Inventory Holding**: Approximately ₹${idleCapital.toLocaleString('en-IN')} is tied in slow-rotating stock with storage and obsolescence overhead.`,
        isHinglish 
          ? `⚡ **Urgent Stockout Reorder Surcharges**: Low stock hone par emergency procurement me 3-5% extra lagta hai.`
          : `⚡ **Emergency Freight Premium**: Depleted safety buffers force last-minute reorders carrying avoidable expedited freight surcharges.`
      ],
      recommendations: [
        isHinglish ? 'Sabhi 21+ din purane debtors ko WhatsApp reminder bhein taaki 48 ghante me cash release ho.' : 'Trigger batch WhatsApp reminders to accounts overdue by >21 days to unlock immediate liquidity.',
        isHinglish ? 'Wholesale distributors se 50+ units par 3-4% upfront cash discount negotiate karein.' : 'Consolidate supplier orders to qualify for tiered 3-5% wholesale volume discounts.'
      ],
      actions: [
        { label: 'Send WhatsApp Reminders', type: 'OPEN_WHATSAPP_DRAWER', payload: customers[0] },
        { label: 'Review Khata Ledger', type: 'NAVIGATE_KHATA' }
      ],
      followUps: [
        isHinglish ? 'Aaj kitna munafa hua?' : 'What are the profit that we made today?',
        isHinglish ? 'Aaj ka hisaab summarize karo' : 'Summarize today\'s data',
        isHinglish ? 'Kounse product reorder karein?' : 'Which products need reordering?'
      ]
    };
  }

  // =========================================================================
  // 7. SPECIFIC CUSTOMER SEARCH (Entity Resolution)
  // =========================================================================
  const matchedCustomer = customers.find(c => {
    if (!c.name) return false;
    const nameParts = c.name.toLowerCase().split(/\s+/);
    return nameParts.some(part => part.length >= 3 && q.includes(part));
  });

  if (matchedCustomer) {
    const due = Number(matchedCustomer.pendingAmount) || 0;
    const purchases = Number(matchedCustomer.totalPurchases) || 0;
    const days = matchedCustomer.overdueDays || 14;

    return {
      question: rawQuery,
      title: isHinglish ? `Grahak Khata: ${matchedCustomer.name}` : `Party Ledger Account: ${matchedCustomer.name}`,
      summary: isHinglish 
        ? `${matchedCustomer.name} ka khata record live ledger se nikala gaya hai:`
        : `Direct account diagnostic pulled for customer party "${matchedCustomer.name}":`,
      insights: [
        isHinglish ? `💳 **Baki Udhar**: ₹${due.toLocaleString('en-IN')} (${days} din se pending)` : `💳 **Current Outstanding Udhar**: ₹${due.toLocaleString('en-IN')} (Overdue by ${days} days)`,
        isHinglish ? `🛍️ **Total Purchases**: ₹${purchases.toLocaleString('en-IN')} lifetime business` : `🛍️ **Total Lifetime Volume**: ₹${purchases.toLocaleString('en-IN')}`,
        isHinglish ? `📞 **Phone / WhatsApp**: ${matchedCustomer.phone || 'Available in directory'}` : `📞 **Contact Number**: ${matchedCustomer.phone || 'Recorded in directory'}`,
        isHinglish ? `⭐ **Credit Standing**: ${due > 20000 ? 'High Risk (>₹20k)' : 'Normal Risk'}` : `⭐ **Credit Risk Profile**: ${due > 20000 ? 'High Exposure (>₹20,000)' : 'Moderate / Healthy'}`
      ],
      recommendations: [
        due > 0 
          ? (isHinglish ? `Inhe turant polite WhatsApp payment reminder bhein jisme UPI QR link ho.` : `Send a courteous WhatsApp payment reminder with your direct UPI payment QR.`)
          : (isHinglish ? `Inka pura hisaab chukta hai. Inhe naye offers bhejein.` : `Account is fully settled with zero outstanding balance. Eligible for seasonal credit.`)
      ],
      actions: due > 0 ? [
        { label: `Send WhatsApp to ${matchedCustomer.name.split(' ')[0]}`, type: 'OPEN_WHATSAPP_DRAWER', payload: matchedCustomer },
        { label: 'View in Khata Ledger', type: 'NAVIGATE_KHATA' }
      ] : [
        { label: 'Open Customer Directory', type: 'NAVIGATE_CUSTOMERS' }
      ],
      followUps: [
        isHinglish ? 'Baki sabhi debtors ki list dikhao' : 'Show full debtors list',
        isHinglish ? 'Inke liye WhatsApp message draft karo' : `Draft payment reminder for ${matchedCustomer.name.split(' ')[0]}`,
        isHinglish ? 'Sabse purana udhar kiska hai?' : 'Who has the oldest overdue payment?'
      ]
    };
  }

  // =========================================================================
  // 3. SPECIFIC PRODUCT SEARCH (Entity Resolution)
  // =========================================================================
  const matchedProduct = inventory.find(i => {
    if (!i.name) return false;
    const nameParts = i.name.toLowerCase().split(/\s+/);
    return nameParts.some(part => part.length >= 3 && q.includes(part));
  });

  if (matchedProduct && !q.includes('all products') && !q.includes('sabhi product')) {
    const stock = Number(matchedProduct.stock) || 0;
    const minStock = Number(matchedProduct.minStock) || 10;
    const cost = Number(matchedProduct.costPrice) || 0;
    const sell = Number(matchedProduct.sellingPrice) || 0;
    const margin = sell > 0 ? Math.round(((sell - cost) / sell) * 100) : 0;
    const isLow = stock <= minStock;

    return {
      question: rawQuery,
      title: isHinglish ? `Product Vivaran: ${matchedProduct.name}` : `Inventory Item Profile: ${matchedProduct.name}`,
      summary: isHinglish 
        ? `Godown aur catalog se live stock data:`
        : `Real-time SKU performance & stock tracking for "${matchedProduct.name}":`,
      insights: [
        isHinglish ? `📦 **Bacha Stock**: ${stock} units (Safety reorder level: ${minStock} units)` : `📦 **Current Physical Stock**: ${stock} units (Safety threshold: ${minStock} units)`,
        isHinglish ? `🏷️ **Kharid / Bikri Price**: Kharid ₹${cost} | Bikri ₹${sell} (Unit profit: ₹${sell - cost})` : `🏷️ **Cost vs Selling Price**: Cost ₹${cost} | Selling ₹${sell} (Gross profit: ₹${sell - cost}/unit)`,
        isHinglish ? `📊 **Gross Margin**: ${margin}% profit margin` : `📊 **Unit Margin**: ${margin}% gross markup`,
        isHinglish ? `🏭 **Supplier**: ${matchedProduct.supplier || 'Primary Distributor'}` : `🏭 **Procurement Supplier**: ${matchedProduct.supplier || 'Primary Distributor'}`,
        isLow 
          ? (isHinglish ? '⚠️ **ALERT**: Stock safety limit se kam hai! Turant order karein.' : '⚠️ **STOCK ALERT**: Below minimum reorder buffer. High stockout risk!')
          : (isHinglish ? '✅ Stock level bilkul surakshit hai.' : '✅ Current stock level is healthy and sufficient.')
      ],
      recommendations: [
        isLow 
          ? (isHinglish ? `Supplier ko turant +${minStock * 2} units ka reorder PO bhein.` : `Generate purchase order for +${minStock * 2} units to maintain 14-day sales runway.`)
          : (isHinglish ? `Iss product par regular sales flow maintain rakhein.` : `Item moving steadily. Review inventory buffer again during weekend stock-taking.`)
      ],
      actions: [
        { label: `Reorder PO (${matchedProduct.name.split(' ')[0]})`, type: 'GENERATE_PO', payload: [matchedProduct] },
        { label: 'View Inventory Catalog', type: 'NAVIGATE_INVENTORY' }
      ],
      followUps: [
        isHinglish ? 'Aur kounse product low stock par hain?' : 'What other products are low on stock?',
        isHinglish ? 'Iss item ka stock kaise badhayein?' : 'How to adjust this stock count?',
        isHinglish ? 'Mera sabse jyada bikne wala item koun sa hai?' : 'What is my top-selling item?'
      ]
    };
  }

  // =========================================================================
  // 4. SALES, REVENUE & TURNOVER INQUIRIES
  // =========================================================================
  if (q.includes('sale') || q.includes('revenue') || q.includes('bikri') || q.includes('kamai') || q.includes('turnover') || q.includes('collection')) {
    const paidSales = transactions.filter(t => !t.status?.toLowerCase().includes('pending') && !t.paymentMode?.includes('Udhar'));
    const pendingSales = transactions.filter(t => t.status?.toLowerCase().includes('pending') || t.paymentMode?.includes('Udhar'));
    
    const paidAmount = paidSales.reduce((s, t) => s + (Number(t.total) || 0), 0);
    const pendingAmount = pendingSales.reduce((s, t) => s + (Number(t.total) || 0), 0);
    const avgBill = transactions.length > 0 ? Math.round(totalSales / transactions.length) : 0;

    return {
      question: rawQuery,
      title: isHinglish ? 'Sales & Revenue Vishleshan' : 'Comprehensive Sales & Revenue Diagnostics',
      summary: isHinglish 
        ? `Aapke vyapar ka kul bikri data (${transactions.length} bills/transactions ke aadhar par):`
        : `Overall sales performance diagnostics across ${transactions.length} recorded invoices:`,
      insights: [
        isHinglish ? `💰 **Total Sales Turnover**: ₹${totalSales.toLocaleString('en-IN')}` : `💰 **Total Sales Volume**: ₹${totalSales.toLocaleString('en-IN')}`,
        isHinglish ? `💵 **Cash / UPI Collection (Nokad)**: ₹${paidAmount.toLocaleString('en-IN')} (${transactions.length > 0 ? Math.round((paidAmount / (totalSales || 1)) * 100) : 0}% settled)` : `💵 **Cash & Digital Settlement**: ₹${paidAmount.toLocaleString('en-IN')} (${transactions.length > 0 ? Math.round((paidAmount / (totalSales || 1)) * 100) : 0}% settled)`,
        isHinglish ? `⏳ **Udhar / Credit Sales**: ₹${pendingAmount.toLocaleString('en-IN')} (${transactions.length > 0 ? Math.round((pendingAmount / (totalSales || 1)) * 100) : 0}% pending credit)` : `⏳ **Credit (Udhar) Volume**: ₹${pendingAmount.toLocaleString('en-IN')} (${transactions.length > 0 ? Math.round((pendingAmount / (totalSales || 1)) * 100) : 0}% on credit)`,
        isHinglish ? `🧾 **Average Bill Value**: ₹${avgBill.toLocaleString('en-IN')} per customer` : `🧾 **Average Ticket Size**: ₹${avgBill.toLocaleString('en-IN')} per checkout`
      ],
      recommendations: [
        isHinglish ? 'Naye counter bills ke liye Quick Bill feature ka use karein taaki stock aur sales turant tally ho.' : 'Use "+ Quick Bill / Sale" on the Sales page for fast counter checkouts with auto GST and invoice generation.',
        isHinglish ? 'Digital UPI payment par 1% instant incentive dekar udhar sales ko kam karein.' : 'Incentivize upfront UPI transactions with small cashback offers to shrink credit exposure.'
      ],
      actions: [
        { label: isHinglish ? '+ Naya Counter Bill Banayein' : '+ Quick Counter Sale', type: 'OPEN_QUICK_SALE' },
        { label: isHinglish ? 'Pura Sales Ledger Dekhein' : 'Open Sales Ledger', type: 'NAVIGATE_SALES' }
      ],
      followUps: [
        isHinglish ? 'Munafa kam kyu ho raha hai?' : 'Why did my profit decrease?',
        isHinglish ? 'Sabse jyada bikne wale item koun se hain?' : 'Which items have the highest volume?',
        isHinglish ? 'Udhar recover karne ka tareeka batao' : 'How can I speed up credit recovery?'
      ]
    };
  }

  // =========================================================================
  // 5. PRICE & MARGIN CALCULATOR (When numbers are present in query)
  // =========================================================================
  const numbersInQuery = rawQuery.match(/\d+(\.\d+)?/g);
  if ((q.includes('calc') || q.includes('calculate') || q.includes('margin') || q.includes('hisaab') || q.includes('buy') || q.includes('sell')) && numbersInQuery && numbersInQuery.length >= 2) {
    const num1 = parseFloat(numbersInQuery[0]);
    const num2 = parseFloat(numbersInQuery[1]);
    const cost = Math.min(num1, num2);
    const sell = Math.max(num1, num2);
    const profit = sell - cost;
    const marginPct = Math.round((profit / sell) * 100);
    const markupPct = Math.round((profit / cost) * 100);

    return {
      question: rawQuery,
      title: isHinglish ? `Margin Calculator: Kharid ₹${cost} | Bikri ₹${sell}` : `Unit Profit & Margin Calculation (₹${cost} vs ₹${sell})`,
      summary: isHinglish 
        ? `Aapke diye gaye rate (Cost: ₹${cost}, Selling: ₹${sell}) ka hisaab:`
        : `Calculated profitability breakdown for Cost ₹${cost} vs Selling Price ₹${sell}:`,
      insights: [
        `💵 **Net Profit Per Unit**: ₹${profit.toLocaleString('en-IN')}`,
        `📊 **Gross Margin (on Revenue)**: ${marginPct}%`,
        `📈 **Markup Percentage (on Cost)**: ${markupPct}%`,
        `🎯 **Category Assessment**: ${marginPct >= 20 ? 'Strong healthy margin (>20%)' : 'Volume-driven tight margin (<20%)'}`
      ],
      recommendations: [
        `At ₹${profit} profit/unit, selling 100 units yields ₹${(profit * 100).toLocaleString('en-IN')} gross margin.`,
        'Keep shipping and packaging costs below 3% of unit price to protect the net spread.'
      ],
      actions: [
        { label: '+ Add Product with this Margin', type: 'NAVIGATE_INVENTORY' }
      ],
      followUps: [
        isHinglish ? 'Mera sabse jyada margin wala item koun sa hai?' : 'Which product has my highest margin?',
        isHinglish ? 'Munafa kam kyu hua?' : 'Why did my profit decrease?',
        isHinglish ? 'Aaj ke 3 mukhya kaam kya hain?' : 'What should I focus on today?'
      ]
    };
  }

  // =========================================================================
  // 6. PROFIT, MARGINS & EXPENSES
  // =========================================================================
  if (q.includes('profit') || q.includes('munafa') || q.includes('margin') || q.includes('markup') || q.includes('decrease') || q.includes('ghata') || q.includes('kam kyu') || q.includes('bachat')) {
    const deadStockValue = inventory
      .filter(i => (Number(i.stock) || 0) > (Number(i.minStock) || 10) * 3)
      .reduce((sum, item) => sum + ((Number(item.stock) || 0) * (Number(item.costPrice) || 0)), 0);

    return {
      question: rawQuery,
      title: isHinglish ? 'Munafa & Margin Diagnostic Report' : 'Profitability & Margin Root-Cause Analysis',
      summary: isHinglish 
        ? 'Aapke store data ke anusar munafa badhane aur margin sudharne ke 3 mukhya bindu:'
        : 'Systematic financial breakdown isolating factors influencing your net operating margins:',
      insights: [
        isHinglish ? `📦 **Godown Me Fasa Paisa (Holding Capital)**: Lagbhag ₹${deadStockValue.toLocaleString('en-IN')} ka maal slow rotation me ruka hai.` : `📦 **Capital Tied in Idle Stock**: Approximately ₹${deadStockValue.toLocaleString('en-IN')} is locked in excess inventory buffers, suppressing liquidity.`,
        isHinglish ? `⏳ **Baki Udhar Ka Asar**: ₹${totalUdhar.toLocaleString('en-IN')} market me baki hone se wholesale cash discounts nahi mil pa rahe.` : `⏳ **Receivables Lag Drag**: ₹${totalUdhar.toLocaleString('en-IN')} in unpaid Udhar prevents capitalizing on 2-3% supplier upfront cash discounts.`,
        isHinglish ? `📈 **Average Inventory Gross Margin**: ~22-26% average category markup.` : `📈 **Average Store Gross Margin**: Benchmarked at ~24.5% across primary FMCG/hardware catalog.`
      ],
      recommendations: [
        isHinglish ? 'Slow-moving items par 10% Festival Combo discount lagakar holding cash release karein.' : 'Apply a 10% clearance combo bundle on slow-moving inventory to liberate locked working capital.',
        isHinglish ? 'Top 3 high-volume SKUs par 2-3% price revision karein jo market absorb kar sake.' : 'Recalibrate pricing on top volume drivers by 2-3% to comfortably expand net operating spread.'
      ],
      actions: [
        { label: isHinglish ? 'Clearance Promo Lagayein' : 'Apply Clearance Promo', type: 'CLEARANCE_PROMO' },
        { label: isHinglish ? 'Khata Collection Bhejein' : 'Send WhatsApp Recovery', type: 'OPEN_WHATSAPP_DRAWER', payload: customers[0] }
      ],
      followUps: [
        isHinglish ? 'Price aur margin calculate kaise karein?' : 'How to calculate optimal markup?',
        isHinglish ? 'Dead stock koun sa hai?' : 'Which items are slow-moving?',
        isHinglish ? 'Stock reorder kab karna chahiye?' : 'When should I reorder inventory?'
      ]
    };
  }

  // =========================================================================
  // 6. INVENTORY REORDERING & STOCKOUT ALERTS
  // =========================================================================
  if (q.includes('reorder') || q.includes('order') || q.includes('stock') || q.includes('maal') || q.includes('kharidna') || q.includes('khatam') || q.includes('depleted') || q.includes('godown')) {
    const reorderBatch = lowStock.map(item => {
      const stock = Number(item.stock) || 0;
      const min = Number(item.minStock) || 10;
      const cost = Number(item.costPrice) || 0;
      const suggestedQty = Math.max(min * 2 - stock, 10);
      return {
        ...item,
        suggestedOrderQty: suggestedQty,
        estimatedCost: suggestedQty * cost
      };
    });

    const totalEstimatedSpend = reorderBatch.reduce((sum, i) => sum + i.estimatedCost, 0);

    return {
      question: rawQuery,
      title: isHinglish ? `Stock Reorder Intelligence (${lowStock.length} Items)` : `Automated Reorder Intelligence (${lowStock.length} SKUs Alert)`,
      summary: isHinglish 
        ? `Aapke catalog ke ${lowStock.length} items safety stock boundary se neeche aa gaye hain:`
        : `Identified ${lowStock.length} SKUs that have breached minimum safety thresholds:`,
      insights: reorderBatch.length > 0 
        ? reorderBatch.slice(0, 5).map(item => 
            isHinglish 
              ? `🔴 **${item.name}**: Bacha stock **${item.stock} pcs** (Min: ${item.minStock}). Mangwayein: **+${item.suggestedOrderQty} pcs** (Kharcha: ₹${item.estimatedCost.toLocaleString('en-IN')})`
              : `🔴 **${item.name}**: Stock: **${item.stock} pcs** (Safety Min: ${item.minStock}). Recommended Reorder: **+${item.suggestedOrderQty} pcs** (Est: ₹${item.estimatedCost.toLocaleString('en-IN')})`
          )
        : [isHinglish ? '✅ Sabhi products ke paas paryapt stock maujood hai.' : '✅ All inventory items currently maintain healthy buffer margins.'],
      recommendations: [
        reorderBatch.length > 0 
          ? (isHinglish ? `Kul anumanit kharid budget: ₹${totalEstimatedSpend.toLocaleString('en-IN')}. Supplier ko PO bhein.` : `Estimated procurement investment: ₹${totalEstimatedSpend.toLocaleString('en-IN')}. Place purchase order to prevent weekend stockouts.`)
          : (isHinglish ? `Naye stock add karne ke liye Inventory page par '+ Add Item' use karein.` : `To register new products or adjust counts, use "+ Add Item" on the Inventory page.`)
      ],
      actions: reorderBatch.length > 0 ? [
        { label: isHinglish ? '1-Click Reorder PO Banayein' : 'Generate Reorder PO', type: 'GENERATE_PO', payload: reorderBatch },
        { label: isHinglish ? 'Inventory Matrix Kholein' : 'Open Inventory Matrix', type: 'NAVIGATE_INVENTORY' }
      ] : [
        { label: 'View Inventory Catalog', type: 'NAVIGATE_INVENTORY' }
      ],
      followUps: [
        isHinglish ? 'Top 3 suppliers ke naam batao' : 'Who are my key suppliers?',
        isHinglish ? 'Inventory ki kul keemat kitni hai?' : 'What is my total inventory valuation?',
        isHinglish ? 'Slow-moving items kaise nikalein?' : 'How to clear slow-moving goods?'
      ]
    };
  }

  // =========================================================================
  // 7. WHO OWES MONEY / KHATA RECEIVABLES / UDHAR
  // =========================================================================
  if (q.includes('who owes') || q.includes('owes') || q.includes('udhar') || q.includes('khata') || q.includes('paisa lena') || q.includes('baki') || q.includes('debt') || q.includes('receivable') || q.includes('overdue')) {
    const sortedDebtors = [...customers]
      .filter(c => (Number(c.pendingAmount) || 0) > 0)
      .sort((a, b) => (Number(b.pendingAmount) || 0) - (Number(a.pendingAmount) || 0));

    return {
      question: rawQuery,
      title: isHinglish ? `Baki Udhar (Khata) Report (${sortedDebtors.length} Debtors)` : `Outstanding Receivables (Udhar) Ledger (${sortedDebtors.length} Accounts)`,
      summary: isHinglish 
        ? `Kul milakar **₹${totalUdhar.toLocaleString('en-IN')}** ka udhar ${sortedDebtors.length} parties par baki hai:`
        : `Outstanding customer receivables total **₹${totalUdhar.toLocaleString('en-IN')}** across ${sortedDebtors.length} debtor accounts:`,
      insights: sortedDebtors.slice(0, 5).map(c => 
        isHinglish 
          ? `👤 **${c.name}**: **₹${Number(c.pendingAmount).toLocaleString('en-IN')}** baki (${c.overdueDays || 14} din se) — Phone: ${c.phone || 'Available'}`
          : `👤 **${c.name}**: **₹${Number(c.pendingAmount).toLocaleString('en-IN')}** overdue by ${c.overdueDays || 14} days (Contact: ${c.phone || 'Listed'})`
      ),
      recommendations: [
        isHinglish 
          ? `Sabhi debtors ko direct WhatsApp reminder bhein jisme UPI ID (${upiId}) shamil ho.`
          : `Send 1-click WhatsApp reminders containing instant UPI payment links (${upiId}) for direct settlement.`,
        isHinglish 
          ? `Payments view me jakar 'Record Payment' button se partial ya full payment turant record karein.`
          : `Record collected settlements via the "Record Payment" button on the Payments & Khata page.`
      ],
      actions: sortedDebtors.length > 0 ? [
        { label: `WhatsApp Reminder (${sortedDebtors[0]?.name?.split(' ')[0] || 'Party'})`, type: 'OPEN_WHATSAPP_DRAWER', payload: sortedDebtors[0] },
        { label: isHinglish ? 'Khata Ledger Kholein' : 'Open Khata Ledger', type: 'NAVIGATE_KHATA' }
      ] : [
        { label: 'View Customer Accounts', type: 'NAVIGATE_CUSTOMERS' }
      ],
      followUps: [
        isHinglish ? 'WhatsApp reminder message kaisa likhein?' : 'Draft a polite WhatsApp payment reminder',
        isHinglish ? 'High priority accounts koun se hain?' : 'Which debtor accounts are over ₹20,000?',
        isHinglish ? 'Naya customer add kaise karein?' : 'How do I add a new customer party?'
      ]
    };
  }

  // =========================================================================
  // 8. DRAFT WHATSAPP REMINDER MESSAGE
  // =========================================================================
  if (q.includes('draft') || q.includes('message') || q.includes('template') || q.includes('sandesh') || q.includes('likh do') || q.includes('whatsapp text')) {
    const topDebtor = customers.find(c => (Number(c.pendingAmount) || 0) > 0) || { name: 'Customer Ji', pendingAmount: 15000, overdueDays: 21 };
    const draftText = `Namaste ${topDebtor.name} Ji! 🙏
Aapke business account me ${storeName} ka kul ₹${Number(topDebtor.pendingAmount).toLocaleString('en-IN')} ka hisaab baki hai.
Kripya niche diye gaye UPI ID par payment transfer karein ya link se pay karein:
UPI ID: ${upiId}
Aapke nirantar sahyog ke liye dhanyawad! 🤝
— ${business.owner || 'Proprietor'}, ${storeName}`;

    return {
      question: rawQuery,
      title: isHinglish ? 'WhatsApp Payment Reminder Sandesh' : 'Ready-to-Send WhatsApp Payment Reminder',
      summary: isHinglish 
        ? `Aapke store ke liye taiyar kiya gaya polite WhatsApp message template:`
        : `Personalized, polite collection template formatted with your store details and UPI credentials:`,
      insights: [
        `📝 **Message Preview**:`,
        `> *${draftText.replace(/\n/g, '<br/>> *')}*`
      ],
      recommendations: [
        isHinglish ? 'Aap iss message ko copy karke kisi bhi customer ko seedha WhatsApp kar sakte hain.' : 'You can copy this text or use the 1-click WhatsApp button to auto-fill the customer details.',
        isHinglish ? 'Payment milne par Khata ledger me "Record Payment" button se hisaab update karein.' : 'Once paid, record settlement on Payments page to automatically balance customer accounts.'
      ],
      actions: [
        { label: isHinglish ? 'Top Debtor Ko WhatsApp Kholein' : 'Open WhatsApp Drawer', type: 'OPEN_WHATSAPP_DRAWER', payload: topDebtor },
        { label: isHinglish ? 'Khata Ledger Dekhein' : 'Open Payments View', type: 'NAVIGATE_KHATA' }
      ],
      followUps: [
        isHinglish ? 'Sabse bada debtor koun hai?' : 'Who owes the highest amount?',
        isHinglish ? 'Aaj ke 3 mukhya kaam kya hain?' : 'What are today’s priorities?',
        isHinglish ? 'Festival demand forecast dikhao' : 'Show festival demand forecast'
      ]
    };
  }

  // =========================================================================
  // 9. DAILY PRIORITIES, FOCUS & SOP CHECKLIST
  // =========================================================================
  if (q.includes('focus') || q.includes('today') || q.includes('aaj') || q.includes('kya karu') || q.includes('priority') || q.includes('checklist') || q.includes('routine')) {
    const briefing = generateDailyBriefing(business);
    return {
      question: rawQuery,
      title: isHinglish ? 'Aaj Ka Executive Routine: 3 Sabse Zaroori Kaam' : 'Daily Executive Operating Checklist (3 Key Priorities)',
      summary: briefing.greeting,
      insights: [
        `🌅 **Morning Protocol**: Review low stock alerts (${lowStock.length} SKUs below threshold) and approve supplier POs.`,
        `☀️ **Afternoon Operations**: Monitor counter sales pace and trigger batch WhatsApp reminders to top overdue debtors.`,
        `🌙 **Evening Closing**: Reconcile daily UPI vs Cash collections and tally closing drawer balance.`
      ],
      recommendations: [
        isHinglish ? 'Rozana in teeno steps ko follow karne se cash flow hamesha positive rehta hai.' : 'Maintaining this disciplined daily rhythm prevents working capital bottlenecks and stockouts.',
        isHinglish ? 'Kisi bhi transaction ke turant baad Quick Sale register karein.' : 'Ensure all sales are logged via Quick Sale for 100% tax invoice accuracy.'
      ],
      actions: briefing.topPriorities.map(p => ({
        label: p.actionLabel,
        type: p.actionType,
        payload: p.actionPayload
      })),
      followUps: [
        isHinglish ? 'Baki udhar kitna hai?' : 'How much Udhar is pending?',
        isHinglish ? 'Festival surge kaise handle karein?' : 'How to prepare for festival demand?',
        isHinglish ? 'Mera munafa kaise badhayein?' : 'How to boost profit margins?'
      ]
    };
  }

  // =========================================================================
  // 10. FESTIVAL, SEASONAL SURGE & PROMOTIONS
  // =========================================================================
  if (q.includes('festival') || q.includes('diwali') || q.includes('demand') || q.includes('season') || q.includes('tehwar') || q.includes('puja') || q.includes('holi') || q.includes('eid') || q.includes('surge')) {
    return {
      question: rawQuery,
      title: isHinglish ? 'Festival Surge Strategy & Growth Plan' : 'Festival & Seasonal Demand Blueprint (+45% Surge)',
      summary: isHinglish 
        ? 'Aane wale festival season me retail footfall aur order size me 40-60% badhotari hoti hai:'
        : 'Predictive seasonal simulation models a +45% footfall and basket size surge during festival cycles:',
      insights: [
        '🎁 **Gift & Premium Bundles**: Create combo hampers pairing fast-moving staples with higher-margin accessories.',
        '📦 **Advance Buffer Stock**: Pre-order 15 days of inventory buffer at least 2-3 weeks early to secure wholesale discounts.',
        '💳 **Digital QR Display**: Ensure store counter UPI QR codes are prominently displayed — digital transactions jump to ~75% during festive shopping.',
        '🤝 **Pre-Festive Udhar Clearance**: Collect outstanding debts before festive week so customers have refreshed credit budgets.'
      ],
      recommendations: [
        isHinglish ? 'Suppliers se bulk booking par 3-5% additional cash discount negotiate karein.' : 'Pre-book supplier allocations early to avoid peak transportation surcharges and wholesale price spikes.',
        isHinglish ? 'Top 20 loyal grahakon ko festival WhatsApp greetings ke sath special voucher bhejein.' : 'Broadcast festive promotional vouchers to your registered customer directory.'
      ],
      actions: [
        { label: isHinglish ? 'Demand Simulator Kholein' : 'Open Demand Simulator', type: 'NAVIGATE_FORECAST' },
        { label: isHinglish ? 'Bulk PO Banayein' : 'Prepare Bulk PO', type: 'GENERATE_PO', payload: lowStock }
      ],
      followUps: [
        isHinglish ? 'Slow stock par clearance offer kaise lagayein?' : 'How to run a clearance bundle?',
        isHinglish ? 'Sabse jyada bikne wale item koun se hain?' : 'Which items have the highest demand?',
        isHinglish ? 'Naya customer kaise add karein?' : 'How to register a new customer?'
      ]
    };
  }

  // =========================================================================
  // 12. GENERAL CATCH-ALL INTELLIGENT SYNTHESIS
  // =========================================================================
  return {
    question: rawQuery,
    title: isHinglish ? `VyaparAI Analysis: "${rawQuery}"` : `Business Intelligence Synthesis: "${rawQuery}"`,
    summary: isHinglish 
      ? `Aapke sawal par live business data se nikala gaya vishleshan:`
      : `Contextual diagnostic synthesized across your live store ledger:`,
    insights: [
      isHinglish ? `💰 **Current Sales Revenue**: ₹${totalSales.toLocaleString('en-IN')} total turnover दर्ज.` : `💰 **Active Sales Volume**: ₹${totalSales.toLocaleString('en-IN')} across current ledger records.`,
      isHinglish ? `📦 **Catalog Inventory Status**: ${healthyStock.length} healthy SKUs, ${lowStock.length} items low stock par.` : `📦 **Catalog Stock Health**: ${healthyStock.length} healthy SKUs, ${lowStock.length} SKUs below reorder point.`,
      isHinglish ? `🤝 **Khata Credit Exposure**: ₹${totalUdhar.toLocaleString('en-IN')} pending udhar collection.` : `🤝 **Pending Receivables**: ₹${totalUdhar.toLocaleString('en-IN')} in customer Khata balances.`
    ],
    recommendations: [
      isHinglish 
        ? 'Aap mujhse kisi bhi grahak ke naam, product ke stock, ya sales ke baare me seedha poochh sakte hain.'
        : 'You can query any specific customer party name, product SKU, daily sales metrics, or profit diagnostics.',
      isHinglish 
        ? 'Neeche diye gaye action buttons se seedha store manage karein.'
        : 'Click any of the direct action buttons below to resolve operational tasks instantly.'
    ],
    actions: [
      { label: isHinglish ? 'Stock Matrix Kholein' : 'View Stock Catalog', type: 'NAVIGATE_INVENTORY' },
      { label: isHinglish ? 'Khata Ledger Kholein' : 'Review Khata Receivables', type: 'NAVIGATE_KHATA' },
      { label: isHinglish ? 'Sales Ledger Kholein' : 'Open Sales Ledger', type: 'NAVIGATE_SALES' }
    ],
    followUps: [
      isHinglish ? 'Kounse product ka stock khatam ho raha hai?' : 'Which products need reordering?',
      isHinglish ? 'Sabse jyada udhar kiska baki hai?' : 'Who owes me the most money?',
      isHinglish ? 'Munafa kam kyu hua?' : 'Why did my profit decrease?'
    ]
  };
};
