// ==========================================================================
// POSTGRESQL-COMPATIBLE SCHEMAS FOR VYAPARAI OS
// Standardized Business Fields for Sales, Inventory, and Customers
// ==========================================================================

export const DATASET_TYPES = {
  SALES: 'sales',
  INVENTORY: 'inventory',
  CUSTOMERS: 'customers'
};

export const SCHEMAS = {
  // 1. SALES SCHEMA (Maps to SQL: `sales_transactions`)
  [DATASET_TYPES.SALES]: {
    id: 'sales',
    name: 'Sales & Orders',
    tableName: 'sales_transactions',
    description: 'Transaction records, invoices, selling prices, costs, and profits.',
    fields: [
      {
        key: 'date',
        label: 'Date',
        sqlType: 'DATE',
        type: 'date',
        required: true,
        description: 'Transaction or invoice date',
        aliases: ['date', 'bill_date', 'billdate', 'order_date', 'tarikh', 'invoice_date', 'txn_date', 'sale_date']
      },
      {
        key: 'invoiceId',
        label: 'Invoice ID',
        sqlType: 'VARCHAR(100)',
        type: 'string',
        required: false,
        unique: true,
        description: 'Unique bill or invoice number',
        aliases: ['invoice_id', 'invoice', 'bill_no', 'bill_number', 'inv_no', 'order_id', 'order_number', 'txn_id']
      },
      {
        key: 'product',
        label: 'Product',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: true,
        description: 'Product or item title',
        aliases: ['product', 'product_name', 'item', 'item_name', 'description', 'goods', 'maal', 'sku_name']
      },
      {
        key: 'category',
        label: 'Category',
        sqlType: 'VARCHAR(100)',
        type: 'string',
        required: false,
        default: 'General',
        description: 'Item group or department',
        aliases: ['category', 'group', 'type', 'dept', 'classification', 'segment']
      },
      {
        key: 'quantity',
        label: 'Quantity',
        sqlType: 'INTEGER',
        type: 'number',
        required: true,
        min: 1,
        description: 'Number of units sold',
        aliases: ['quantity', 'qty', 'units', 'pcs', 'count', 'nag', 'nos', 'kg', 'packets']
      },
      {
        key: 'sellingPrice',
        label: 'Selling Price',
        sqlType: 'NUMERIC(12,2)',
        type: 'number',
        required: true,
        min: 0,
        description: 'Price per unit charged to customer (₹)',
        aliases: ['selling_price', 'price', 'rate', 'sp', 'unit_price', 'bikri_rate', 'bikri_bhav', 'mrp']
      },
      {
        key: 'revenue',
        label: 'Revenue',
        sqlType: 'NUMERIC(14,2)',
        type: 'number',
        required: false,
        computed: true,
        description: 'Total sale amount (₹) (Qty × Selling Price)',
        aliases: ['revenue', 'total', 'amount', 'net_amount', 'bill_amount', 'total_amount', 'value']
      },
      {
        key: 'cost',
        label: 'Cost',
        sqlType: 'NUMERIC(12,2)',
        type: 'number',
        required: false,
        description: 'Cost price of goods sold (₹)',
        aliases: ['cost', 'cost_price', 'cp', 'purchase_price', 'purchase_rate', 'kharid_rate', 'kharid_bhav']
      },
      {
        key: 'profit',
        label: 'Profit',
        sqlType: 'NUMERIC(14,2)',
        type: 'number',
        required: false,
        computed: true,
        description: 'Net margin on sale (₹) (Revenue - Cost)',
        aliases: ['profit', 'margin', 'net_profit', 'munafa', 'net_margin']
      },
      {
        key: 'customer',
        label: 'Customer',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: true,
        description: 'Customer or party name',
        aliases: ['customer', 'customer_name', 'party', 'party_name', 'grahak', 'client', 'buyer', 'name']
      }
    ]
  },

  // 2. INVENTORY SCHEMA (Maps to SQL: `inventory_items`)
  [DATASET_TYPES.INVENTORY]: {
    id: 'inventory',
    name: 'Inventory & Stock',
    tableName: 'inventory_items',
    description: 'Product catalogue, stock balances, costs, and reorder levels.',
    fields: [
      {
        key: 'product',
        label: 'Product',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: true,
        description: 'Name of the stock item',
        aliases: ['product', 'product_name', 'item', 'item_name', 'goods', 'maal', 'title']
      },
      {
        key: 'sku',
        label: 'SKU',
        sqlType: 'VARCHAR(100)',
        type: 'string',
        required: false,
        unique: true,
        description: 'Stock Keeping Unit / Product Code',
        aliases: ['sku', 'sku_code', 'item_code', 'product_code', 'barcode', 'item_id']
      },
      {
        key: 'category',
        label: 'Category',
        sqlType: 'VARCHAR(100)',
        type: 'string',
        required: false,
        default: 'General Store',
        description: 'Product category or classification',
        aliases: ['category', 'group', 'type', 'dept', 'classification']
      },
      {
        key: 'currentStock',
        label: 'Current Stock',
        sqlType: 'INTEGER',
        type: 'number',
        required: true,
        min: 0,
        description: 'Available units in store / warehouse',
        aliases: ['current_stock', 'stock', 'stock_qty', 'balance_qty', 'available_stock', 'qty_in_hand', 'pcs']
      },
      {
        key: 'costPrice',
        label: 'Cost Price',
        sqlType: 'NUMERIC(12,2)',
        type: 'number',
        required: true,
        min: 0,
        description: 'Purchase cost per unit from supplier (₹)',
        aliases: ['cost_price', 'cost', 'cp', 'purchase_price', 'purchase_rate', 'kharid_bhav']
      },
      {
        key: 'sellingPrice',
        label: 'Selling Price',
        sqlType: 'NUMERIC(12,2)',
        type: 'number',
        required: true,
        min: 0,
        description: 'Retail selling price / MRP (₹)',
        aliases: ['selling_price', 'price', 'sp', 'rate', 'bikri_rate', 'bikri_bhav', 'mrp']
      },
      {
        key: 'supplier',
        label: 'Supplier',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: false,
        default: 'Primary Distributor',
        description: 'Vendor or distributor providing this SKU',
        aliases: ['supplier', 'vendor', 'distributor', 'dealer', 'agency', 'wholesaler']
      },
      {
        key: 'reorderLevel',
        label: 'Reorder Level',
        sqlType: 'INTEGER',
        type: 'number',
        required: false,
        default: 10,
        min: 0,
        description: 'Minimum safety stock before trigger alert',
        aliases: ['reorder_level', 'min_stock', 'safety_stock', 'minimum_buffer', 'reorder_point', 'low_stock_limit']
      }
    ]
  },

  // 3. CUSTOMERS SCHEMA (Maps to SQL: `customers_ledger`)
  [DATASET_TYPES.CUSTOMERS]: {
    id: 'customers',
    name: 'Customers & Khata',
    tableName: 'customers_ledger',
    description: 'Customer contact profiles, lifetime purchase value, and pending credit.',
    fields: [
      {
        key: 'customerName',
        label: 'Customer Name',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: true,
        description: 'Full name or firm name of the buyer',
        aliases: ['customer_name', 'customer', 'party', 'party_name', 'grahak', 'client', 'name', 'firm_name']
      },
      {
        key: 'phone',
        label: 'Phone',
        sqlType: 'VARCHAR(30)',
        type: 'string',
        required: false,
        description: 'Mobile or WhatsApp number',
        aliases: ['phone', 'mobile', 'contact', 'whatsapp', 'phone_number', 'mobile_number', 'tel']
      },
      {
        key: 'email',
        label: 'Email',
        sqlType: 'VARCHAR(255)',
        type: 'string',
        required: false,
        description: 'Customer email address',
        aliases: ['email', 'email_address', 'mail']
      },
      {
        key: 'totalPurchases',
        label: 'Total Purchases',
        sqlType: 'NUMERIC(14,2)',
        type: 'number',
        required: false,
        default: 0,
        min: 0,
        description: 'Cumulative lifetime purchase value (₹)',
        aliases: ['total_purchases', 'total_sales', 'lifetime_value', 'total_business', 'turnover', 'gross_purchase']
      },
      {
        key: 'amountPaid',
        label: 'Amount Paid',
        sqlType: 'NUMERIC(14,2)',
        type: 'number',
        required: false,
        default: 0,
        min: 0,
        description: 'Total amount collected from customer (₹)',
        aliases: ['amount_paid', 'paid', 'total_paid', 'collected', 'received', 'jama']
      },
      {
        key: 'amountDue',
        label: 'Amount Due',
        sqlType: 'NUMERIC(14,2)',
        type: 'number',
        required: false,
        default: 0,
        min: 0,
        description: 'Pending Udhar / balance to collect (₹)',
        aliases: ['amount_due', 'due', 'balance', 'outstanding', 'udhar', 'baki', 'pending_amount']
      },
      {
        key: 'dueDate',
        label: 'Due Date',
        sqlType: 'DATE',
        type: 'date',
        required: false,
        description: 'Credit due date for payment settlement',
        aliases: ['due_date', 'payment_due_date', 'expiry_date', 'last_date', 'settle_by']
      }
    ]
  }
};
