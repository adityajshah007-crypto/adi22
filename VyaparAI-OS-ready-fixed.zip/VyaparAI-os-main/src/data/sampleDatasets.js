// Sample Indian SMB Datasets for VyaparAI OS
// Realistic data representing 4 diverse Indian business sectors:
// 1. Bharat Kirana & Supermart (FMCG & Groceries)
// 2. Rajesh Mobile & Electronics (Retail Tech & Gadgets)
// 3. Om Garments & Textiles (Apparel Wholesale & Retail)
// 4. Balaji Hardware & Electricals (Building Materials & Tools)

export const sampleBusinesses = [
  {
    id: 'kirana',
    name: 'Bharat Kirana & Supermart',
    tagline: 'Wholesale & Retail FMCG, Grains & Groceries',
    owner: 'Rameshwar Gupta',
    location: 'Chandni Chowk, Old Delhi',
    gstin: '07AAAAA0000A1Z5',
    upiId: 'bharatkirana@okaxis',
    currency: 'INR',
    stats: {
      monthlySalesTarget: 1200000,
      cashReserve: 285000,
      avgDailyFootfall: 140,
    },
    inventory: [
      { id: 'INV-101', name: 'India Gate Basmati Rice (10kg)', category: 'Staples & Grains', stock: 14, minStock: 25, costPrice: 920, sellingPrice: 1150, supplier: 'KRBL Agri Ltd', leadTimeDays: 3, lastRestocked: '2026-08-20', salesVelocity: 'High' },
      { id: 'INV-102', name: 'Fortune Sunlite Sunflower Oil (5L)', category: 'Edible Oils', stock: 8, minStock: 20, costPrice: 560, sellingPrice: 650, supplier: 'Adani Wilmar Dist', leadTimeDays: 2, lastRestocked: '2026-08-22', salesVelocity: 'High' },
      { id: 'INV-103', name: 'Tata Salt Vacuum Evaporated (1kg)', category: 'Spices & Essentials', stock: 65, minStock: 30, costPrice: 21, sellingPrice: 28, supplier: 'Tata Consumer Local', leadTimeDays: 2, lastRestocked: '2026-09-02', salesVelocity: 'High' },
      { id: 'INV-104', name: 'Aashirvaad Shudh Chakki Atta (10kg)', category: 'Staples & Grains', stock: 12, minStock: 30, costPrice: 410, sellingPrice: 485, supplier: 'ITC Supply Hub', leadTimeDays: 3, lastRestocked: '2026-08-18', salesVelocity: 'High' },
      { id: 'INV-105', name: 'Amul Butter Salted (500g)', category: 'Dairy & Cold', stock: 5, minStock: 15, costPrice: 245, sellingPrice: 285, supplier: 'Delhi Milk Union', leadTimeDays: 1, lastRestocked: '2026-09-05', salesVelocity: 'High' },
      { id: 'INV-106', name: 'Everest Turmeric Powder (200g)', category: 'Spices & Masala', stock: 45, minStock: 20, costPrice: 52, sellingPrice: 70, supplier: 'Everest Masala Agency', leadTimeDays: 4, lastRestocked: '2026-08-10', salesVelocity: 'Medium' },
      { id: 'INV-107', name: 'Surf Excel Quick Wash Powder (2kg)', category: 'Household Care', stock: 18, minStock: 15, costPrice: 320, sellingPrice: 390, supplier: 'Hindustan Unilever Dist', leadTimeDays: 3, lastRestocked: '2026-08-25', salesVelocity: 'Medium' },
      { id: 'INV-108', name: 'Cadbury Celebrations Gift Pack (Premium)', category: 'Chocolates & Confectionery', stock: 42, minStock: 10, costPrice: 280, sellingPrice: 350, supplier: 'Mondelez India', leadTimeDays: 5, lastRestocked: '2026-07-15', salesVelocity: 'Slow (Dead Stock until Festival)' },
      { id: 'INV-109', name: 'Organic Cold Pressed Mustard Oil (1L Glass)', category: 'Edible Oils', stock: 28, minStock: 5, costPrice: 220, sellingPrice: 310, supplier: 'Kisan Organic Co', leadTimeDays: 7, lastRestocked: '2026-06-12', salesVelocity: 'Dead Stock (>80 days)' },
      { id: 'INV-110', name: 'Maggi 2-Minute Noodles (Pack of 12)', category: 'Instant Food', stock: 35, minStock: 25, costPrice: 140, sellingPrice: 168, supplier: 'Nestle Distribution', leadTimeDays: 2, lastRestocked: '2026-09-01', salesVelocity: 'High' },
    ],
    transactions: [
      { id: 'TXN-901', date: '2026-09-08', customer: 'Sharmaji Caterers', item: 'India Gate Basmati Rice (10kg)', qty: 6, unitPrice: 1150, total: 6900, cost: 5520, profit: 1380, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-902', date: '2026-09-08', customer: 'Deepak Sweet House', item: 'Fortune Sunlite Sunflower Oil (5L)', qty: 5, unitPrice: 650, total: 3250, cost: 2800, profit: 450, paymentMode: 'UPI (PhonePe)', status: 'Paid' },
      { id: 'TXN-903', date: '2026-09-07', customer: 'Sunita Mehra', item: 'Aashirvaad Shudh Chakki Atta (10kg)', qty: 2, unitPrice: 485, total: 970, cost: 820, profit: 150, paymentMode: 'Cash (Rokad)', status: 'Paid' },
      { id: 'TXN-904', date: '2026-09-07', customer: 'Verma PG Hostel', item: 'Tata Salt Vacuum Evaporated (1kg)', qty: 15, unitPrice: 28, total: 420, cost: 315, profit: 105, paymentMode: 'UPI (GPay)', status: 'Paid' },
      { id: 'TXN-905', date: '2026-09-06', customer: 'Gupta Fast Food Corner', item: 'Fortune Sunlite Sunflower Oil (5L)', qty: 8, unitPrice: 640, total: 5120, cost: 4480, profit: 640, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-906', date: '2026-09-06', customer: 'Anil Dhaba', item: 'India Gate Basmati Rice (10kg)', qty: 5, unitPrice: 1150, total: 5750, cost: 4600, profit: 1150, paymentMode: 'Bank Transfer (NEFT)', status: 'Paid' },
      { id: 'TXN-907', date: '2026-09-05', customer: 'Preeti Rawat', item: 'Amul Butter Salted (500g)', qty: 4, unitPrice: 285, total: 1140, cost: 980, profit: 160, paymentMode: 'UPI (Paytm)', status: 'Paid' },
      { id: 'TXN-908', date: '2026-09-04', customer: 'Aggarwal Sweets', item: 'India Gate Basmati Rice (10kg)', qty: 10, unitPrice: 1120, total: 11200, cost: 9200, profit: 2000, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-909', date: '2026-09-03', customer: 'Walk-in Retail', item: 'Maggi 2-Minute Noodles (Pack of 12)', qty: 3, unitPrice: 168, total: 504, cost: 420, profit: 84, paymentMode: 'Cash (Rokad)', status: 'Paid' },
      { id: 'TXN-910', date: '2026-09-02', customer: 'Mohan Tea Stall', item: 'Everest Turmeric Powder (200g)', qty: 6, unitPrice: 70, total: 420, cost: 312, profit: 108, paymentMode: 'UPI (PhonePe)', status: 'Paid' },
      { id: 'TXN-911', date: '2026-08-28', customer: 'Verma PG Hostel', item: 'Aashirvaad Shudh Chakki Atta (10kg)', qty: 8, unitPrice: 485, total: 3880, cost: 3280, profit: 600, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-912', date: '2026-08-25', customer: 'Chawla Family', item: 'Surf Excel Quick Wash Powder (2kg)', qty: 2, unitPrice: 390, total: 780, cost: 640, profit: 140, paymentMode: 'Cash (Rokad)', status: 'Paid' },
    ],
    customers: [
      { id: 'CUST-01', name: 'Sharmaji Caterers', phone: '+91 98112 34567', pendingAmount: 24500, overdueDays: 34, creditLimit: 30000, trustScore: 'Moderate', notes: 'Major customer for weddings, usually pays in 45 days. Follow up for Dussehra booking.' },
      { id: 'CUST-02', name: 'Gupta Fast Food Corner', phone: '+91 98731 22890', pendingAmount: 14800, overdueDays: 21, creditLimit: 15000, trustScore: 'High', notes: 'Daily oil and grains customer. Has paid ₹10k last week.' },
      { id: 'CUST-03', name: 'Aggarwal Sweets', phone: '+91 99104 88712', pendingAmount: 38200, overdueDays: 42, creditLimit: 40000, trustScore: 'High Risk (Delayed)', notes: 'Over credit limit by 2 days, promises to clear on Monday.' },
      { id: 'CUST-04', name: 'Verma PG Hostel', phone: '+91 93120 77419', pendingAmount: 8900, overdueDays: 14, creditLimit: 12000, trustScore: 'Good', notes: 'Monthly student mess bill, clears on 10th of every month.' },
      { id: 'CUST-05', name: 'Sunil Grocery Sub-dealer', phone: '+91 98211 44520', pendingAmount: 5600, overdueDays: 7, creditLimit: 10000, trustScore: 'Good', notes: 'Small sub-store in Daryaganj.' },
    ],
    monthlyTrends: [
      { month: 'Apr', revenue: 780000, profit: 140000, expenses: 640000, udharGiven: 120000, udharRecovered: 95000 },
      { month: 'May', revenue: 840000, profit: 152000, expenses: 688000, udharGiven: 135000, udharRecovered: 110000 },
      { month: 'Jun', revenue: 810000, profit: 138000, expenses: 672000, udharGiven: 140000, udharRecovered: 105000 },
      { month: 'Jul', revenue: 890000, profit: 165000, expenses: 725000, udharGiven: 155000, udharRecovered: 130000 },
      { month: 'Aug', revenue: 945000, profit: 142000, expenses: 803000, udharGiven: 180000, udharRecovered: 125000 },
      { month: 'Sep (Est)', revenue: 1050000, profit: 178000, expenses: 872000, udharGiven: 160000, udharRecovered: 150000 },
    ]
  },
  {
    id: 'electronics',
    name: 'Rajesh Mobile & Electronics',
    tagline: 'Retail Smartphones, Gadgets & Audio Gear',
    owner: 'Rajesh Patel',
    location: 'Ring Road, Surat, Gujarat',
    gstin: '24BBBBB1111B2Z4',
    upiId: 'rajeshmobile@icici',
    currency: 'INR',
    stats: {
      monthlySalesTarget: 2500000,
      cashReserve: 620000,
      avgDailyFootfall: 65,
    },
    inventory: [
      { id: 'INV-201', name: 'Realme 12 Pro 5G (8GB/256GB)', category: 'Smartphones', stock: 3, minStock: 8, costPrice: 21500, sellingPrice: 24999, supplier: 'Shree Sai Mobile Dist', leadTimeDays: 2, lastRestocked: '2026-08-29', salesVelocity: 'High' },
      { id: 'INV-202', name: 'boAt Airdopes 141 ANC Earbuds', category: 'Audio & Accessories', stock: 7, minStock: 20, costPrice: 950, sellingPrice: 1499, supplier: 'Imagine Marketing Direct', leadTimeDays: 4, lastRestocked: '2026-08-15', salesVelocity: 'High' },
      { id: 'INV-203', name: 'OnePlus Nord CE4 5G (8GB/128GB)', category: 'Smartphones', stock: 2, minStock: 6, costPrice: 21200, sellingPrice: 23999, supplier: 'Apex Telecom Surat', leadTimeDays: 3, lastRestocked: '2026-08-26', salesVelocity: 'High' },
      { id: 'INV-204', name: 'Mi 20000mAh Power Bank 3i (18W)', category: 'Power & Charging', stock: 12, minStock: 10, costPrice: 1450, sellingPrice: 1999, supplier: 'Xiaomi Logistics', leadTimeDays: 5, lastRestocked: '2026-08-10', salesVelocity: 'Medium' },
      { id: 'INV-205', name: 'Noise ColorFit Pulse 3 Smartwatch', category: 'Wearables', stock: 4, minStock: 12, costPrice: 1100, sellingPrice: 1799, supplier: 'Nexxbase Audio', leadTimeDays: 4, lastRestocked: '2026-08-18', salesVelocity: 'High' },
      { id: 'INV-206', name: '9D Edge-to-Edge Tempered Glass (Assorted)', category: 'Accessories', stock: 110, minStock: 50, costPrice: 25, sellingPrice: 150, supplier: 'Ghaas Mandi Wholesaler', leadTimeDays: 1, lastRestocked: '2026-09-03', salesVelocity: 'Very High' },
      { id: 'INV-207', name: 'Old Gen Micro-USB Cables 1m (Pack of 50)', category: 'Cables & Adapters', stock: 85, minStock: 10, costPrice: 30, sellingPrice: 60, supplier: 'Surat Tech Hub', leadTimeDays: 2, lastRestocked: '2026-05-10', salesVelocity: 'Dead Stock (Type-C transition)' },
      { id: 'INV-208', name: 'Ambrane 65W GaN Fast Charger', category: 'Power & Charging', stock: 9, minStock: 8, costPrice: 1250, sellingPrice: 1899, supplier: 'Apex Telecom Surat', leadTimeDays: 3, lastRestocked: '2026-08-20', salesVelocity: 'Medium' },
    ],
    transactions: [
      { id: 'TXN-801', date: '2026-09-08', customer: 'Ketan Desai (Diamond Broker)', item: 'Realme 12 Pro 5G (8GB/256GB)', qty: 1, unitPrice: 24999, total: 24999, cost: 21500, profit: 3499, paymentMode: 'UPI (GPay)', status: 'Paid' },
      { id: 'TXN-802', date: '2026-09-08', customer: 'Chirag Mobile Care (B2B)', item: '9D Edge-to-Edge Tempered Glass (Assorted)', qty: 25, unitPrice: 110, total: 2750, cost: 625, profit: 2125, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-803', date: '2026-09-07', customer: 'Bhavna Ben', item: 'boAt Airdopes 141 ANC Earbuds', qty: 2, unitPrice: 1499, total: 2998, cost: 1900, profit: 1098, paymentMode: 'Card (Swipe)', status: 'Paid' },
      { id: 'TXN-804', date: '2026-09-07', customer: 'Vipul Enterprise Staff', item: 'Noise ColorFit Pulse 3 Smartwatch', qty: 3, unitPrice: 1799, total: 5397, cost: 3300, profit: 2097, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-805', date: '2026-09-06', customer: 'Pooja Jariwala', item: 'OnePlus Nord CE4 5G (8GB/128GB)', qty: 1, unitPrice: 23999, total: 23999, cost: 21200, profit: 2799, paymentMode: 'Bajaj Finserv EMI', status: 'Paid' },
      { id: 'TXN-806', date: '2026-09-05', customer: 'Harish Bhai Repair Shop', item: 'Mi 20000mAh Power Bank 3i (18W)', qty: 4, unitPrice: 1950, total: 7800, cost: 5800, profit: 2000, paymentMode: 'Udhar / Credit', status: 'Pending' },
    ],
    customers: [
      { id: 'CUST-21', name: 'Chirag Mobile Care (B2B)', phone: '+91 98251 90812', pendingAmount: 48500, overdueDays: 38, creditLimit: 50000, trustScore: 'Medium', notes: 'Local repair shop buying accessories in bulk. Check stock before extending credit.' },
      { id: 'CUST-22', name: 'Vipul Enterprise Staff', phone: '+91 97274 33190', pendingAmount: 22400, overdueDays: 19, creditLimit: 25000, trustScore: 'High', notes: 'Corporate gifting purchases. Clears monthly via NEFT.' },
      { id: 'CUST-23', name: 'Harish Bhai Repair Shop', phone: '+91 98240 66511', pendingAmount: 18900, overdueDays: 45, creditLimit: 20000, trustScore: 'High Risk (Critical)', notes: 'Overdue by 45 days. WhatsApp reminder needed urgently.' },
    ],
    monthlyTrends: [
      { month: 'Apr', revenue: 1650000, profit: 245000, expenses: 1405000, udharGiven: 220000, udharRecovered: 180000 },
      { month: 'May', revenue: 1820000, profit: 275000, expenses: 1545000, udharGiven: 250000, udharRecovered: 210000 },
      { month: 'Jun', revenue: 1710000, profit: 230000, expenses: 1480000, udharGiven: 240000, udharRecovered: 195000 },
      { month: 'Jul', revenue: 1950000, profit: 290000, expenses: 1660000, udharGiven: 280000, udharRecovered: 260000 },
      { month: 'Aug', revenue: 2120000, profit: 260000, expenses: 1860000, udharGiven: 310000, udharRecovered: 240000 },
      { month: 'Sep (Est)', revenue: 2400000, profit: 340000, expenses: 2060000, udharGiven: 320000, udharRecovered: 290000 },
    ]
  },
  {
    id: 'garments',
    name: 'Om Garments & Textiles',
    tagline: 'Wholesale Kurtis, Ethnic Wear & Daily Cottons',
    owner: 'Manish Chawla',
    location: 'Gandhi Nagar / Cloth Market, Ludhiana',
    gstin: '03CCCCC2222C3Z3',
    upiId: 'omgarments@okhdfcbank',
    currency: 'INR',
    stats: {
      monthlySalesTarget: 1800000,
      cashReserve: 410000,
      avgDailyFootfall: 50,
    },
    inventory: [
      { id: 'INV-301', name: 'Jaipuri Pure Cotton Kurti Set (L/XL)', category: 'Ethnic Wear', stock: 15, minStock: 40, costPrice: 480, sellingPrice: 799, supplier: 'Sanganer Print Works', leadTimeDays: 6, lastRestocked: '2026-08-14', salesVelocity: 'High' },
      { id: 'INV-302', name: 'Anarkali Festive Heavy Gown (Rayon)', category: 'Festive Wear', stock: 8, minStock: 25, costPrice: 850, sellingPrice: 1499, supplier: 'Surat Textile Mill #4', leadTimeDays: 7, lastRestocked: '2026-08-10', salesVelocity: 'High' },
      { id: 'INV-303', name: 'Men Pure Linen Formal Shirt (Pack of 3)', category: 'Menswear', stock: 12, minStock: 20, costPrice: 920, sellingPrice: 1599, supplier: 'Ludhiana Mills Ltd', leadTimeDays: 4, lastRestocked: '2026-08-22', salesVelocity: 'Medium' },
      { id: 'INV-304', name: 'Comfort Stretch Denim Jeans (Slim Fit)', category: 'Menswear', stock: 30, minStock: 25, costPrice: 490, sellingPrice: 899, supplier: 'Bhilwara Textiles', leadTimeDays: 5, lastRestocked: '2026-08-28', salesVelocity: 'High' },
      { id: 'INV-305', name: 'Winter Velvet Shawl Embroidered', category: 'Seasonal / Winter', stock: 55, minStock: 10, costPrice: 450, sellingPrice: 850, supplier: 'Amritsar Shawl Hub', leadTimeDays: 10, lastRestocked: '2026-03-01', salesVelocity: 'Dead Stock (Off-season)' },
    ],
    transactions: [
      { id: 'TXN-701', date: '2026-09-08', customer: 'Pooja Designer Boutique', item: 'Jaipuri Pure Cotton Kurti Set (L/XL)', qty: 20, unitPrice: 750, total: 15000, cost: 9600, profit: 5400, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-702', date: '2026-09-07', customer: 'Soniya Garment Store (Shimla)', item: 'Anarkali Festive Heavy Gown (Rayon)', qty: 12, unitPrice: 1450, total: 17400, cost: 10200, profit: 7200, paymentMode: 'Bank Transfer (RTGS)', status: 'Paid' },
      { id: 'TXN-703', date: '2026-09-06', customer: 'Ritu Collections', item: 'Comfort Stretch Denim Jeans (Slim Fit)', qty: 15, unitPrice: 850, total: 12750, cost: 7350, profit: 5400, paymentMode: 'UPI (PhonePe)', status: 'Paid' },
    ],
    customers: [
      { id: 'CUST-31', name: 'Pooja Designer Boutique', phone: '+91 98144 55210', pendingAmount: 52000, overdueDays: 40, creditLimit: 60000, trustScore: 'Moderate', notes: 'Boutique owner stocking up for Karwa Chauth and Diwali. Requires payment reminder.' },
      { id: 'CUST-32', name: 'Modern Wear Retail Jalandhar', phone: '+91 98722 11984', pendingAmount: 28000, overdueDays: 18, creditLimit: 40000, trustScore: 'High', notes: 'Regular monthly buyer.' },
    ],
    monthlyTrends: [
      { month: 'Apr', revenue: 1100000, profit: 290000, expenses: 810000, udharGiven: 320000, udharRecovered: 270000 },
      { month: 'May', revenue: 1250000, profit: 340000, expenses: 910000, udharGiven: 360000, udharRecovered: 310000 },
      { month: 'Jun', revenue: 1180000, profit: 305000, expenses: 875000, udharGiven: 340000, udharRecovered: 290000 },
      { month: 'Jul', revenue: 1320000, profit: 360000, expenses: 960000, udharGiven: 390000, udharRecovered: 340000 },
      { month: 'Aug', revenue: 1450000, profit: 390000, expenses: 1060000, udharGiven: 420000, udharRecovered: 370000 },
      { month: 'Sep (Est)', revenue: 1750000, profit: 480000, expenses: 1270000, udharGiven: 490000, udharRecovered: 430000 },
    ]
  },
  {
    id: 'hardware',
    name: 'Balaji Hardware & Electricals',
    tagline: 'Sanitary Ware, Electrical Supplies, Tools & Paints',
    owner: 'Suresh Prajapati',
    location: 'Katraj-Kondhwa Road, Pune, Maharashtra',
    gstin: '27DDDDD3333D4Z2',
    upiId: 'balajihardware@ybl',
    currency: 'INR',
    stats: {
      monthlySalesTarget: 1500000,
      cashReserve: 340000,
      avgDailyFootfall: 45,
    },
    inventory: [
      { id: 'INV-401', name: 'Havells 1.5 Sqmm Copper Wire (90m Red)', category: 'Electrical Cables', stock: 11, minStock: 25, costPrice: 1420, sellingPrice: 1750, supplier: 'Havells Pune Agency', leadTimeDays: 2, lastRestocked: '2026-08-25', salesVelocity: 'High' },
      { id: 'INV-402', name: 'Asian Paints Apex Ultima White (20L)', category: 'Paints & Primers', stock: 4, minStock: 12, costPrice: 4200, sellingPrice: 4950, supplier: 'Asian Paints Depot', leadTimeDays: 3, lastRestocked: '2026-08-20', salesVelocity: 'High' },
      { id: 'INV-403', name: 'Astral CPVC Pipe 1 inch (3 Meter)', category: 'Plumbing & Sanitary', stock: 18, minStock: 30, costPrice: 280, sellingPrice: 360, supplier: 'Astral Pipes Hub', leadTimeDays: 3, lastRestocked: '2026-08-24', salesVelocity: 'High' },
      { id: 'INV-404', name: 'Bosch Professional Impact Drill GSB 550', category: 'Power Tools', stock: 2, minStock: 5, costPrice: 2850, sellingPrice: 3499, supplier: 'Bosch Power India', leadTimeDays: 5, lastRestocked: '2026-08-12', salesVelocity: 'Medium' },
      { id: 'INV-405', name: 'Philips 9W LED Cool Day Bulb (Pack of 10)', category: 'Lighting & Bulbs', stock: 40, minStock: 20, costPrice: 650, sellingPrice: 850, supplier: 'Signify Lighting', leadTimeDays: 2, lastRestocked: '2026-09-02', salesVelocity: 'High' },
    ],
    transactions: [
      { id: 'TXN-601', date: '2026-09-08', customer: 'Kadam Construction Contractors', item: 'Asian Paints Apex Ultima White (20L)', qty: 4, unitPrice: 4950, total: 19800, cost: 16800, profit: 3000, paymentMode: 'Udhar / Credit', status: 'Pending' },
      { id: 'TXN-602', date: '2026-09-07', customer: 'Ramesh Plumber & Fitters', item: 'Astral CPVC Pipe 1 inch (3 Meter)', qty: 12, unitPrice: 360, total: 4320, cost: 3360, profit: 960, paymentMode: 'UPI (GPay)', status: 'Paid' },
      { id: 'TXN-603', date: '2026-09-06', customer: 'Shinde Electrical Works', item: 'Havells 1.5 Sqmm Copper Wire (90m Red)', qty: 6, unitPrice: 1750, total: 10500, cost: 8520, profit: 1980, paymentMode: 'Udhar / Credit', status: 'Pending' },
    ],
    customers: [
      { id: 'CUST-41', name: 'Kadam Construction Contractors', phone: '+91 98901 44321', pendingAmount: 64000, overdueDays: 32, creditLimit: 75000, trustScore: 'Medium', notes: 'Civil contractor working on Kondhwa residential project.' },
      { id: 'CUST-42', name: 'Shinde Electrical Works', phone: '+91 94220 87110', pendingAmount: 21500, overdueDays: 16, creditLimit: 25000, trustScore: 'High', notes: 'Licensed electrical contractor.' },
    ],
    monthlyTrends: [
      { month: 'Apr', revenue: 950000, profit: 185000, expenses: 765000, udharGiven: 280000, udharRecovered: 220000 },
      { month: 'May', revenue: 1080000, profit: 210000, expenses: 870000, udharGiven: 310000, udharRecovered: 260000 },
      { month: 'Jun', revenue: 1150000, profit: 225000, expenses: 925000, udharGiven: 330000, udharRecovered: 280000 },
      { month: 'Jul', revenue: 980000, profit: 180000, expenses: 800000, udharGiven: 290000, udharRecovered: 250000 },
      { month: 'Aug', revenue: 1240000, profit: 245000, expenses: 995000, udharGiven: 370000, udharRecovered: 310000 },
      { month: 'Sep (Est)', revenue: 1420000, profit: 280000, expenses: 1140000, udharGiven: 390000, udharRecovered: 350000 },
    ]
  }
];
