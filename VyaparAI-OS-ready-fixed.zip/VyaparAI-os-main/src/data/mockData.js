// ==========================================================================
// VYAPARAI OS — MOCK DATA FOUNDATION FOR INDIAN SMB
// ==========================================================================

export const mockBusinessProfile = {
  name: "Bharat Enterprises & Retail",
  owner: "Rajesh Sharma",
  type: "Supermart & Wholesale FMCG",
  location: "Chandni Chowk, Delhi",
  gstin: "07AAAAA0000A1Z5",
  upiId: "bharatenterprises@upi",
  currency: "INR"
};

// 8 Core KPIs for Command Center
export const mockKPIs = {
  revenue: {
    value: 2485000, // ₹24.85 L
    formatted: "₹24,85,000",
    trend: "+14.8%",
    trendPositive: true,
    subtext: "vs. last month"
  },
  profit: {
    value: 542000, // ₹5.42 L
    formatted: "₹5,42,000",
    trend: "+8.2%",
    trendPositive: true,
    subtext: "net earnings"
  },
  profitMargin: {
    value: 21.8,
    formatted: "21.8%",
    trend: "-1.4%",
    trendPositive: false,
    subtext: "target: 24.0%"
  },
  sales: {
    value: 1420,
    formatted: "1,420 units",
    trend: "+19.4%",
    trendPositive: true,
    subtext: "units moved"
  },
  inventoryValue: {
    value: 1860000, // ₹18.6 L
    formatted: "₹18,60,000",
    trend: "Healthy",
    trendPositive: true,
    subtext: "142 active SKUs"
  },
  lowStock: {
    value: 12,
    formatted: "12 items",
    trend: "Action Required",
    trendPositive: false,
    subtext: "below safety buffer"
  },
  outstandingPayments: {
    value: 385000, // ₹3.85 L
    formatted: "₹3,85,000",
    trend: "5 overdue >30d",
    trendPositive: false,
    subtext: "uncollected Udhar"
  },
  orders: {
    value: 384,
    formatted: "384 orders",
    trend: "+11.2%",
    trendPositive: true,
    subtext: "this billing cycle"
  }
};

// Sales Trend Data (Monthly / Cycle)
export const mockSalesTrend = [
  { period: "Apr", revenue: 1650000, profit: 380000, salesUnits: 980 },
  { period: "May", revenue: 1820000, profit: 410000, salesUnits: 1060 },
  { period: "Jun", revenue: 1780000, profit: 390000, salesUnits: 1020 },
  { period: "Jul", revenue: 1950000, profit: 450000, salesUnits: 1140 },
  { period: "Aug", revenue: 2160000, profit: 480000, salesUnits: 1280 },
  { period: "Sep (MTD)", revenue: 2485000, profit: 542000, salesUnits: 1420 },
];

// Top Performing Products
export const mockTopProducts = [
  { id: "PROD-01", name: "Fortune Sunlite Sunflower Oil (5L)", category: "Edible Oils", unitsSold: 284, revenue: 184600, margin: "16.5%", status: "High Demand" },
  { id: "PROD-02", name: "India Gate Basmati Rice Feast (10kg)", category: "Grains & Staples", unitsSold: 210, revenue: 241500, margin: "22.4%", status: "High Demand" },
  { id: "PROD-03", name: "Aashirvaad Shudh Chakki Atta (10kg)", category: "Grains & Staples", unitsSold: 195, revenue: 94575, margin: "18.2%", status: "Steady" },
  { id: "PROD-04", name: "Tata Salt Vacuum Evaporated (1kg)", category: "Spices & Essentials", unitsSold: 460, revenue: 12880, margin: "28.0%", status: "Steady" },
  { id: "PROD-05", name: "Amul Butter Salted (500g)", category: "Dairy & Cold", unitsSold: 160, revenue: 45600, margin: "14.8%", status: "High Demand" },
];

// Low Stock Products
export const mockLowStockProducts = [
  { id: "SKU-102", name: "Fortune Sunflower Oil 5L", currentStock: 8, safetyBuffer: 25, reorderQty: 40, supplier: "Adani Wilmar Agency", leadDays: 2, priority: "Critical" },
  { id: "SKU-104", name: "Aashirvaad Atta 10kg", currentStock: 12, safetyBuffer: 30, reorderQty: 50, supplier: "ITC Hub Delhi", leadDays: 3, priority: "High" },
  { id: "SKU-101", name: "India Gate Basmati Rice 10kg", currentStock: 14, safetyBuffer: 30, reorderQty: 35, supplier: "KRBL Mandi Dist", leadDays: 2, priority: "High" },
  { id: "SKU-105", name: "Amul Butter 500g", currentStock: 5, safetyBuffer: 15, reorderQty: 25, supplier: "Delhi Milk Union", leadDays: 1, priority: "Urgent" },
];

// Recent Activity / Sales
export const mockRecentActivity = [
  { id: "TXN-108", time: "12 mins ago", party: "Sharmaji Caterers", action: "Order Placed", amount: "₹6,900", mode: "Udhar / Credit", status: "Pending" },
  { id: "TXN-107", time: "45 mins ago", party: "Deepak Sweets", action: "Payment Received", amount: "₹3,250", mode: "UPI (PhonePe)", status: "Completed" },
  { id: "TXN-106", time: "2 hours ago", party: "Verma PG Mess", action: "Order Placed", amount: "₹4,120", mode: "Cash (Rokad)", status: "Completed" },
  { id: "TXN-105", time: "3 hours ago", party: "Aggarwal Bakers", action: "Invoice Generated", amount: "₹11,200", mode: "Udhar / Credit", status: "Pending" },
  { id: "TXN-104", time: "5 hours ago", party: "Gupta Store", action: "Payment Settle", amount: "₹8,500", mode: "UPI (GPay)", status: "Completed" },
];

// AI Insights for Command Center
export const mockAIInsights = [
  {
    id: "ai-1",
    tag: "Profit Diagnostics",
    title: "Profit Margin Contracted by 1.4% This Cycle",
    detail: "Wholesale acquisition cost on edible oils and pulses increased by 5.2%, while retail prices remained constant to protect market share.",
    recommendation: "Recalibrate selling prices on top 3 bulk volume SKUs or negotiate cash settlement discount with distributors.",
    actionText: "Review Pricing"
  },
  {
    id: "ai-2",
    tag: "Inventory Warning",
    title: "4 Top Revenue Drivers Nearing Stockout",
    detail: "Current inventory of Sunflower Oil and Basmati Rice will exhaust in less than 48 hours based on weekend sales velocity.",
    recommendation: "Place an automated purchase order with suppliers today to avoid stockout during weekend rush.",
    actionText: "Prepare PO"
  },
  {
    id: "ai-3",
    tag: "Khata / Receivables",
    title: "₹3,85,000 Overdue in Customer Credit",
    detail: "5 customer accounts have balances exceeding 30 days overdue, tying up working capital.",
    recommendation: "Send friendly automated WhatsApp payment reminders with your UPI VPA to recover dues.",
    actionText: "Send Reminders"
  }
];
