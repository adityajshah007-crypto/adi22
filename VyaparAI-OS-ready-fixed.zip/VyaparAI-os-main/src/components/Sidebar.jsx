import React from 'react';
import { 
  LayoutDashboard, 
  Bot, 
  ShoppingBag, 
  Package, 
  Users, 
  WalletCards, 
  TrendingUp, 
  Zap, 
  FileBarChart2, 
  Settings, 
  UploadCloud, 
  Store,
  LogOut,
  Sparkles,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Sidebar = ({ 
  activeTab, 
  setActiveTab, 
  businessProfile, 
  onOpenImportModal,
  lowStockCount = 12,
  pendingUdharCount = 5,
  isOpen = false,
  onClose
}) => {
  const { logout } = useAuth();

  // Navigation Items
  const navigationItems = [
    { id: 'command-center', label: 'Command Center', icon: LayoutDashboard },
    { id: 'pitch-deck', label: 'Investor Deck', icon: Sparkles, badge: 'Pitch', badgeColor: 'saffron' },
    { id: 'ai-advisor', label: 'AI Advisor', icon: Bot, badge: 'AI Live' },
    { id: 'sales', label: 'Sales', icon: ShoppingBag },
    { id: 'inventory', label: 'Inventory', icon: Package, badge: lowStockCount > 0 ? `${lowStockCount}` : null, badgeColor: 'danger' },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'payments', label: 'Payments', icon: WalletCards, badge: pendingUdharCount > 0 ? `${pendingUdharCount} Due` : null, badgeColor: 'amber' },
    { id: 'forecasts', label: 'Forecasts', icon: TrendingUp },
    { id: 'actions', label: 'Actions', icon: Zap },
    { id: 'reports', label: 'Reports', icon: FileBarChart2 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleTabClick = (id) => {
    setActiveTab(id);
    if (onClose) onClose();
  };

  const handleImportClick = () => {
    onOpenImportModal();
    if (onClose) onClose();
  };

  return (
    <aside className={`app-sidebar ${isOpen ? 'open' : ''}`}>
      {/* Brand Header */}
      <div className="sidebar-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div className="sidebar-brand-icon">
            <span>V</span>
          </div>
          <div className="sidebar-brand-text">
            <span className="brand-title">VyaparAI OS</span>
            <span className="brand-subtitle">AI SMB Platform</span>
          </div>
        </div>
        {onClose && (
          <button 
            className="sidebar-close-btn" 
            onClick={onClose}
            aria-label="Close navigation"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Prominent Import Data Button in Sidebar */}
      <div style={{ padding: '16px 14px 6px' }}>
        <button 
          className="btn-primary"
          onClick={handleImportClick}
          style={{
            width: '100%',
            justifyContent: 'center',
            fontSize: '13px',
            padding: '10px 14px',
            fontWeight: 700
          }}
        >
          <UploadCloud size={16} />
          <span>Import Business Data</span>
        </button>
      </div>

      {/* Navigation List */}
      <div className="sidebar-nav-container">
        <div>
          <div className="sidebar-section-label">Main Navigation</div>
          <ul className="sidebar-nav-list">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <li key={item.id}>
                  <button
                    className={`nav-item-btn ${isActive ? 'active' : ''}`}
                    onClick={() => handleTabClick(item.id)}
                  >
                    <Icon size={18} />
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className={`nav-badge ${item.badgeColor ? `badge-${item.badgeColor}` : ''}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>

      {/* Business & Owner Profile Footer */}
      <div className="sidebar-footer">
        <div className="user-profile-pill" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0, flex: 1 }}>
            <div className="user-avatar">
              <Store size={16} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {businessProfile.name}
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {businessProfile.owner || 'Owner'} • {businessProfile.location || 'India'}
              </div>
            </div>
          </div>
          <button
            onClick={() => logout()}
            title="Sign out of business"
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--text-muted)',
              padding: '4px',
              borderRadius: '6px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'color 0.15s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.color = 'var(--badge-text-red)'}
            onMouseLeave={(e) => e.currentTarget.style.color = 'var(--text-muted)'}
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
};

