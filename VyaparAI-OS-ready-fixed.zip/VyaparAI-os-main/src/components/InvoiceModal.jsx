import React from 'react';
import { X, Printer, Download, Store, ShieldCheck } from 'lucide-react';
import { formatINR } from '../utils/formatters';

export const InvoiceModal = ({ isOpen, onClose, sale, business }) => {
  if (!isOpen || !sale) return null;

  const invoiceId = sale.invoiceId || '#INV-101';
  const invoiceDate = sale.date || new Date().toISOString().split('T')[0];
  const customerName = sale.customer || 'Counter Cash Sale';
  const productName = sale.product || 'Standard Merchandise';
  const quantity = Number(sale.quantity) || 1;
  const unitPrice = Number(sale.sellingPrice) || Math.round((Number(sale.revenue) || 1000) / quantity);
  const totalAmount = Number(sale.revenue) || (quantity * unitPrice);

  // 18% GST calculation (Base + 9% CGST + 9% SGST)
  const basePrice = Math.round(totalAmount / 1.18);
  const totalGst = totalAmount - basePrice;
  const cgst = Math.round(totalGst / 2);
  const sgst = totalGst - cgst;

  const upiVpa = business?.upiId || business?.upi_id || 'bharatenterprises@upi';
  const upiQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=${encodeURIComponent(
    `upi://pay?pa=${upiVpa}&pn=${encodeURIComponent(business?.name || 'Vyapar Store')}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent(`Invoice ${invoiceId}`)}`
  )}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content" 
        style={{ maxWidth: '680px', width: '95%' }} 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Store size={18} color="var(--brand-saffron)" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              GST Tax Invoice & Cash Memo ({invoiceId})
            </h3>
          </div>
          <button className="header-icon-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        {/* Printable Invoice Container */}
        <div 
          className="modal-body" 
          id="printable-invoice"
          style={{ 
            backgroundColor: '#ffffff', 
            color: '#0f172a', 
            padding: '24px', 
            borderRadius: '10px', 
            border: '1px solid #e2e8f0',
            fontFamily: "'Plus Jakarta Sans', sans-serif"
          }}
        >
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0f172a', paddingBottom: '16px' }}>
            <div>
              <div style={{ fontSize: '11px', fontWeight: 800, color: '#0284c7', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                ORIGINAL TAX INVOICE (FOR RECIPIENT)
              </div>
              <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a', margin: '4px 0 2px' }}>
                {business?.name || 'Bharat Enterprises & Retail'}
              </h2>
              <div style={{ fontSize: '12px', color: '#475569' }}>
                {business?.location || 'Chandni Chowk, Delhi, 110006'}
              </div>
              <div style={{ fontSize: '12px', color: '#475569', marginTop: '2px' }}>
                <strong>GSTIN:</strong> {business?.gstin || '07AAAAA0000A1Z5'} • <strong>Prop:</strong> {business?.owner || 'Rajesh Sharma'}
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '14px', fontWeight: 800, color: '#2563eb' }}>{invoiceId}</div>
              <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {invoiceDate}</div>
              <div style={{ fontSize: '11px', color: '#16a34a', fontWeight: 700, marginTop: '4px' }}>
                STATUS: SETTLED / PAID
              </div>
            </div>
          </div>

          {/* Bill To & Dispatch */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', margin: '16px 0', padding: '12px', backgroundColor: '#f8fafc', borderRadius: '8px', fontSize: '12px' }}>
            <div>
              <span style={{ color: '#64748b', fontWeight: 600, display: 'block', textTransform: 'uppercase', fontSize: '10px' }}>Billed To:</span>
              <strong style={{ fontSize: '13.5px', color: '#0f172a' }}>{customerName}</strong>
              <div style={{ color: '#475569' }}>Verified Registered Customer Account</div>
              <div style={{ color: '#475569' }}>Place of Supply: Intra-State (Delhi)</div>
            </div>
            <div>
              <span style={{ color: '#64748b', fontWeight: 600, display: 'block', textTransform: 'uppercase', fontSize: '10px' }}>Payment Mode & Settlement:</span>
              <strong style={{ color: '#0f172a' }}>UPI / Digital Counter Settlement</strong>
              <div style={{ color: '#475569' }}>VPA: {upiVpa}</div>
              <div style={{ color: '#475569' }}>Category: {sale.category || 'Wholesale & Retail FMCG'}</div>
            </div>
          </div>

          {/* Itemized Table */}
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12.5px', marginTop: '8px' }}>
            <thead>
              <tr style={{ backgroundColor: '#f1f5f9', borderBottom: '1px solid #cbd5e1' }}>
                <th style={{ padding: '8px', textAlign: 'left', color: '#334155' }}>Item Description</th>
                <th style={{ padding: '8px', textAlign: 'center', color: '#334155' }}>HSN</th>
                <th style={{ padding: '8px', textAlign: 'center', color: '#334155' }}>Qty</th>
                <th style={{ padding: '8px', textAlign: 'right', color: '#334155' }}>Unit Rate (₹)</th>
                <th style={{ padding: '8px', textAlign: 'right', color: '#334155' }}>Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                <td style={{ padding: '10px 8px', fontWeight: 600, color: '#0f172a' }}>{productName}</td>
                <td style={{ padding: '10px 8px', textAlign: 'center', color: '#64748b' }}>2106</td>
                <td style={{ padding: '10px 8px', textAlign: 'center', fontWeight: 700 }}>{quantity}</td>
                <td style={{ padding: '10px 8px', textAlign: 'right' }}>{formatINR(unitPrice)}</td>
                <td style={{ padding: '10px 8px', textAlign: 'right', fontWeight: 700 }}>{formatINR(totalAmount)}</td>
              </tr>
            </tbody>
          </table>

          {/* Subtotals and QR Code Section */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e2e8f0' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div style={{ padding: '4px', border: '1px solid #e2e8f0', borderRadius: '6px', backgroundColor: '#ffffff' }}>
                <img 
                  src={upiQrUrl} 
                  alt="UPI QR Code" 
                  style={{ width: '90px', height: '90px', display: 'block' }}
                />
              </div>
              <div style={{ fontSize: '11px', color: '#64748b', maxWidth: '170px' }}>
                <strong style={{ color: '#0f172a', display: 'block', marginBottom: '2px' }}>Scan & Pay via UPI</strong>
                Supports Google Pay, PhonePe, Paytm, and BHIM UPI.
              </div>
            </div>

            <div style={{ width: '240px', fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                <span>Taxable Value:</span>
                <span>{formatINR(basePrice)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                <span>CGST (9.0%):</span>
                <span>{formatINR(cgst)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                <span>SGST (9.0%):</span>
                <span>{formatINR(sgst)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, fontSize: '15px', color: '#0f172a', paddingTop: '6px', borderTop: '2px solid #0f172a', marginTop: '2px' }}>
                <span>Invoice Total:</span>
                <span style={{ color: '#0284c7' }}>{formatINR(totalAmount)}</span>
              </div>
            </div>
          </div>

          <div style={{ marginTop: '20px', paddingTop: '12px', borderTop: '1px dashed #cbd5e1', display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#64748b' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <ShieldCheck size={14} color="#16a34a" />
              <span>Digitally verified by VyaparAI OS Engine</span>
            </div>
            <div>Authorized Signatory</div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="modal-footer">
          <button className="btn-secondary" onClick={handlePrint}>
            <Printer size={14} />
            <span>Print Invoice</span>
          </button>
          <button className="btn-primary" onClick={handlePrint}>
            <Download size={14} />
            <span>Save PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
