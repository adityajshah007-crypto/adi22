import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Languages, 
  RefreshCw,
  Copy,
  RotateCcw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { answerBusinessQuestion, generateDailyBriefing } from '../services/aiAdvisorEngine';

export const AIAdvisorView = ({ 
  business = {}, 
  onOpenWhatsApp, 
  onGeneratePO, 
  onNavigateTab,
  onShowToast
}) => {
  const [language, setLanguage] = useState('en'); // 'en' or 'hinglish'
  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const messagesEndRef = useRef(null);

  // Categorized Suggested prompt pills
  const presetQuestions = [
    { text: 'Why did my profit decrease?', icon: '📉', cat: 'profit' },
    { text: 'Which products should I reorder?', icon: '📦', cat: 'stock' },
    { text: 'Who owes me money?', icon: '👥', cat: 'khata' },
    { text: 'What should I focus on today?', icon: '🎯', cat: 'strategy' },
    { text: 'Draft polite WhatsApp payment reminder', icon: '📝', cat: 'khata' },
    { text: 'Calculate margin: cost 350 selling 480', icon: '🧮', cat: 'profit' },
    { text: 'How will upcoming festivals impact sales?', icon: '🪔', cat: 'strategy' },
    { text: 'What is my total sales and revenue?', icon: '💰', cat: 'profit' },
    { text: 'How to clear dead slow-moving stock?', icon: '⚡', cat: 'stock' }
  ];

  const filteredPresets = activeCategory === 'all' 
    ? presetQuestions 
    : presetQuestions.filter(p => p.cat === activeCategory);

  // Initial message thread seeded with morning briefing
  const createInitialMessage = (lang) => {
    const briefing = generateDailyBriefing(business);
    return {
      id: 'msg-init-1',
      sender: 'ai',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: lang === 'hinglish' ? 'Aapka Live AI Vyapar Sahayak Taiyar Hai' : `Live AI Business Copilot — ${business.name || 'Store'}`,
      summary: briefing.greeting,
      insights: briefing.topPriorities.map(p => `🎯 **${p.title}**: ${p.description}`),
      recommendations: [
        lang === 'hinglish' 
          ? 'Neeche diye gaye kisi bhi sawal par click karein ya koi bhi custom vyaparik sawal type karein.'
          : 'Tap any inquiry prompt below or send ANY freeform question about your products, debtors, or revenue.'
      ],
      actions: briefing.topPriorities.map(p => ({
        label: p.actionLabel,
        type: p.actionType,
        payload: p.actionPayload
      })),
      followUps: [
        lang === 'hinglish' ? 'Kounse product ka stock khatam ho raha hai?' : 'Which products need reordering?',
        lang === 'hinglish' ? 'Sabse bada debtor koun hai?' : 'Who owes me the most money?',
        lang === 'hinglish' ? 'Munafa kam kyu ho raha hai?' : 'Why did my profit decrease?'
      ]
    };
  };

  const [messages, setMessages] = useState(() => [createInitialMessage(language)]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendQuestion = (queryText) => {
    const text = queryText || inputQuery;
    if (!text.trim()) return;

    // Add user message
    const userMsg = {
      id: `msg-user-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    // Simulate AI thinking and computing answers over real business data
    setTimeout(() => {
      const response = answerBusinessQuestion(text, business, language);
      const aiMsg = {
        id: `msg-ai-${Date.now()}`,
        sender: 'ai',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        ...response
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 450);
  };

  const handleActionClick = (action) => {
    if (!action) return;

    if (action.type === 'OPEN_WHATSAPP_DRAWER') {
      onOpenWhatsApp(action.payload || business.customers?.[0] || { name: 'Customer', pendingAmount: 15000 });
    } else if (action.type === 'GENERATE_PO') {
      const items = action.payload || business.inventory?.filter(i => (Number(i.stock) || 0) <= (Number(i.minStock) || 10));
      onGeneratePO(items || []);
    } else if (action.type === 'NAVIGATE_KHATA') {
      onNavigateTab('payments');
    } else if (action.type === 'NAVIGATE_INVENTORY') {
      onNavigateTab('inventory');
    } else if (action.type === 'NAVIGATE_SALES') {
      onNavigateTab('sales');
    } else if (action.type === 'NAVIGATE_CUSTOMERS') {
      onNavigateTab('customers');
    } else if (action.type === 'NAVIGATE_FORECAST') {
      onNavigateTab('forecasts');
    } else if (action.type === 'OPEN_QUICK_SALE') {
      onNavigateTab('sales');
    } else if (action.type === 'CLEARANCE_PROMO') {
      confetti({ particleCount: 50, spread: 60 });
      if (onShowToast) {
        onShowToast({ message: `Applied 10% clearance promotion to slow-moving inventory for ${business.name || 'your store'}.`, type: 'success' });
      }
    }
  };

  const handleCopyMessage = (msg) => {
    const textToCopy = `${msg.title || 'VyaparAI Insight'}\n\n${msg.summary || ''}\n\n` + 
      (msg.insights ? msg.insights.map(i => i.replace(/\*\*/g, '')).join('\n') : '') +
      (msg.recommendations ? '\n\nRecommendations:\n' + msg.recommendations.join('\n') : '');
    
    navigator.clipboard.writeText(textToCopy).then(() => {
      if (onShowToast) {
        onShowToast({ message: 'Insight copied to clipboard!', type: 'success' });
      }
    }).catch(() => {
      if (onShowToast) {
        onShowToast({ message: 'Could not access clipboard.', type: 'info' });
      }
    });
  };

  const handleResetChat = () => {
    setMessages([createInitialMessage(language)]);
    if (onShowToast) {
      onShowToast({ message: 'Advisor chat reset to fresh morning briefing.', type: 'info' });
    }
  };

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'hinglish' : 'en';
    setLanguage(newLang);
    if (onShowToast) {
      onShowToast({ message: `Language switched to ${newLang === 'en' ? 'English' : 'Hinglish (हिंदी)'}`, type: 'info' });
    }
  };

  const currentBriefing = generateDailyBriefing(business);

  return (
    <div className="page-container">
      {/* Title Bar */}
      <div className="page-header">
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <h1 className="page-title">AI Business Advisor</h1>
            <span style={{ 
              background: 'rgba(0, 240, 255, 0.1)', 
              color: 'var(--brand-cyan)', 
              border: '1px solid rgba(0, 240, 255, 0.3)',
              borderRadius: '12px',
              padding: '2px 8px',
              fontSize: '11px',
              fontWeight: 700
            }}>
              Live Data Connected
            </span>
          </div>
          <p className="page-subtitle">
            Autonomous financial diagnostics, real-time inventory reordering, and smart Khata receivables recovery for {business.name || 'your store'}.
          </p>
        </div>

        {/* Language switch & actions */}
        <div className="page-actions-group">
          <button 
            className="btn-secondary"
            onClick={toggleLanguage}
            style={{ fontSize: '13px' }}
          >
            <Languages size={15} color="var(--brand-cyan)" />
            <span>Language: <strong>{language === 'en' ? 'English' : 'Hinglish (हिंदी)'}</strong></span>
          </button>

          <button 
            className="btn-secondary"
            onClick={handleResetChat}
            style={{ fontSize: '13px' }}
            title="Reset conversation"
          >
            <RotateCcw size={14} />
            <span>Reset Chat</span>
          </button>
        </div>
      </div>

      <div className="ai-advisor-container">
        {/* Left Sidebar: Daily Morning Briefing & Categorized Presets */}
        <div className="ai-sidebar">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={16} color="var(--brand-cyan)" />
              <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>
                {language === 'hinglish' ? 'Aaj Ka Mudda (Key Focus)' : "Live Store Priorities"}
              </span>
            </div>
            <span style={{ fontSize: '11px', color: 'var(--brand-green)', fontWeight: 600 }}>Active</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {currentBriefing.topPriorities.map((item, idx) => (
              <div 
                key={idx} 
                style={{ 
                  backgroundColor: 'var(--bg-card-subtle)', 
                  border: '1px solid var(--border-color)', 
                  borderRadius: '8px', 
                  padding: '10px 12px',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
                onClick={() => handleActionClick({ type: item.actionType, payload: item.actionPayload })}
              >
                <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {item.title}
                </div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginTop: '4px', lineHeight: 1.4 }}>
                  {item.description}
                </div>
                <div style={{ 
                  marginTop: '6px', 
                  fontSize: '11px', 
                  color: 'var(--brand-cyan)', 
                  fontWeight: 600, 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '4px' 
                }}>
                  <span>{item.actionLabel}</span>
                  <ArrowRight size={11} />
                </div>
              </div>
            ))}
          </div>

          {/* Quick AI Inquiries with Filter Tabs */}
          <div style={{ marginTop: '6px', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)' }}>
                Quick Inquiries:
              </span>
              <div style={{ display: 'flex', gap: '4px' }}>
                {['all', 'stock', 'khata', 'profit'].map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setActiveCategory(cat)}
                    style={{
                      background: activeCategory === cat ? 'var(--brand-cyan)' : 'transparent',
                      color: activeCategory === cat ? '#030712' : 'var(--text-muted)',
                      border: 'none',
                      borderRadius: '4px',
                      fontSize: '10px',
                      padding: '2px 5px',
                      fontWeight: 600,
                      cursor: 'pointer',
                      textTransform: 'capitalize'
                    }}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {filteredPresets.map((q, i) => (
                <button
                  key={i}
                  className="prompt-preset-chip"
                  onClick={() => handleSendQuestion(q.text)}
                  style={{ textAlign: 'left', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
                >
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span>{q.icon}</span>
                    <span style={{ fontSize: '12px' }}>{q.text}</span>
                  </span>
                  <ArrowRight size={12} color="var(--text-muted)" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main AI Chat Interface */}
        <div className="ai-chat-card">
          <div className="ai-chat-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div className="ai-avatar">
                <Bot size={18} />
              </div>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  VyaparAI Executive Copilot
                </div>
                <div style={{ fontSize: '11.5px', color: 'var(--brand-green)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'var(--brand-green)' }}></span>
                  Online • Analyzing live sales, stock &amp; Khata ledger
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <button
                type="button"
                onClick={handleResetChat}
                className="btn-secondary"
                style={{ fontSize: '11px', padding: '4px 8px', borderRadius: '6px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
                title="Restart chat"
              >
                <RotateCcw size={11} />
                <span>Clear</span>
              </button>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="ai-chat-messages">
            {messages.map((msg) => (
              <div key={msg.id} className={`ai-message ${msg.sender === 'user' ? 'user' : ''}`}>
                <div className="ai-avatar">
                  {msg.sender === 'user' ? 'ME' : <Bot size={18} />}
                </div>

                <div className="message-bubble" style={{ position: 'relative', width: '100%' }}>
                  {msg.sender === 'user' ? (
                    <div style={{ fontWeight: 500, fontSize: '14px' }}>{msg.text}</div>
                  ) : (
                    <div>
                      {/* Title & Copy Button Header */}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        {msg.title && (
                          <div style={{ fontSize: '14.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
                            {msg.title}
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => handleCopyMessage(msg)}
                          title="Copy insight to clipboard"
                          style={{
                            background: 'transparent',
                            border: 'none',
                            color: 'var(--text-muted)',
                            cursor: 'pointer',
                            padding: '2px 4px',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '3px',
                            fontSize: '11px'
                          }}
                        >
                          <Copy size={12} />
                          <span>Copy</span>
                        </button>
                      </div>

                      {msg.summary && (
                        <div style={{ color: 'var(--text-secondary)', marginBottom: '12px', fontSize: '13.5px', lineHeight: 1.5 }}>
                          {msg.summary}
                        </div>
                      )}

                      {/* Insights List */}
                      {msg.insights && msg.insights.length > 0 && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', margin: '10px 0' }}>
                          {msg.insights.map((insight, idx) => (
                            <div key={idx} style={{ display: 'flex', gap: '8px', fontSize: '13px', lineHeight: 1.5 }}>
                              <span style={{ color: 'var(--brand-cyan)', fontWeight: 700 }}>•</span>
                              <span dangerouslySetInnerHTML={{ __html: insight.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Strategic Recommendations */}
                      {msg.recommendations && msg.recommendations.length > 0 && (
                        <div style={{ 
                          backgroundColor: 'var(--bg-card)', 
                          border: '1px solid var(--border-color)', 
                          borderRadius: '8px', 
                          padding: '10px 14px', 
                          marginTop: '12px' 
                        }}>
                          <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '4px', textTransform: 'uppercase' }}>
                            Strategic Recommendations:
                          </div>
                          {msg.recommendations.map((rec, idx) => (
                            <div key={idx} style={{ fontSize: '12.5px', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
                              <CheckCircle2 size={13} color="var(--brand-green)" style={{ flexShrink: 0 }} />
                              <span>{rec}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Action Triggers / Buttons Right Inside Message */}
                      {msg.actions && msg.actions.length > 0 && (
                        <div className="ai-action-pills-row" style={{ marginTop: '12px' }}>
                          {msg.actions.map((act, idx) => (
                            <button
                              key={idx}
                              type="button"
                              className="action-pill-btn"
                              onClick={() => handleActionClick(act)}
                            >
                              <Sparkles size={13} color="var(--brand-cyan)" />
                              <span>{act.label}</span>
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Interactive Suggested Follow-Up Prompts */}
                      {msg.followUps && msg.followUps.length > 0 && (
                        <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed var(--border-color)' }}>
                          <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '6px' }}>
                            Suggested Follow-up Inquiries:
                          </div>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                            {msg.followUps.map((fu, fIdx) => (
                              <button
                                key={fIdx}
                                type="button"
                                onClick={() => handleSendQuestion(fu)}
                                style={{
                                  background: 'rgba(0, 240, 255, 0.07)',
                                  border: '1px solid rgba(0, 240, 255, 0.22)',
                                  color: 'var(--brand-cyan)',
                                  padding: '4px 10px',
                                  borderRadius: '16px',
                                  fontSize: '11.5px',
                                  cursor: 'pointer',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '5px',
                                  transition: 'all 0.15s ease'
                                }}
                              >
                                <span>💬</span>
                                <span>{fu}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div style={{ fontSize: '10px', color: 'var(--text-muted)', textAlign: 'right', marginTop: '6px' }}>
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="ai-message">
                <div className="ai-avatar">
                  <Bot size={18} />
                </div>
                <div className="message-bubble" style={{ color: 'var(--text-muted)', fontStyle: 'italic', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <RefreshCw size={14} className="spin-animation" />
                  <span>VyaparAI is analyzing live store ledger, stock &amp; Khata...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestion Chips Above Input */}
          <div style={{ 
            padding: '8px 24px', 
            background: 'var(--bg-card-subtle)', 
            borderTop: '1px solid var(--border-color)',
            display: 'flex',
            gap: '8px',
            overflowX: 'auto',
            whiteSpace: 'nowrap'
          }}>
            {[
              { label: '📦 Stockout Risk', query: 'Which products should I reorder?' },
              { label: '👥 Debtors Overdue', query: 'Who owes me money?' },
              { label: '📉 Profit Diagnostics', query: 'Why did my profit decrease?' },
              { label: '🧮 Margin Calc', query: 'Calculate margin: cost 200 selling 280' },
              { label: '📝 Draft WhatsApp', query: 'Draft polite WhatsApp payment reminder' }
            ].map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendQuestion(chip.query)}
                style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  color: 'var(--text-secondary)',
                  borderRadius: '14px',
                  padding: '3px 10px',
                  fontSize: '11px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  flexShrink: 0
                }}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Question Input Form */}
          <form 
            className="ai-input-form" 
            onSubmit={(e) => {
              e.preventDefault();
              handleSendQuestion();
            }}
          >
            <input
              type="text"
              className="ai-input"
              placeholder={language === 'hinglish' 
                ? 'Apne vyapar ke baare me kuch bhi poochhein (e.g. Rice ka stock kitna hai, Sharma ji ka baki udhar, ya Munafa kyu gira)...' 
                : 'Ask anything about your business (e.g., Rice stock, Sharma overdue dues, or why profit decreased)...'}
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
            />
            <button type="submit" className="btn-primary" disabled={!inputQuery.trim() || isTyping}>
              <Send size={15} />
              <span>Ask AI</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
