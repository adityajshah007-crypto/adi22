import React, { useState } from 'react';
import { 
  Check, 
  X, 
  Sparkles, 
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const SubscriptionModal = ({ isOpen, onClose, _currentPlan = 'pro-trial' }) => {
  const [billingCycle, setBillingCycle] = useState('annual'); // 'monthly' | 'annual'
  const [_selectedPlan, setSelectedPlan] = useState('pro');
  const [upgraded, setUpgraded] = useState(false);

  if (!isOpen) return null;

  const handleUpgrade = (planKey) => {
    setSelectedPlan(planKey);
    setUpgraded(true);
    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.6 }
    });
    setTimeout(() => {
      setUpgraded(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div 
        className="modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{ maxWidth: '880px', width: '92%', maxHeight: '90vh', overflowY: 'auto' }}
      >
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
          <div>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '3px 10px',
              borderRadius: '12px',
              backgroundColor: 'rgba(0, 229, 255, 0.12)',
              color: 'var(--brand-saffron)',
              fontSize: '11px',
              fontWeight: 700,
              marginBottom: '6px'
            }}>
              <Sparkles size={13} />
              <span>COMMERCIAL B2B SAAS TIERS</span>
            </div>
            <h2 style={{ fontSize: '22px', fontWeight: 800, margin: '0 0 4px 0', color: 'var(--text-primary)' }}>
              Choose the Right Operating Plan for Your Vyapar
            </h2>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: 0 }}>
              Transparent pricing tailored for Indian retailers, wholesalers, and multi-branch enterprises.
            </p>
          </div>
          <button 
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--text-muted)',
              padding: '4px'
            }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Billing Toggle (Monthly / Annual with 20% discount) */}
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '24px' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            backgroundColor: 'var(--bg-card-subtle)',
            padding: '4px',
            borderRadius: '10px',
            border: '1px solid var(--border-color)'
          }}>
            <button
              type="button"
              onClick={() => setBillingCycle('monthly')}
              style={{
                padding: '6px 14px',
                borderRadius: '7px',
                border: 'none',
                backgroundColor: billingCycle === 'monthly' ? 'var(--bg-card)' : 'transparent',
                color: billingCycle === 'monthly' ? 'var(--text-primary)' : 'var(--text-muted)',
                fontWeight: 600,
                fontSize: '12.5px',
                cursor: 'pointer',
                boxShadow: billingCycle === 'monthly' ? 'var(--card-shadow)' : 'none'
              }}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle('annual')}
              style={{
                padding: '6px 14px',
                borderRadius: '7px',
                border: 'none',
                backgroundColor: billingCycle === 'annual' ? 'var(--bg-card)' : 'transparent',
                color: billingCycle === 'annual' ? 'var(--text-primary)' : 'var(--text-muted)',
                fontWeight: 600,
                fontSize: '12.5px',
                cursor: 'pointer',
                boxShadow: billingCycle === 'annual' ? 'var(--card-shadow)' : 'none',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <span>Annual Billing</span>
              <span style={{
                fontSize: '10px',
                padding: '2px 6px',
                borderRadius: '8px',
                backgroundColor: 'var(--badge-bg-green)',
                color: 'var(--brand-green)',
                fontWeight: 700
              }}>
                SAVE 20%
              </span>
            </button>
          </div>
        </div>

        {/* 3 Pricing Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '18px', marginBottom: '24px' }}>
          
          {/* Plan 1: Starter */}
          <div style={{
            padding: '20px',
            borderRadius: '12px',
            backgroundColor: 'var(--bg-card)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between'
          }}>
            <div>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                Vyapar Starter
              </div>
              <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--text-primary)', margin: '8px 0 2px' }}>
                ₹0
              </div>
              <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginBottom: '16px' }}>
                Free forever for small single-counter shops
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Up to 50 sales entries/mo</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Basic manual Khata ledger</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-secondary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Single user owner login</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-disabled)' }}>
                  <X size={14} />
                  <span>No automated WhatsApp alerts</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleUpgrade('starter')}
              style={{
                width: '100%',
                padding: '9px',
                borderRadius: '8px',
                border: '1px solid var(--border-color)',
                backgroundColor: 'var(--bg-card-subtle)',
                color: 'var(--text-primary)',
                fontWeight: 600,
                fontSize: '12.5px',
                cursor: 'pointer'
              }}
            >
              Current Base Plan
            </button>
          </div>

          {/* Plan 2: Pro Growth (Highlighted) */}
          <div style={{
            padding: '20px',
            borderRadius: '12px',
            backgroundColor: 'var(--bg-card)',
            border: '2px solid var(--brand-saffron)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            position: 'relative',
            boxShadow: '0 6px 20px rgba(0, 229, 255, 0.25)'
          }}>
            <div style={{
              position: 'absolute',
              top: '-11px',
              left: '50%',
              transform: 'translateX(-50%)',
              padding: '2px 10px',
              borderRadius: '12px',
              backgroundColor: 'var(--brand-saffron)',
              color: '#030712',
              fontSize: '10px',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}>
              Most Popular • Core Plan
            </div>

            <div>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-saffron)', textTransform: 'uppercase' }}>
                Vyapar Pro Growth
              </div>
              <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--text-primary)', margin: '8px 0 2px' }}>
                {billingCycle === 'annual' ? '₹799' : '₹999'}
                <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--text-muted)' }}>/mo</span>
              </div>
              <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginBottom: '16px' }}>
                {billingCycle === 'annual' ? 'Billed annually at ₹9,588/yr' : 'Billed monthly'}
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)', fontWeight: 600 }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Unlimited WhatsApp Udhar alerts</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)', fontWeight: 600 }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Predictive Stockout & PO Generator</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)', fontWeight: 600 }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Autonomous AI Advisor & insights</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Dynamic UPI QR code recovery</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>GST-ready audited statements</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleUpgrade('pro')}
              className="btn-primary"
              style={{
                width: '100%',
                padding: '10px',
                fontSize: '13px',
                fontWeight: 700,
                justifyContent: 'center',
                backgroundColor: 'var(--brand-saffron)',
                borderColor: 'var(--brand-saffron)'
              }}
            >
              {upgraded ? 'Plan Activated! 🎉' : 'Upgrade to Pro Growth'}
            </button>
          </div>

          {/* Plan 3: Enterprise Multi-Store */}
          <div style={{
            padding: '20px',
            borderRadius: '12px',
            backgroundColor: 'var(--bg-card)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between'
          }}>
            <div>
              <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--brand-purple)', textTransform: 'uppercase' }}>
                Vyapar Enterprise
              </div>
              <div style={{ fontSize: '26px', fontWeight: 900, color: 'var(--text-primary)', margin: '8px 0 2px' }}>
                {billingCycle === 'annual' ? '₹1,999' : '₹2,499'}
                <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--text-muted)' }}>/mo</span>
              </div>
              <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginBottom: '16px' }}>
                For multi-branch mandi agencies & wholesalers
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Everything in Pro Growth</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Multi-store & central warehouse sync</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Unlimited staff logins with role controls</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: 'var(--text-primary)' }}>
                  <Check size={14} color="var(--brand-green)" />
                  <span>Custom ERP / Tally API connectors</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleUpgrade('enterprise')}
              style={{
                width: '100%',
                padding: '9px',
                borderRadius: '8px',
                border: '1px solid var(--brand-purple)',
                backgroundColor: 'rgba(139, 92, 246, 0.08)',
                color: 'var(--brand-purple)',
                fontWeight: 700,
                fontSize: '12.5px',
                cursor: 'pointer'
              }}
            >
              Upgrade to Enterprise
            </button>
          </div>
        </div>

        {/* Footer Guarantee */}
        <div style={{
          padding: '12px 16px',
          borderRadius: '8px',
          backgroundColor: 'var(--bg-card-subtle)',
          fontSize: '11.5px',
          color: 'var(--text-muted)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <span>🛡️ 30-Day Money Back Guarantee • Cancel Anytime • GST Invoicing Included</span>
          <span style={{ fontWeight: 600, color: 'var(--brand-saffron)' }}>Instant UPI & Netbanking Activation</span>
        </div>
      </div>
    </div>
  );
};
