import React, { useState } from 'react';
import { 
  X, 
  Zap, 
  ArrowDownCircle, 
  Package, 
  ShoppingBag
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDataStore } from '../context/DataStore';

export const MarketSimulatorModal = ({ isOpen, onClose }) => {
  const [_copiedEvent, _setCopiedEvent] = useState(null);
  const [simulationLog, setSimulationLog] = useState([]);

  const { customers, importDataset, inventory, _sales } = useDataStore();

  if (!isOpen) return null;

  const logEvent = (msg) => {
    setSimulationLog(prev => [
      { time: new Date().toLocaleTimeString('en-IN'), text: msg },
      ...prev.slice(0, 4)
    ]);
  };

  // 1. Simulate ₹24,500 UPI Settlement from Sharmaji Caterers
  const handleSimulatePayment = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    const updatedCustomers = customers.map(c => {
      if (c.customerName === 'Sharmaji Caterers' || c.name === 'Sharmaji Caterers') {
        return {
          ...c,
          amountPaid: (Number(c.amountPaid) || 0) + (Number(c.amountDue) || 24500),
          amountDue: 0,
          pendingAmount: 0
        };
      }
      return c;
    });

    importDataset('CUSTOMERS', updatedCustomers, { overwrite: true });
    logEvent('✅ UPI Webhook: Received ₹24,500 from Sharmaji Caterers via PhonePe (UTR: UPI-984421). Ledger updated to ₹0 due.');
  };

  // 2. Simulate High-Value Bulk Invoiced Sale (₹48,500)
  const handleSimulateSale = () => {
    const newInvoice = {
      date: new Date().toISOString().split('T')[0],
      invoiceId: `INV-${Date.now().toString().slice(-4)}`,
      product: 'India Gate Basmati Rice (10kg)',
      category: 'Grains & Staples',
      quantity: 40,
      sellingPrice: 1150,
      revenue: 46000,
      cost: 36800,
      profit: 9200,
      customer: 'Deepak Sweet House'
    };

    importDataset('SALES', [newInvoice], { overwrite: false });
    confetti({ particleCount: 40, spread: 50 });
    logEvent(`🎉 New Invoice Recorded: Deepak Sweet House purchased 40 units Basmati Rice (Revenue: ₹46,000 | Profit: ₹9,200).`);
  };

  // 3. Simulate Stockout Alert Trigger
  const handleSimulateStockout = () => {
    const updatedInventory = inventory.map(i => {
      if (i.product.includes('Fortune') || i.sku === 'SKU-102') {
        return { ...i, currentStock: 2 }; // Drop below reorder level (25)
      }
      return i;
    });

    importDataset('INVENTORY', updatedInventory, { overwrite: true });
    logEvent('⚠️ Safety Stock Buffer Breached: Fortune Sunflower Oil dropped to 2 units (Safety threshold: 25). Purchase order generated.');
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div 
        className="modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{ maxWidth: '640px', width: '92%' }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
          <div>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '3px 8px',
              borderRadius: '10px',
              backgroundColor: 'rgba(16, 185, 129, 0.12)',
              color: 'var(--brand-green)',
              fontSize: '11px',
              fontWeight: 700,
              marginBottom: '6px'
            }}>
              <Zap size={13} />
              <span>MARKET TEST SANDBOX</span>
            </div>
            <h2 style={{ fontSize: '20px', fontWeight: 800, margin: '0 0 4px 0', color: 'var(--text-primary)' }}>
              Live Market Simulation Engine
            </h2>
            <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: 0 }}>
              Trigger real-world merchant events to showcase instant autonomous reactions to investors and pilot testers.
            </p>
          </div>
          <button 
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: 'var(--text-muted)',
              padding: '4px'
            }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Action Triggers */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '20px' }}>
          {/* Action 1: UPI Settlement */}
          <div style={{
            padding: '14px 16px',
            borderRadius: '10px',
            backgroundColor: 'var(--bg-card-subtle)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ padding: '8px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--brand-green)' }}>
                <ArrowDownCircle size={18} />
              </div>
              <div>
                <div style={{ fontSize: '13.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Simulate UPI Customer Settlement
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                  Sharmaji Caterers clears ₹24,500 overdue khata balance via WhatsApp UPI intent.
                </div>
              </div>
            </div>
            <button
              onClick={handleSimulatePayment}
              className="btn-primary"
              style={{ padding: '7px 14px', fontSize: '12px', whiteSpace: 'nowrap', backgroundColor: 'var(--brand-green)', borderColor: 'var(--brand-green)' }}
            >
              Trigger Settlement
            </button>
          </div>

          {/* Action 2: High Value Sale */}
          <div style={{
            padding: '14px 16px',
            borderRadius: '10px',
            backgroundColor: 'var(--bg-card-subtle)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ padding: '8px', borderRadius: '8px', backgroundColor: 'rgba(0, 229, 255, 0.12)', color: 'var(--brand-saffron)' }}>
                <ShoppingBag size={18} />
              </div>
              <div>
                <div style={{ fontSize: '13.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Simulate Bulk Mandi Sale (₹46,000)
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                  Deepak Sweet House orders 40 bags of Basmati Rice. Recomputes profit & revenue live.
                </div>
              </div>
            </div>
            <button
              onClick={handleSimulateSale}
              className="btn-primary"
              style={{ padding: '7px 14px', fontSize: '12px', whiteSpace: 'nowrap' }}
            >
              Dispatch Invoice
            </button>
          </div>

          {/* Action 3: Stock Depletion */}
          <div style={{
            padding: '14px 16px',
            borderRadius: '10px',
            backgroundColor: 'var(--bg-card-subtle)',
            border: '1px solid var(--border-color)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ padding: '8px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-red)', color: 'var(--badge-text-red)' }}>
                <Package size={18} />
              </div>
              <div>
                <div style={{ fontSize: '13.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Simulate Urgent Low Stock Alert
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                  Drops Fortune Sunflower Oil to 2 units to demonstrate autonomous purchase order generator.
                </div>
              </div>
            </div>
            <button
              onClick={handleSimulateStockout}
              className="btn-secondary"
              style={{ padding: '7px 14px', fontSize: '12px', whiteSpace: 'nowrap' }}
            >
              Trigger Stockout
            </button>
          </div>
        </div>

        {/* Live Simulation Event Log */}
        {simulationLog.length > 0 && (
          <div style={{
            padding: '12px 14px',
            borderRadius: '8px',
            backgroundColor: 'var(--bg-card-subtle)',
            border: '1px solid var(--border-color)'
          }}>
            <div style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '8px' }}>
              Live Simulation Terminal Output:
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {simulationLog.map((log, i) => (
                <div key={i} style={{ fontSize: '12px', color: 'var(--text-primary)', fontFamily: 'monospace' }}>
                  <span style={{ color: 'var(--brand-saffron)', marginRight: '6px' }}>[{log.time}]</span>
                  <span>{log.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
