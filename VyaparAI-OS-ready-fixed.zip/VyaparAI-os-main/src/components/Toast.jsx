import React, { useEffect } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

export const Toast = ({ message, type = 'success', onClose, duration = 3000 }) => {
  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => {
      onClose();
    }, duration);
    return () => clearTimeout(timer);
  }, [message, duration, onClose]);

  if (!message) return null;

  const icons = {
    success: <CheckCircle2 size={16} color="var(--brand-green)" />,
    warning: <AlertTriangle size={16} color="var(--badge-text-amber)" />,
    info: <Info size={16} color="var(--brand-blue)" />
  };

  const borders = {
    success: 'rgba(16, 185, 129, 0.4)',
    warning: 'rgba(245, 158, 11, 0.4)',
    info: 'rgba(14, 165, 233, 0.4)'
  };

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '12px 18px',
        backgroundColor: 'var(--bg-card)',
        border: `1px solid ${borders[type] || 'var(--border-color)'}`,
        borderRadius: '10px',
        boxShadow: 'var(--elevated-shadow)',
        backdropFilter: 'blur(16px)',
        color: 'var(--text-primary)',
        fontSize: '13px',
        fontWeight: 600,
        animation: 'modalEnter 0.2s ease-out'
      }}
    >
      {icons[type] || icons.success}
      <span>{message}</span>
      <button
        onClick={onClose}
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: 'var(--text-muted)',
          padding: '2px',
          marginLeft: '4px',
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <X size={14} />
      </button>
    </div>
  );
};
