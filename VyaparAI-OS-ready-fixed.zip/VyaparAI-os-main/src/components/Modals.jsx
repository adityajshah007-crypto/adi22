import React, { useState } from 'react';
import { 
  X, 
  MessageCircle, 
  Copy, 
  ExternalLink, 
  Printer, 
  Check, 
  FileText, 
  Search,
  Bot
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatINR } from '../utils/formatters';

// 1. WhatsApp Payment Reminder Modal
export const WhatsAppModal = ({ isOpen, onClose, customer, business }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !customer) return null;

  const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
  const messageText = `Namaste ${customer.name} Ji 🙏,

This is a gentle payment reminder from *${business.name}*.
Your current pending ledger balance is *${formatINR(customer.pendingAmount)}* (overdue by ${customer.overdueDays} days).

Kindly clear the balance via UPI:
💳 *UPI ID:* ${business.upiId || 'vyapar@upi'}

Thank you for your ongoing partnership!
— *${business.owner}*, ${business.name}`;

  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(messageText)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSend = () => {
    confetti({ particleCount: 70, spread: 50, origin: { y: 0.6 } });
    window.open(whatsappUrl, '_blank');
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <MessageCircle size={18} color="#25d366" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Send WhatsApp Payment Reminder
            </h3>
          </div>
          <button className="header-icon-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        <div className="modal-body">
          <div style={{ display: 'flex', justifyContent: 'space-between', backgroundColor: 'var(--bg-card-subtle)', padding: '12px 16px', borderRadius: '8px' }}>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 700 }}>{customer.name}</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{customer.phone}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '15px', fontWeight: 800, color: '#ef4444' }}>{formatINR(customer.pendingAmount)}</div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{customer.overdueDays} days overdue</div>
            </div>
          </div>

          <div>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>
              Preview Message (Formatted with UPI details):
            </label>
            <textarea
              readOnly
              rows={8}
              value={messageText}
              className="ai-input"
              style={{ width: '100%', fontSize: '13px', lineHeight: '1.5', fontFamily: 'monospace' }}
            />
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn-secondary" onClick={handleCopy}>
            {copied ? <Check size={14} color="var(--brand-green)" /> : <Copy size={14} />}
            <span>{copied ? 'Copied!' : 'Copy Text'}</span>
          </button>

          <button className="btn-whatsapp" onClick={handleSend} style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '8px 16px', borderRadius: '8px', fontWeight: 600, cursor: 'pointer' }}>
            <ExternalLink size={14} />
            <span>Open in WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const PurchaseOrderModal = ({ isOpen, onClose, items = [], business, onOrderConfirmed }) => {
  const [poNumber] = useState(() => `PO-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  if (!isOpen) return null;

  const dateStr = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  const orderLines = items.map(item => ({
    name: item.name,
    supplier: item.supplier || 'Primary Distributor',
    qty: item.suggestedOrderQty || Math.max((item.minStock * 2) - item.stock, 10),
    unitCost: item.costPrice,
    total: (item.suggestedOrderQty || Math.max((item.minStock * 2) - item.stock, 10)) * item.costPrice
  }));

  const grandTotal = orderLines.reduce((sum, line) => sum + line.total, 0);

  const handlePrint = () => {
    window.print();
  };

  const handleConfirmOrder = () => {
    confetti({ particleCount: 50, spread: 40 });
    if (onOrderConfirmed) {
      onOrderConfirmed(`Purchase Order ${poNumber} dispatched to vendor.`);
    }
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '680px' }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FileText size={18} color="var(--brand-blue)" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Purchase Order (PO) Generator
            </h3>
          </div>
          <button className="header-icon-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        <div className="modal-body" id="printable-po" style={{ backgroundColor: '#ffffff', color: '#0f172a', padding: '24px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
          {/* PO Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0f172a', paddingBottom: '16px' }}>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>{business.name}</h2>
              <div style={{ fontSize: '12px', color: '#64748b' }}>{business.location}</div>
              <div style={{ fontSize: '12px', color: '#64748b' }}>GSTIN: {business.gstin || '27AAAAA0000A1Z5'}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>PURCHASE ORDER</div>
              <div style={{ fontSize: '13px', fontWeight: 600, color: '#2563eb' }}>{poNumber}</div>
              <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {dateStr}</div>
            </div>
          </div>

          {/* Supplier Info */}
          <div style={{ margin: '16px 0', padding: '10px', backgroundColor: '#f8fafc', borderRadius: '6px', fontSize: '12.5px' }}>
            <strong>Vendor / Distributor:</strong> {orderLines[0]?.supplier || 'Authorized Wholesale Agency'}
          </div>

          {/* Line items table */}
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12.5px', marginTop: '12px' }}>
            <thead>
              <tr style={{ backgroundColor: '#f1f5f9', borderBottom: '1px solid #cbd5e1' }}>
                <th style={{ padding: '8px', textAlign: 'left' }}>Item Description</th>
                <th style={{ padding: '8px', textAlign: 'center' }}>Qty</th>
                <th style={{ padding: '8px', textAlign: 'right' }}>Unit Cost (₹)</th>
                <th style={{ padding: '8px', textAlign: 'right' }}>Total (₹)</th>
              </tr>
            </thead>
            <tbody>
              {orderLines.map((line, idx) => (
                <tr key={idx} style={{ borderBottom: '1px solid #e2e8f0' }}>
                  <td style={{ padding: '8px', fontWeight: 500 }}>{line.name}</td>
                  <td style={{ padding: '8px', textAlign: 'center', fontWeight: 700 }}>{line.qty}</td>
                  <td style={{ padding: '8px', textAlign: 'right' }}>{formatINR(line.unitCost)}</td>
                  <td style={{ padding: '8px', textAlign: 'right', fontWeight: 600 }}>{formatINR(line.total)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} style={{ padding: '12px 8px', textAlign: 'right', fontWeight: 700 }}>Grand Total:</td>
                <td style={{ padding: '12px 8px', textAlign: 'right', fontWeight: 800, fontSize: '14.5px', color: '#0f172a' }}>
                  {formatINR(grandTotal)}
                </td>
              </tr>
            </tfoot>
          </table>

          <div style={{ marginTop: '24px', paddingTop: '16px', borderTop: '1px dashed #cbd5e1', display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#64748b' }}>
            <div>Authorized Signatory / Vyapar Stamp</div>
            <div>Generated autonomously by VyaparAI OS</div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn-secondary" onClick={handlePrint}>
            <Printer size={14} />
            <span>Print PO</span>
          </button>
          <button className="btn-primary" onClick={handleConfirmOrder}>
            <Check size={14} />
            <span>Confirm & Dispatch Order</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// 3. Command Palette (Cmd + K)
export const CommandPaletteModal = ({ isOpen, onClose, onNavigate, onAskAI }) => {
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const quickActions = [
    { label: 'Why did my profit decrease?', type: 'ai', icon: Bot },
    { label: 'Which products should I reorder?', type: 'ai', icon: Bot },
    { label: 'Who owes me money?', type: 'ai', icon: Bot },
    { label: 'What should I focus on today?', type: 'ai', icon: Bot },
    { label: 'How will upcoming festivals impact sales?', type: 'ai', icon: Bot },
    { label: 'Go to Command Center', type: 'nav', target: 'command-center' },
    { label: 'Go to Sales Management', type: 'nav', target: 'sales' },
    { label: 'Go to Inventory & Stock', type: 'nav', target: 'inventory' },
    { label: 'Go to Customers Directory', type: 'nav', target: 'customers' },
    { label: 'Go to Payments & Khata (Udhar)', type: 'nav', target: 'payments' },
    { label: 'Go to Demand & Sales Forecasts', type: 'nav', target: 'forecasts' },
    { label: 'Go to AI Actions & Recommendations', type: 'nav', target: 'actions' },
    { label: 'Go to Investor-Grade Financial Reports', type: 'nav', target: 'reports' },
    { label: 'Go to Business Profile & Settings', type: 'nav', target: 'settings' },
    { label: 'Go to Investor Pitch Deck', type: 'nav', target: 'pitch-deck' },
    { label: 'Go to Import Business Data', type: 'nav', target: 'import-data' }
  ];

  const filtered = quickActions.filter(a => a.label.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '520px' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Search size={16} color="var(--text-muted)" />
          <input
            autoFocus
            type="text"
            placeholder="Search commands, navigate, or ask AI..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ border: 'none', outline: 'none', background: 'transparent', width: '100%', fontSize: '14px', color: 'var(--text-primary)' }}
          />
          <button className="header-icon-btn" onClick={onClose} style={{ width: '28px', height: '28px' }}>
            <X size={14} />
          </button>
        </div>

        <div style={{ padding: '10px', maxHeight: '340px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {filtered.map((item, idx) => (
            <div
              key={idx}
              onClick={() => {
                if (item.type === 'ai') {
                  onAskAI(item.label);
                } else if (item.type === 'nav') {
                  onNavigate(item.target);
                }
                onClose();
              }}
              style={{
                padding: '10px 12px',
                borderRadius: '8px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontSize: '13px',
                color: 'var(--text-primary)',
                transition: 'background-color 0.1s'
              }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--bg-card-subtle)'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            >
              <span>{item.label}</span>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                {item.type === 'ai' ? 'Ask AI' : 'Navigate'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
