import React, { useState } from 'react';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  Store, 
  Plus, 
  RefreshCw
} from 'lucide-react';
import { parseSpreadsheetFile, downloadSampleTemplate } from '../utils/dataParser';
import { sampleBusinesses } from '../data/sampleDatasets';
import { formatINR } from '../utils/formatters';

export const DataManagementView = ({ 
  business, 
  onLoadCustomData, 
  onSelectBusiness,
  onAddTransaction,
  onShowToast
}) => {
  const [uploadStatus, setUploadStatus] = useState(null); // null, 'loading', 'success', 'error'
  const [uploadDetails, setUploadDetails] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Manual Transaction Form
  const [manualCustomer, setManualCustomer] = useState('');
  const [manualItem, setManualItem] = useState('');
  const [manualQty, setManualQty] = useState(1);
  const [manualPrice, setManualPrice] = useState('');
  const [manualPaymentMode, setManualPaymentMode] = useState('UPI');

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadStatus('loading');
    setErrorMessage('');

    try {
      const result = await parseSpreadsheetFile(file);
      setUploadDetails(result);
      setUploadStatus('success');

      // Update active business data
      if (onLoadCustomData) {
        onLoadCustomData(result);
      }
    } catch (err) {
      console.error(err);
      setUploadStatus('error');
      setErrorMessage(err.message || 'Failed to parse file. Ensure it is a valid .xlsx or .csv.');
    }
  };

  const handleAddManualTxn = (e) => {
    e.preventDefault();
    if (!manualCustomer || !manualItem || !manualPrice) return;

    const price = Number(manualPrice);
    const qty = Number(manualQty);
    const total = price * qty;
    const cost = Math.round(price * 0.75); // approx 25% margin

    const newTxn = {
      id: `TXN-MAN-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      customer: manualCustomer,
      item: manualItem,
      qty,
      unitPrice: price,
      costPrice: cost,
      total,
      profit: total - (cost * qty),
      paymentMode: manualPaymentMode,
      status: manualPaymentMode.includes('Udhar') ? 'Pending' : 'Paid'
    };

    onAddTransaction(newTxn);

    // Reset form
    setManualCustomer('');
    setManualItem('');
    setManualQty(1);
    setManualPrice('');
    if (onShowToast) {
      onShowToast({ message: `Added sale for ${manualCustomer} (${formatINR(total)}) successfully!`, type: 'success' });
    }
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Data Ingestion & Business Switcher</h1>
          <p className="page-subtitle">
            Upload your own business Excel/CSV ledgers or switch between pre-configured Indian SMB models.
          </p>
        </div>

        <div className="page-actions-group">
          <button className="btn-secondary" onClick={downloadSampleTemplate}>
            <Download size={15} />
            <span>Download Sample Excel Template</span>
          </button>
        </div>
      </div>

      {/* 1-Click Pre-configured SMB Datasets */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
          <Store size={18} color="var(--brand-saffron)" />
          <span style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)' }}>
            1-Click Pre-Loaded Indian SMB Datasets
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '14px' }}>
          {sampleBusinesses.map((b) => {
            const isSelected = b.id === business.id;
            return (
              <div
                key={b.id}
                onClick={() => onSelectBusiness(b)}
                style={{
                  backgroundColor: isSelected ? 'var(--bg-card-subtle)' : 'var(--bg-card)',
                  border: `2px solid ${isSelected ? 'var(--brand-saffron)' : 'var(--border-color)'}`,
                  borderRadius: '10px',
                  padding: '16px',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>{b.name}</span>
                  {isSelected && <span className="badge badge-success">Active</span>}
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{b.tagline}</div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-secondary)', marginTop: '8px' }}>
                  📍 {b.location} • {b.inventory.length} SKUs • {b.customers.length} Credit accounts
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Drag and Drop File Upload Area */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
          <UploadCloud size={18} color="var(--brand-blue)" />
          <span style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Upload Your Own Excel / CSV File (.xlsx, .xls, .csv)
          </span>
        </div>

        <div style={{
          border: '2px dashed var(--border-color)',
          borderRadius: '12px',
          padding: '36px 20px',
          textAlign: 'center',
          backgroundColor: 'var(--bg-card-subtle)',
          cursor: 'pointer',
          position: 'relative'
        }}>
          <input 
            type="file" 
            accept=".xlsx, .xls, .csv" 
            onChange={handleFileUpload}
            style={{ 
              position: 'absolute', 
              top: 0, 
              left: 0, 
              width: '100%', 
              height: '100%', 
              opacity: 0, 
              cursor: 'pointer' 
            }} 
          />
          <FileSpreadsheet size={42} color="var(--brand-green)" style={{ margin: '0 auto 12px' }} />
          <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Drop your sales spreadsheet here, or browse files
          </div>
          <p style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginTop: '4px' }}>
            Supports Tally exports, Vyapar app exports, Marg ERP sheets, or custom CSV/Excel files.
          </p>
        </div>

        {/* Upload Status & Auto Column Mapping Result */}
        {uploadStatus === 'loading' && (
          <div style={{ marginTop: '16px', display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)' }}>
            <RefreshCw size={16} className="spin-animation" />
            <span>Parsing spreadsheet rows and mapping columns...</span>
          </div>
        )}

        {uploadStatus === 'error' && (
          <div style={{ marginTop: '16px', padding: '12px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-red)', color: 'var(--badge-text-red)', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <AlertCircle size={16} />
            <span>{errorMessage}</span>
          </div>
        )}

        {uploadStatus === 'success' && uploadDetails && (
          <div style={{ marginTop: '18px', padding: '16px', borderRadius: '10px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--brand-green)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--brand-green)', fontWeight: 700, fontSize: '14px', marginBottom: '10px' }}>
              <CheckCircle2 size={16} />
              <span>Successfully imported {uploadDetails.totalRows} transactions from "{uploadDetails.fileName}"!</span>
            </div>

            <div style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginBottom: '10px' }}>
              Automatic Column Header Detection:
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '8px' }}>
              {Object.entries(uploadDetails.detectedMapping).map(([key, origCol]) => (
                <div key={key} style={{ padding: '6px 10px', borderRadius: '6px', backgroundColor: 'var(--bg-card-subtle)', fontSize: '12px' }}>
                  <span style={{ color: 'var(--text-muted)', textTransform: 'capitalize' }}>{key}: </span>
                  <strong style={{ color: 'var(--text-primary)' }}>{origCol}</strong>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Quick Manual Sale Entry Form */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
          <Plus size={18} color="var(--brand-green)" />
          <span style={{ fontSize: '15px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Quick Counter Sale Entry (Parchi / Instant Bill)
          </span>
        </div>

        <form onSubmit={handleAddManualTxn} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '12px', alignItems: 'flex-end' }}>
          <div>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Customer Name</label>
            <input 
              type="text" 
              placeholder="e.g. Verma Tea Stall"
              value={manualCustomer}
              onChange={(e) => setManualCustomer(e.target.value)}
              className="ai-input" 
              style={{ width: '100%', fontSize: '13px' }} 
              required 
            />
          </div>

          <div>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Product / Item</label>
            <input 
              type="text" 
              placeholder="e.g. Basmati Rice 10kg"
              value={manualItem}
              onChange={(e) => setManualItem(e.target.value)}
              className="ai-input" 
              style={{ width: '100%', fontSize: '13px' }} 
              required 
            />
          </div>

          <div style={{ maxWidth: '90px' }}>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Qty</label>
            <input 
              type="number" 
              min="1"
              value={manualQty}
              onChange={(e) => setManualQty(e.target.value)}
              className="ai-input" 
              style={{ width: '100%', fontSize: '13px' }} 
              required 
            />
          </div>

          <div>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Unit Price (₹)</label>
            <input 
              type="number" 
              placeholder="e.g. 1150"
              value={manualPrice}
              onChange={(e) => setManualPrice(e.target.value)}
              className="ai-input" 
              style={{ width: '100%', fontSize: '13px' }} 
              required 
            />
          </div>

          <div>
            <label style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Payment Mode</label>
            <select 
              value={manualPaymentMode}
              onChange={(e) => setManualPaymentMode(e.target.value)}
              className="ai-input" 
              style={{ width: '100%', fontSize: '13px' }}
            >
              <option value="UPI">UPI (GPay/PhonePe)</option>
              <option value="Cash (Rokad)">Cash (Rokad)</option>
              <option value="Udhar / Credit">Udhar / Credit (Khata)</option>
              <option value="Bank Transfer">Bank Transfer (NEFT)</option>
            </select>
          </div>

          <div>
            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
              <span>Record Sale</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
