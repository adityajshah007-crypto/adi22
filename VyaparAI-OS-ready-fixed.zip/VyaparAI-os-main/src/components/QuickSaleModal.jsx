import React, { useState } from 'react';
import { X, ShoppingBag, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDataStore } from '../context/DataStore';
import { formatINR } from '../utils/formatters';

export const QuickSaleModal = ({ isOpen, onClose, onSaleRecorded }) => {
  const { customers, inventory, importDataset } = useDataStore();

  const [customerName, setCustomerName] = useState('');
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [sellingPrice, setSellingPrice] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [category, setCategory] = useState('Grains & Staples');
  const [paymentStatus, setPaymentStatus] = useState('paid'); // 'paid' | 'credit'

  if (!isOpen) return null;

  // Auto-fill price and category if known product is selected
  const handleSelectProduct = (prodName) => {
    setProductName(prodName);
    const found = inventory.find(i => i.product === prodName);
    if (found) {
      setSellingPrice(found.sellingPrice || '');
      setCostPrice(found.costPrice || '');
      if (found.category) setCategory(found.category);
    }
  };

  const qty = Number(quantity) || 1;
  const price = Number(sellingPrice) || 0;
  const cost = Number(costPrice) || Math.round(price * 0.75);
  const totalRevenue = qty * price;
  const totalCost = qty * cost;
  const profit = totalRevenue - totalCost;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!productName.trim() || !sellingPrice) return;

    const finalCustomer = customerName.trim() || 'Counter Walk-in Customer';
    const invoiceNumber = `INV-${Date.now().toString().slice(-4)}`;
    const today = new Date().toISOString().split('T')[0];

    const newSale = {
      date: today,
      invoiceId: invoiceNumber,
      product: productName.trim(),
      category: category,
      quantity: qty,
      sellingPrice: price,
      revenue: totalRevenue,
      cost: totalCost,
      profit: profit,
      customer: finalCustomer
    };

    // 1. Ingest sale record
    importDataset('SALES', [newSale], { overwrite: false });

    // 2. Adjust inventory stock if matching product exists
    const updatedInventory = inventory.map(item => {
      if (item.product.toLowerCase() === productName.trim().toLowerCase()) {
        const remaining = Math.max(0, (Number(item.currentStock) || 0) - qty);
        return { ...item, currentStock: remaining };
      }
      return item;
    });
    importDataset('INVENTORY', updatedInventory, { overwrite: true });

    // 3. If credit/udhar, update customer dues
    if (paymentStatus === 'credit') {
      const existingCust = customers.find(c => (c.customerName || c.name || '').toLowerCase() === finalCustomer.toLowerCase());
      if (existingCust) {
        const updatedCustomers = customers.map(c => {
          if (c === existingCust) {
            return {
              ...c,
              totalPurchases: (Number(c.totalPurchases) || 0) + totalRevenue,
              amountDue: (Number(c.amountDue) || 0) + totalRevenue,
              pendingAmount: (Number(c.pendingAmount) || 0) + totalRevenue
            };
          }
          return c;
        });
        importDataset('CUSTOMERS', updatedCustomers, { overwrite: true });
      } else {
        const newCustomer = {
          customerName: finalCustomer,
          phone: '+91 98000 00000',
          email: '',
          totalPurchases: totalRevenue,
          amountPaid: 0,
          amountDue: totalRevenue,
          pendingAmount: totalRevenue,
          dueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
        };
        importDataset('CUSTOMERS', [newCustomer], { overwrite: false });
      }
    }

    confetti({ particleCount: 50, spread: 50 });
    if (onSaleRecorded) onSaleRecorded(newSale);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className="modal-content" 
        style={{ maxWidth: '540px', width: '92%' }} 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ShoppingBag size={18} color="var(--brand-saffron)" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Record Counter Sale / Quick Bill
            </h3>
          </div>
          <button className="header-icon-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {/* Customer Name */}
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                Customer / Party Name
              </label>
              <input 
                type="text" 
                list="customer-list"
                placeholder="e.g. Sharmaji Caterers or Walk-in Customer"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="ai-input"
                style={{ width: '100%' }}
              />
              <datalist id="customer-list">
                {customers.map((c, i) => (
                  <option key={i} value={c.customerName || c.name} />
                ))}
              </datalist>
            </div>

            {/* Product Name */}
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                Product / Item Name *
              </label>
              <input 
                type="text" 
                list="product-list"
                placeholder="Select or enter item name..."
                required
                value={productName}
                onChange={(e) => handleSelectProduct(e.target.value)}
                className="ai-input"
                style={{ width: '100%' }}
              />
              <datalist id="product-list">
                {inventory.map((inv, i) => (
                  <option key={i} value={inv.product} />
                ))}
              </datalist>
            </div>

            {/* Category & Quantity */}
            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '12px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="ai-input"
                  style={{ width: '100%' }}
                >
                  <option value="Grains & Staples">Grains & Staples</option>
                  <option value="Edible Oils">Edible Oils</option>
                  <option value="Spices & Essentials">Spices & Essentials</option>
                  <option value="Dairy & Cold">Dairy & Cold</option>
                  <option value="Beverages & Snacks">Beverages & Snacks</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Quantity (Units) *
                </label>
                <input 
                  type="number" 
                  min="1"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="ai-input"
                  style={{ width: '100%' }}
                />
              </div>
            </div>

            {/* Price & Cost */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Unit Selling Price (₹) *
                </label>
                <input 
                  type="number" 
                  min="1"
                  required
                  placeholder="₹ Rate"
                  value={sellingPrice}
                  onChange={(e) => setSellingPrice(e.target.value)}
                  className="ai-input"
                  style={{ width: '100%' }}
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '4px' }}>
                  Unit Cost Price (₹)
                </label>
                <input 
                  type="number" 
                  min="0"
                  placeholder="Wholesale cost"
                  value={costPrice}
                  onChange={(e) => setCostPrice(e.target.value)}
                  className="ai-input"
                  style={{ width: '100%' }}
                />
              </div>
            </div>

            {/* Payment Settlement Mode */}
            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Payment Status
              </label>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="button"
                  onClick={() => setPaymentStatus('paid')}
                  style={{
                    flex: 1,
                    padding: '8px 12px',
                    borderRadius: '8px',
                    border: `1px solid ${paymentStatus === 'paid' ? 'var(--brand-green)' : 'var(--border-color)'}`,
                    backgroundColor: paymentStatus === 'paid' ? 'var(--badge-bg-green)' : 'var(--bg-card-subtle)',
                    color: paymentStatus === 'paid' ? 'var(--brand-green)' : 'var(--text-secondary)',
                    fontWeight: 600,
                    fontSize: '12.5px',
                    cursor: 'pointer'
                  }}
                >
                  Paid (UPI / Cash)
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentStatus('credit')}
                  style={{
                    flex: 1,
                    padding: '8px 12px',
                    borderRadius: '8px',
                    border: `1px solid ${paymentStatus === 'credit' ? '#ef4444' : 'var(--border-color)'}`,
                    backgroundColor: paymentStatus === 'credit' ? 'var(--badge-bg-red)' : 'var(--bg-card-subtle)',
                    color: paymentStatus === 'credit' ? 'var(--badge-text-red)' : 'var(--text-secondary)',
                    fontWeight: 600,
                    fontSize: '12.5px',
                    cursor: 'pointer'
                  }}
                >
                  Pending Udhar (Credit)
                </button>
              </div>
            </div>

            {/* Live Calculation Summary */}
            <div style={{ padding: '10px 14px', borderRadius: '8px', backgroundColor: 'var(--bg-card-subtle)', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>TOTAL REVENUE</div>
                <div style={{ fontSize: '16px', fontWeight: 800, color: 'var(--brand-saffron)' }}>
                  {formatINR(totalRevenue)}
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>ESTIMATED PROFIT</div>
                <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--brand-green)' }}>
                  {formatINR(profit)}
                </div>
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" style={{ padding: '8px 18px' }}>
              <Check size={14} />
              <span>Record & Save Sale</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
