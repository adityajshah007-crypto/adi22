import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Sun, 
  Moon, 
  UploadCloud, 
  Store, 
  LogOut, 
  ChevronDown, 
  ShieldCheck, 
  CreditCard,
  Bell,
  AlertTriangle,
  MessageCircle,
  Package,
  TrendingUp,
  Sparkles,
  Menu
} from 'lucide-react';
import { checkBackendHealth } from '../services/apiClient';
import { useAuth } from '../context/AuthContext';
import { useDataStore } from '../context/DataStore';

export const Header = ({ 
  activeTab, 
  businessProfile, 
  theme, 
  toggleTheme, 
  onOpenImportModal, 
  onOpenCommandPalette, 
  onNavigateTab, 
  onOpenSandbox, 
  onOpenSubscriptionModal,
  onOpenWhatsApp,
  onOpenPOModal,
  onToggleMobileMenu
}) => {
  const [backendOnline, setBackendOnline] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const userMenuRef = useRef(null);
  const notificationsRef = useRef(null);
  const { user, business, logout } = useAuth();
  const { lowStockItems, customers } = useDataStore();

  const debtors = (customers || []).filter(c => Number(c.amountDue) > 0);
  const unreadAlertsCount = (lowStockItems?.length || 0) + (debtors?.length || 0);

  useEffect(() => {
    checkBackendHealth().then(res => setBackendOnline(res.online));
    const interval = setInterval(() => {
      checkBackendHealth().then(res => setBackendOnline(res.online));
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(e.target)) {
        setNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getTabLabel = () => {
    switch (activeTab) {
      case 'command-center': return 'Command Center';
      case 'pitch-deck': return 'Investor Pitch & Business Model';
      case 'import-data': return 'Import Business Data';
      case 'ai-advisor': return 'AI Advisor';
      case 'sales': return 'Sales Management';
      case 'inventory': return 'Inventory & Stock';
      case 'customers': return 'Customers Directory';
      case 'payments': return 'Payments & Khata';
      case 'forecasts': return 'Demand & Cash Forecasts';
      case 'actions': return 'AI Recommendations & Actions';
      case 'reports': return 'Business Reports';
      case 'settings': return 'Platform Settings';
      default: return 'Command Center';
    }
  };

  return (
    <header className="app-header">
      {/* Left side: Mobile Toggle + Business & Breadcrumb */}
      <div className="header-left">
        {onToggleMobileMenu && (
          <button 
            type="button"
            className="mobile-menu-btn"
            onClick={onToggleMobileMenu}
            aria-label="Open Navigation Menu"
            title="Open Menu"
          >
            <Menu size={18} />
          </button>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div className="business-selector-badge">
            <Store size={15} color="var(--brand-saffron)" />
            <span>{businessProfile.name}</span>
          </div>
          <span style={{ color: 'var(--text-muted)' }} className="header-hide-mobile">/</span>
          <span style={{ fontWeight: 600, fontSize: '13.5px', color: 'var(--text-primary)' }} className="header-hide-mobile">
            {getTabLabel()}
          </span>
        </div>
      </div>

      {/* Right side: Backend status, Search, Import Data, Theme Toggle, User Profile */}
      <div className="header-right">
        {/* Live Backend Connection Indicator */}
        <div 
          className="header-hide-mobile"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '7px',
            fontSize: '11.5px',
            fontWeight: 700,
            padding: '5px 10px',
            borderRadius: '8px',
            backgroundColor: backendOnline ? 'rgba(16, 185, 129, 0.12)' : 'var(--bg-card-subtle)',
            color: backendOnline ? 'var(--brand-green)' : 'var(--text-muted)',
            border: `1px solid ${backendOnline ? 'rgba(16, 185, 129, 0.35)' : 'var(--border-color)'}`,
            boxShadow: backendOnline ? '0 0 12px rgba(16, 185, 129, 0.2)' : 'none'
          }}
          title={backendOnline ? "FastAPI Backend & PostgreSQL Connected" : "Connecting to backend..."}
        >
          {backendOnline ? (
            <span className="radar-dot" />
          ) : (
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#94a3b8' }} />
          )}
          <span>{backendOnline ? 'CORE API: LIVE' : 'API: SYNCING'}</span>
        </div>

        {/* Search */}
        <button className="search-button-pill" onClick={onOpenCommandPalette}>
          <Search size={15} />
          <span>Search or query AI...</span>
          <span className="search-shortcut-tag header-hide-tablet">⌘K</span>
        </button>

        {/* Pitch Deck Button */}
        <button
          onClick={() => onNavigateTab && onNavigateTab('pitch-deck')}
          className="btn-secondary header-hide-tablet"
          style={{
            padding: '7px 13px',
            fontSize: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            background: activeTab === 'pitch-deck' 
              ? 'linear-gradient(135deg, rgba(0, 229, 255, 0.2) 0%, rgba(0, 229, 255, 0.08) 100%)' 
              : 'var(--bg-card-subtle)',
            borderColor: activeTab === 'pitch-deck' ? 'var(--brand-saffron)' : 'var(--border-color)',
            color: activeTab === 'pitch-deck' ? 'var(--brand-saffron)' : 'var(--text-primary)',
            fontWeight: 700,
            boxShadow: activeTab === 'pitch-deck' ? '0 0 16px rgba(0, 229, 255, 0.35)' : 'none'
          }}
          title="Open Investor Pitch Deck & Business Model"
        >
          <span>🚀</span>
          <span>Pitch Deck</span>
        </button>

        {/* Market Simulator Sandbox Button */}
        <button
          onClick={() => onOpenSandbox && onOpenSandbox()}
          className="btn-secondary header-hide-tablet"
          style={{
            padding: '7px 12px',
            fontSize: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            borderColor: 'rgba(16, 185, 129, 0.4)',
            color: 'var(--brand-green)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fontWeight: 700,
            boxShadow: '0 0 12px rgba(16, 185, 129, 0.2)'
          }}
          title="Simulate live market events (UPI payment, stockouts, etc.)"
        >
          <span style={{ fontSize: '13px' }}>⚡</span>
          <span>Sandbox</span>
        </button>

        {/* Prominent Import Data Button in Header */}
        <button 
          className="btn-primary header-hide-mobile" 
          onClick={onOpenImportModal}
          style={{ padding: '7px 14px', fontSize: '12px' }}
        >
          <UploadCloud size={14} />
          <span>Import Data</span>
        </button>

        {/* Theme Toggle */}
        <button 
          className="header-icon-btn" 
          onClick={toggleTheme}
          title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
        >
          {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
        </button>

        {/* Operational Notifications Center */}
        <div style={{ position: 'relative' }} ref={notificationsRef}>
          <button
            className="header-icon-btn"
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            title="Operational Alerts & Tasks"
            style={{ position: 'relative' }}
          >
            <Bell size={16} />
            {unreadAlertsCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: '2px',
                  right: '2px',
                  width: '16px',
                  height: '16px',
                  borderRadius: '50%',
                  backgroundColor: '#ef4444',
                  color: '#ffffff',
                  fontSize: '9.5px',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 0 6px rgba(239, 68, 68, 0.6)'
                }}
              >
                {unreadAlertsCount}
              </span>
            )}
          </button>

          {notificationsOpen && (
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                right: 0,
                width: '320px',
                maxHeight: '440px',
                backgroundColor: 'var(--bg-card)',
                border: '1px solid var(--border-color)',
                borderRadius: '12px',
                boxShadow: 'var(--elevated-shadow)',
                zIndex: 100,
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden',
                animation: 'modalEnter 0.15s ease-out'
              }}
            >
              <div style={{
                padding: '12px 14px',
                borderBottom: '1px solid var(--border-color)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                backgroundColor: 'var(--bg-card-subtle)'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Bell size={14} color="var(--brand-saffron)" />
                  <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>
                    Operational Alerts ({unreadAlertsCount})
                  </span>
                </div>
                <span style={{ fontSize: '10.5px', color: 'var(--brand-green)', fontWeight: 700, textTransform: 'uppercase' }}>
                  Live Monitor
                </span>
              </div>

              <div style={{ padding: '8px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {/* Low Stock Alerts */}
                {lowStockItems && lowStockItems.slice(0, 3).map((item, idx) => (
                  <div
                    key={`stock-${idx}`}
                    style={{
                      padding: '10px 12px',
                      borderRadius: '8px',
                      backgroundColor: 'var(--bg-card-subtle)',
                      border: '1px solid rgba(239, 68, 68, 0.25)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <AlertTriangle size={13} color="#ef4444" />
                        <span style={{ fontSize: '11px', fontWeight: 700, color: '#ef4444', textTransform: 'uppercase' }}>
                          Low Stock Alert
                        </span>
                      </div>
                      <span style={{ fontSize: '11px', fontWeight: 700, color: '#ef4444' }}>
                        {item.currentStock} left (min {item.reorderLevel || 10})
                      </span>
                    </div>
                    <div style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                      {item.product}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '4px' }}>
                      <button
                        onClick={() => {
                          setNotificationsOpen(false);
                          if (onOpenPOModal) {
                            onOpenPOModal([item]);
                          } else if (onNavigateTab) {
                            onNavigateTab('inventory');
                          }
                        }}
                        className="btn-primary"
                        style={{ padding: '3px 8px', fontSize: '11px' }}
                      >
                        <Package size={11} />
                        <span>Reorder PO</span>
                      </button>
                    </div>
                  </div>
                ))}

                {/* Overdue Debtors */}
                {debtors && debtors.slice(0, 2).map((d, idx) => (
                  <div
                    key={`debt-${idx}`}
                    style={{
                      padding: '10px 12px',
                      borderRadius: '8px',
                      backgroundColor: 'var(--bg-card-subtle)',
                      border: '1px solid rgba(245, 158, 11, 0.3)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <MessageCircle size={13} color="var(--badge-text-amber)" />
                        <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--badge-text-amber)', textTransform: 'uppercase' }}>
                          Pending Udhar Due
                        </span>
                      </div>
                      <span style={{ fontSize: '11.5px', fontWeight: 800, color: '#ef4444' }}>
                        ₹{Number(d.amountDue).toLocaleString('en-IN')}
                      </span>
                    </div>
                    <div style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                      {d.customerName}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '4px' }}>
                      <button
                        onClick={() => {
                          setNotificationsOpen(false);
                          if (onOpenWhatsApp) {
                            onOpenWhatsApp({
                              name: d.customerName,
                              phone: d.phone || '+91 98000 00000',
                              pendingAmount: Number(d.amountDue),
                              overdueDays: 21
                            });
                          }
                        }}
                        className="btn-whatsapp"
                        style={{ padding: '3px 8px', fontSize: '11px', borderRadius: '4px' }}
                      >
                        <MessageCircle size={11} />
                        <span>WhatsApp Reminder</span>
                      </button>
                    </div>
                  </div>
                ))}

                {/* Festive Forecast Alert */}
                <div
                  style={{
                    padding: '10px 12px',
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 229, 255, 0.08)',
                    border: '1px solid rgba(0, 229, 255, 0.25)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '4px'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <Sparkles size={13} color="var(--brand-saffron)" />
                      <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--brand-saffron)' }}>
                        FESTIVE DEMAND SURGE
                      </span>
                    </div>
                    <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--brand-green)' }}>
                      +55% Vol
                    </span>
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                    Diwali & Dhanteras surge model active. Stock edible oils and staples.
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '4px' }}>
                    <button
                      onClick={() => {
                        setNotificationsOpen(false);
                        if (onNavigateTab) onNavigateTab('forecasts');
                      }}
                      className="btn-secondary"
                      style={{ padding: '3px 8px', fontSize: '11px' }}
                    >
                      <TrendingUp size={11} />
                      <span>View Forecast</span>
                    </button>
                  </div>
                </div>
              </div>

              <div style={{ padding: '8px 12px', borderTop: '1px solid var(--border-color)', textAlign: 'center', backgroundColor: 'var(--bg-card-subtle)' }}>
                <button
                  onClick={() => {
                    setNotificationsOpen(false);
                    if (onNavigateTab) onNavigateTab('actions');
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--brand-saffron)',
                    fontSize: '11.5px',
                    fontWeight: 700,
                    cursor: 'pointer'
                  }}
                >
                  Open AI Action Center & Recommendations →
                </button>
              </div>
            </div>
          )}
        </div>


        {/* User / Business Owner Profile Menu */}
        <div style={{ position: 'relative' }} ref={userMenuRef}>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '5px 10px',
              backgroundColor: 'var(--bg-card-subtle)',
              border: '1px solid var(--border-color)',
              borderRadius: '8px',
              cursor: 'pointer',
              color: 'var(--text-primary)'
            }}
          >
            <div style={{
              width: '26px',
              height: '26px',
              borderRadius: '6px',
              backgroundColor: 'var(--brand-saffron)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '12px'
            }}>
              {user?.full_name ? user.full_name[0].toUpperCase() : 'O'}
            </div>
            <div style={{ textAlign: 'left', display: 'flex', flexDirection: 'column' }}>
              <span style={{ fontSize: '12.5px', fontWeight: 600, lineHeight: 1.2 }}>
                {user?.full_name || businessProfile.owner || 'Owner'}
              </span>
              <span style={{ fontSize: '10px', color: 'var(--brand-saffron)', fontWeight: 700, textTransform: 'uppercase' }}>
                {user?.role || 'Owner'}
              </span>
            </div>
            <ChevronDown size={14} color="var(--text-muted)" />
          </button>

          {/* User Menu Dropdown */}
          {userMenuOpen && (
            <div style={{
              position: 'absolute',
              top: 'calc(100% + 8px)',
              right: 0,
              width: '240px',
              backgroundColor: 'var(--bg-card)',
              border: '1px solid var(--border-color)',
              borderRadius: '10px',
              boxShadow: 'var(--elevated-shadow)',
              zIndex: 100,
              padding: '6px',
              animation: 'modalEnter 0.15s ease-out'
            }}>
              <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {user?.full_name || 'Business Owner'}
                </div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {user?.email || 'owner@bharat.com'}
                </div>
                <div style={{
                  marginTop: '8px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '4px',
                  fontSize: '11px',
                  padding: '2px 6px',
                  borderRadius: '4px',
                  backgroundColor: 'var(--badge-bg-green)',
                  color: 'var(--badge-text-green)',
                  fontWeight: 600
                }}>
                  <ShieldCheck size={12} />
                  <span>{business?.id || businessProfile?.id || 'BIZ-BHARAT-001'}</span>
                </div>
              </div>

              <div style={{ padding: '6px 4px 2px' }}>
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    if (onOpenSubscriptionModal) onOpenSubscriptionModal();
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 12px',
                    border: 'none',
                    borderRadius: '6px',
                    backgroundColor: 'transparent',
                    color: 'var(--brand-saffron)',
                    fontSize: '12.5px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'background-color 0.15s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(0, 229, 255, 0.08)'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <CreditCard size={15} />
                  <span>SaaS Plans & Billing (Pro)</span>
                </button>

                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    logout();
                  }}
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 12px',
                    border: 'none',
                    borderRadius: '6px',
                    backgroundColor: 'transparent',
                    color: 'var(--badge-text-red)',
                    fontSize: '12.5px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'background-color 0.15s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'var(--badge-bg-red)'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <LogOut size={15} />
                  <span>Sign Out / Switch Business</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>

  );
};
