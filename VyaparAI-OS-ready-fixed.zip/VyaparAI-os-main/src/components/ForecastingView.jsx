import React, { useState } from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Flame, 
  ShoppingBag, 
  AlertTriangle,
  FileText
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { formatINR } from '../utils/formatters';

export const ForecastingView = ({ business, onGeneratePO }) => {
  const [activeFestival, setActiveFestival] = useState('diwali'); // none, diwali, navratri, wedding, monthend

  const festivalMultipliers = {
    none: { name: 'Normal Baseline (No Festival)', multiplier: 1.0, icon: '📊', stockoutDays: 18, projectedGrowth: '+0%' },
    diwali: { name: 'Diwali & Dhanteras Festive Surge', multiplier: 1.55, icon: '🪔', stockoutDays: 6, projectedGrowth: '+55%' },
    navratri: { name: 'Navratri & Dussehra Festival', multiplier: 1.35, icon: '🌸', stockoutDays: 9, projectedGrowth: '+35%' },
    wedding: { name: 'Winter Wedding Season (Lagan)', multiplier: 1.45, icon: '💍', stockoutDays: 8, projectedGrowth: '+45%' },
    monthend: { name: 'Month-End Payday Bump', multiplier: 1.20, icon: '💳', stockoutDays: 14, projectedGrowth: '+20%' }
  };

  const currentMultiplier = festivalMultipliers[activeFestival].multiplier;

  // Generate 30-day forecast projection
  const forecastData = Array.from({ length: 30 }).map((_, index) => {
    const day = index + 1;
    const baseDailySales = (business.stats.monthlySalesTarget || 1000000) / 30;
    // Add realistic weekend bumps (every 7 days) and festival multiplier
    const weekendBump = (day % 7 === 5 || day % 7 === 6) ? 1.3 : 1.0;
    const projectedSales = Math.round(baseDailySales * weekendBump * currentMultiplier);
    const projectedCash = Math.round((business.stats.cashReserve || 250000) + (projectedSales * 0.22 * day));

    return {
      day: `Day ${day}`,
      sales: projectedSales,
      projectedCash
    };
  });

  const totalProjectedSales = forecastData.reduce((sum, d) => sum + d.sales, 0);
  const lowStockItems = business.inventory.filter(i => i.stock <= i.minStock);

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Demand & Cash Flow Forecasting</h1>
          <p className="page-subtitle">
            30-day forward projection with real-time Indian festival and seasonal demand simulation.
          </p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-primary"
            onClick={() => onGeneratePO(lowStockItems)}
          >
            <FileText size={15} />
            <span>Pre-order for Festival Rush</span>
          </button>
        </div>
      </div>

      {/* Festival Surge Simulator Picker */}
      <div className="dashboard-card" style={{ background: 'linear-gradient(135deg, rgba(0, 229, 255, 0.06), rgba(2, 132, 199, 0.03))' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
          <Flame size={18} color="var(--brand-saffron)" />
          <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Indian Festival & Seasonality Simulator
          </span>
          <span className="badge badge-warning" style={{ marginLeft: 'auto' }}>
            Simulate Demand Peaks
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '10px' }}>
          {Object.entries(festivalMultipliers).map(([key, item]) => {
            const isSelected = activeFestival === key;
            return (
              <div
                key={key}
                onClick={() => setActiveFestival(key)}
                style={{
                  backgroundColor: isSelected ? 'var(--accent-primary)' : 'var(--bg-card)',
                  color: isSelected ? 'var(--accent-primary-text)' : 'var(--text-primary)',
                  border: `1px solid ${isSelected ? 'transparent' : 'var(--border-color)'}`,
                  borderRadius: '10px',
                  padding: '12px',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: isSelected ? '0 4px 12px rgba(0, 0, 0, 0.12)' : 'none'
                }}
              >
                <div style={{ fontSize: '18px', marginBottom: '4px' }}>{item.icon}</div>
                <div style={{ fontSize: '13px', fontWeight: 700 }}>{item.name}</div>
                <div style={{ 
                  fontSize: '11.5px', 
                  color: isSelected ? 'rgba(255, 255, 255, 0.8)' : 'var(--brand-green)', 
                  fontWeight: 600,
                  marginTop: '4px' 
                }}>
                  {item.projectedGrowth} Volume Surge
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* KPI Projection Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Projected 30-Day Sales</span>
            <div className="kpi-icon-pill">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(totalProjectedSales)}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>{festivalMultipliers[activeFestival].projectedGrowth} above baseline</span>
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Estimated Days Until Stockout</span>
            <div className="kpi-icon-pill" style={{ color: '#ef4444' }}>
              <AlertTriangle size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: festivalMultipliers[activeFestival].stockoutDays < 10 ? '#ef4444' : 'inherit' }}>
            {festivalMultipliers[activeFestival].stockoutDays} Days
          </div>
          <div className="kpi-trend negative">
            <span>Buffer exhausts without pre-ordering</span>
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Safety Stock Budget Needed</span>
            <div className="kpi-icon-pill">
              <ShoppingBag size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(Math.round(totalProjectedSales * 0.35))}</div>
          <div className="kpi-trend positive">
            <span>Procure 15 days before festival</span>
          </div>
        </div>
      </div>

      {/* 30-Day Forecast Graph */}
      <div className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">30-Day Projected Daily Sales Curve</h2>
            <p className="card-subheading">
              Dynamic demand projection adjusted for {festivalMultipliers[activeFestival].name}
            </p>
          </div>
        </div>

        <div style={{ width: '100%', height: 340 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={forecastData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00e5ff" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#00e5ff" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="var(--text-muted)" fontSize={11} interval={3} tickLine={false} />
              <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} tickFormatter={(val) => `₹${Math.round(val / 1000)}k`} />
              <Tooltip 
                formatter={(val) => [formatINR(val), 'Estimated Sales']}
                contentStyle={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', borderRadius: '8px', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="sales" stroke="#00e5ff" strokeWidth={2} fillOpacity={1} fill="url(#salesGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
