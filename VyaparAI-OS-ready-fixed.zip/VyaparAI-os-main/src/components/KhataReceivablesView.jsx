import React, { useState } from 'react';
import { 
  AlertCircle, 
  MessageCircle, 
  Search, 
  CheckCircle2, 
  IndianRupee, 
  ShieldAlert, 
  ShieldCheck,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatINR } from '../utils/formatters';

export const KhataReceivablesView = ({ business, onOpenWhatsApp, onMarkPaid }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAging, setFilterAging] = useState('all');

  const customers = business.customers;
  const totalPending = customers.reduce((sum, c) => sum + c.pendingAmount, 0);

  // Aging buckets
  const bucket30Plus = customers.filter(c => c.overdueDays >= 30);
  const bucket15To30 = customers.filter(c => c.overdueDays >= 15 && c.overdueDays < 30);
  const bucketUnder15 = customers.filter(c => c.overdueDays < 15);

  const amount30Plus = bucket30Plus.reduce((sum, c) => sum + c.pendingAmount, 0);
  const amount15To30 = bucket15To30.reduce((sum, c) => sum + c.pendingAmount, 0);
  const amountUnder15 = bucketUnder15.reduce((sum, c) => sum + c.pendingAmount, 0);

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.phone.includes(searchTerm);
    if (!matchesSearch) return false;

    if (filterAging === '30plus') return c.overdueDays >= 30;
    if (filterAging === '15to30') return c.overdueDays >= 15 && c.overdueDays < 30;
    if (filterAging === 'under15') return c.overdueDays < 15;
    return true;
  });

  const handleSettle = (customer) => {
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.7 }
    });
    if (onMarkPaid) {
      onMarkPaid(customer.id);
    }
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Khata & Udhar (Receivables Book)</h1>
          <p className="page-subtitle">
            Track customer balances, credit limits, overdue aging, and collect payments via WhatsApp.
          </p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-whatsapp"
            onClick={() => onOpenWhatsApp(bucket30Plus[0] || customers[0])}
            style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '8px 16px', borderRadius: '8px', fontWeight: 600, cursor: 'pointer' }}
          >
            <MessageCircle size={16} />
            <span>Send Batch WhatsApp Reminders</span>
          </button>
        </div>
      </div>

      {/* KPI Cards (Aging Buckets) */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Total Uncollected Udhar</span>
            <div className="kpi-icon-pill">
              <IndianRupee size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#ef4444' }}>{formatINR(totalPending)}</div>
          <div className="kpi-trend negative">Across {customers.length} business accounts</div>
        </div>

        <div className="kpi-card" onClick={() => setFilterAging('30plus')} style={{ cursor: 'pointer' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">&gt; 30 Days Overdue (Critical)</span>
            <div className="kpi-icon-pill" style={{ color: '#ef4444' }}>
              <ShieldAlert size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#ef4444' }}>{formatINR(amount30Plus)}</div>
          <div className="kpi-trend negative">{bucket30Plus.length} High-risk accounts</div>
        </div>

        <div className="kpi-card" onClick={() => setFilterAging('15to30')} style={{ cursor: 'pointer' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">15–30 Days Overdue</span>
            <div className="kpi-icon-pill" style={{ color: '#f59e0b' }}>
              <AlertCircle size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#f59e0b' }}>{formatINR(amount15To30)}</div>
          <div className="kpi-trend" style={{ color: '#f59e0b' }}>{bucket15To30.length} Accounts in follow-up</div>
        </div>

        <div className="kpi-card" onClick={() => setFilterAging('under15')} style={{ cursor: 'pointer' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">0–14 Days (Current Terms)</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-green)' }}>
              <ShieldCheck size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: 'var(--brand-green)' }}>{formatINR(amountUnder15)}</div>
          <div className="kpi-trend positive">{bucketUnder15.length} Standard accounts</div>
        </div>
      </div>

      {/* Customer Ledger Table */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '14px', marginBottom: '18px' }}>
          <div className="tabs-navigation-bar">
            <button 
              className={`tab-nav-btn ${filterAging === 'all' ? 'active' : ''}`}
              onClick={() => setFilterAging('all')}
            >
              All Parties ({customers.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterAging === '30plus' ? 'active' : ''}`}
              onClick={() => setFilterAging('30plus')}
            >
              &gt; 30 Days Overdue ({bucket30Plus.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterAging === '15to30' ? 'active' : ''}`}
              onClick={() => setFilterAging('15to30')}
            >
              15–30 Days ({bucket15To30.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterAging === 'under15' ? 'active' : ''}`}
              onClick={() => setFilterAging('under15')}
            >
              Recent / Normal ({bucketUnder15.length})
            </button>
          </div>

          <div style={{ position: 'relative', width: '260px' }}>
            <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
            <input 
              type="text"
              placeholder="Search customer name or mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="ai-input"
              style={{ paddingLeft: '32px', fontSize: '13px' }}
            />
          </div>
        </div>

        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Customer / Party</th>
                <th>Phone Number</th>
                <th>Pending Balance</th>
                <th>Overdue Days</th>
                <th>Credit Limit</th>
                <th>Trust Score</th>
                <th>Notes / History</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((c) => {
                const isCritical = c.overdueDays >= 30;
                const creditUsedPercent = Math.min((c.pendingAmount / c.creditLimit) * 100, 100);

                return (
                  <tr key={c.id}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{c.name}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>ID: {c.id}</div>
                    </td>
                    <td>
                      <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>{c.phone}</div>
                    </td>
                    <td>
                      <div style={{ fontSize: '14.5px', fontWeight: 700, color: isCritical ? '#ef4444' : 'var(--text-primary)' }}>
                        {formatINR(c.pendingAmount)}
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${isCritical ? 'badge-danger' : c.overdueDays >= 15 ? 'badge-warning' : 'badge-success'}`}>
                        {c.overdueDays} days
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>{formatINR(c.creditLimit)}</div>
                      <div style={{ width: '100px', height: '5px', backgroundColor: 'var(--border-color)', borderRadius: '3px', marginTop: '4px', overflow: 'hidden' }}>
                        <div style={{ 
                          width: `${creditUsedPercent}%`, 
                          height: '100%', 
                          backgroundColor: creditUsedPercent > 85 ? '#ef4444' : 'var(--brand-green)' 
                        }} />
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${c.trustScore.includes('Risk') ? 'badge-danger' : c.trustScore.includes('Good') ? 'badge-success' : 'badge-info'}`}>
                        {c.trustScore}
                      </span>
                    </td>
                    <td style={{ maxWidth: '200px' }}>
                      <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{c.notes}</span>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '8px' }}>
                        <button 
                          className="btn-whatsapp"
                          style={{ padding: '5px 10px', fontSize: '12px', borderRadius: '6px', cursor: 'pointer' }}
                          onClick={() => onOpenWhatsApp(c)}
                          title="Send WhatsApp Payment Link"
                        >
                          <MessageCircle size={13} />
                          <span>WhatsApp</span>
                        </button>

                        <button 
                          className="btn-secondary"
                          style={{ padding: '5px 10px', fontSize: '12px' }}
                          onClick={() => handleSettle(c)}
                          title="Record Payment Received"
                        >
                          <CheckCircle2 size={13} color="var(--brand-green)" />
                          <span>Paid</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
