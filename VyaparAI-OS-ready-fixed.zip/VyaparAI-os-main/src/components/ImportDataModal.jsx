import React, { useState } from 'react';
import { 
  X, 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle2, 
  Download, 
  FileText, 
} from 'lucide-react';
import { downloadSampleTemplate } from '../utils/dataParser';

export const ImportDataModal = ({ isOpen, onClose, onFileImported }) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [importSuccess, setImportSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file) => {
    setSelectedFile(file);
    // Simulate import acknowledgement
    setTimeout(() => {
      setImportSuccess(true);
    }, 600);
  };

  const handleConfirm = () => {
    if (onFileImported && selectedFile) {
      onFileImported(selectedFile);
    }
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '580px' }}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FileSpreadsheet size={18} color="var(--brand-green)" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Import Business Data (Excel / CSV)
            </h3>
          </div>
          <button className="header-icon-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        <div className="modal-body">
          <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
            Upload sales ledgers, customer Udhar records, or inventory spreadsheets. Supports <strong>.xlsx, .xls, and .csv</strong> exports from Tally, Marg ERP, Vyapar, or custom Excel sheets.
          </p>

          {/* Drag & Drop Box */}
          <div 
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            style={{
              border: `2px dashed ${dragActive ? 'var(--brand-green)' : 'var(--border-color)'}`,
              borderRadius: '12px',
              padding: '36px 20px',
              textAlign: 'center',
              backgroundColor: dragActive ? 'rgba(16, 185, 129, 0.05)' : 'var(--bg-card-subtle)',
              cursor: 'pointer',
              position: 'relative',
              transition: 'all 0.15s ease'
            }}
          >
            <input 
              type="file" 
              accept=".xlsx, .xls, .csv" 
              onChange={handleChange}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                opacity: 0,
                cursor: 'pointer'
              }}
            />

            <UploadCloud size={40} color={dragActive ? 'var(--brand-green)' : 'var(--text-muted)'} style={{ margin: '0 auto 10px' }} />
            <div style={{ fontSize: '14.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
              {selectedFile ? selectedFile.name : 'Click to select or drag and drop spreadsheet'}
            </div>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>
              {selectedFile ? `${(selectedFile.size / 1024).toFixed(1)} KB` : 'Maximum file size: 25 MB'}
            </div>
          </div>

          {importSuccess && (
            <div style={{ padding: '12px 14px', borderRadius: '8px', backgroundColor: 'var(--badge-bg-green)', color: 'var(--badge-text-green)', fontSize: '12.5px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <CheckCircle2 size={16} />
              <span>File ready for processing: <strong>{selectedFile.name}</strong></span>
            </div>
          )}

          {/* Template Download Prompt */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12.5px', color: 'var(--text-secondary)' }}>
              <FileText size={15} color="var(--brand-blue)" />
              <span>Need the recommended format template?</span>
            </div>
            <button 
              className="btn-secondary" 
              style={{ padding: '4px 10px', fontSize: '12px' }}
              onClick={downloadSampleTemplate}
            >
              <Download size={13} />
              <span>Download Template</span>
            </button>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn-primary" onClick={handleConfirm} disabled={!selectedFile}>
            <span>Process & Import Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
