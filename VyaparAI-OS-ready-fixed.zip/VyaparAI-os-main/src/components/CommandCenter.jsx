import React from 'react';
import { 
  IndianRupee, 
  TrendingUp, 
  Percent, 
  ShoppingBag, 
  Package, 
  AlertTriangle, 
  WalletCards, 
  ClipboardList, 
  Sparkles, 
  ArrowUpRight, 
  ArrowDownRight, 
  Store, 
  ChevronRight,
  UploadCloud
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { useDataStore } from '../context/DataStore';

export const CommandCenter = ({ onNavigateTab, onOpenImportModal }) => {
  const { 
    businessProfile, 
    derivedKPIs, 
    sales, 
    _inventory, 
    _customers, 
    salesTrend, 
    aiInsights, 
    lowStockItems 
  } = useDataStore();

  return (
    <div className="page-container">
      {/* Page Title */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Command Center</h1>
          <p className="page-subtitle">
            Executive operational hub for {businessProfile.name} • All core metrics, inventory triggers, and AI highlights.
          </p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-primary"
            onClick={onOpenImportModal}
            style={{ fontSize: '13px', padding: '7px 14px' }}
          >
            <UploadCloud size={15} />
            <span>Import Data (Excel/CSV)</span>
          </button>
        </div>
      </div>

      {/* ====================================================================
          SECTION 1: BUSINESS OVERVIEW (CYBER HUD BANNER)
          ==================================================================== */}
      <section className="dashboard-card" style={{ 
        background: 'linear-gradient(135deg, rgba(0, 229, 255, 0.08) 0%, rgba(2, 132, 199, 0.06) 50%, rgba(139, 92, 246, 0.04) 100%)', 
        borderColor: 'rgba(0, 229, 255, 0.3)',
        boxShadow: '0 8px 32px 0 rgba(0, 229, 255, 0.08), 0 0 0 1px rgba(0, 229, 255, 0.2)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{
              width: '52px',
              height: '52px',
              borderRadius: '13px',
              background: 'linear-gradient(135deg, #00f0ff 0%, #0284c7 100%)',
              color: '#030712',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 900,
              fontSize: '24px',
              boxShadow: '0 0 24px rgba(0, 229, 255, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.4)'
            }}>
              <Store size={28} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <h2 style={{ fontSize: '20px', fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.4px' }}>
                  {businessProfile.name}
                </h2>
                <span className="badge badge-saffron" style={{ fontSize: '11px' }}>
                  {businessProfile.type || 'Retail & Wholesale SMB'}
                </span>
                <span style={{ 
                  display: 'inline-flex', 
                  alignItems: 'center', 
                  gap: '6px', 
                  fontSize: '11px', 
                  fontWeight: 700, 
                  padding: '3px 9px', 
                  borderRadius: '999px',
                  backgroundColor: 'var(--badge-bg-green)',
                  color: 'var(--brand-green)',
                  border: '1px solid rgba(16, 185, 129, 0.3)'
                }}>
                  <span className="radar-dot" />
                  <span>ONLINE • NODE ACTIVE</span>
                </span>
              </div>
              <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                <span>Proprietor: <strong style={{ color: 'var(--text-primary)' }}>{businessProfile.owner}</strong></span>
                <span>•</span>
                <span>Location: <strong style={{ color: 'var(--text-primary)' }}>{businessProfile.location}</strong></span>
                <span>•</span>
                <span>GSTIN: <span className="font-mono" style={{ color: 'var(--brand-blue)', fontWeight: 600 }}>{businessProfile.gstin}</span></span>
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ 
              textAlign: 'right', 
              padding: '8px 16px', 
              borderRadius: '10px', 
              background: 'var(--bg-card-subtle)',
              border: '1px solid var(--border-color)',
              boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.05)'
            }}>
              <div style={{ fontSize: '10.5px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.5px' }}>Business Health Index</div>
              <div style={{ fontSize: '18px', fontWeight: 900, color: 'var(--brand-green)', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px' }}>
                <span>88 / 100</span>
                <span style={{ fontSize: '11.5px', padding: '1px 6px', borderRadius: '4px', backgroundColor: 'var(--badge-bg-green)' }}>OPTIMAL</span>
              </div>
            </div>
            <button 
              className="btn-primary" 
              onClick={() => onNavigateTab('ai-advisor')}
              style={{ fontSize: '13px', padding: '8px 16px' }}
            >
              <Sparkles size={15} />
              <span>Ask AI Advisor</span>
            </button>
          </div>
        </div>
      </section>

      {/* ====================================================================
          8 CORE KPIS GRID WITH CYBER ACCENTS
          Revenue | Profit | Profit Margin | Sales | Inventory Value | Low Stock | Outstanding Payments | Orders
          ==================================================================== */}
      <div className="kpi-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
        {/* 1. Revenue */}
        <div className="kpi-card" style={{ borderTop: '2px solid var(--brand-saffron)' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Revenue</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-saffron)', borderColor: 'rgba(0, 229, 255, 0.3)', backgroundColor: 'rgba(0, 229, 255, 0.1)' }}>
              <IndianRupee size={17} />
            </div>
          </div>
          <div className="kpi-value">{derivedKPIs.revenue.formatted}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>{derivedKPIs.revenue.trend} {derivedKPIs.revenue.subtext}</span>
          </div>
        </div>

        {/* 2. Profit */}
        <div className="kpi-card" style={{ borderTop: '2px solid var(--brand-green)' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Profit (Net)</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-green)', borderColor: 'rgba(16, 185, 129, 0.3)', backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
              <TrendingUp size={17} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: 'var(--brand-green)' }}>{derivedKPIs.profit.formatted}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>{derivedKPIs.profit.trend} {derivedKPIs.profit.subtext}</span>
          </div>
        </div>

        {/* 3. Profit Margin */}
        <div className="kpi-card" style={{ borderTop: '2px solid var(--brand-cyan)' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Profit Margin</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-cyan)', borderColor: 'rgba(6, 182, 212, 0.3)', backgroundColor: 'rgba(6, 182, 212, 0.1)' }}>
              <Percent size={17} />
            </div>
          </div>
          <div className="kpi-value">{derivedKPIs.profitMargin.formatted}</div>
          <div className="kpi-trend negative">
            <ArrowDownRight size={14} />
            <span>{derivedKPIs.profitMargin.trend} ({derivedKPIs.profitMargin.subtext})</span>
          </div>
        </div>

        {/* 4. Sales */}
        <div className="kpi-card" style={{ borderTop: '2px solid var(--brand-blue)' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Sales Volume</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-blue)', borderColor: 'rgba(14, 165, 233, 0.3)', backgroundColor: 'rgba(14, 165, 233, 0.1)' }}>
              <ShoppingBag size={17} />
            </div>
          </div>
          <div className="kpi-value">{derivedKPIs.sales.formatted}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>{derivedKPIs.sales.trend} {derivedKPIs.sales.subtext}</span>
          </div>
        </div>

        {/* 5. Inventory Value */}
        <div className="kpi-card" onClick={() => onNavigateTab('inventory')} style={{ cursor: 'pointer', borderTop: '2px solid var(--brand-purple)' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Inventory Value</span>
            <div className="kpi-icon-pill" style={{ color: 'var(--brand-purple)', borderColor: 'rgba(139, 92, 246, 0.3)', backgroundColor: 'rgba(139, 92, 246, 0.1)' }}>
              <Package size={17} />
            </div>
          </div>
          <div className="kpi-value">{derivedKPIs.inventoryValue.formatted}</div>
          <div className="kpi-trend neutral">
            <span>{derivedKPIs.inventoryValue.subtext}</span>
          </div>
        </div>

        {/* 6. Low Stock */}
        <div className="kpi-card" onClick={() => onNavigateTab('inventory')} style={{ cursor: 'pointer', borderTop: '2px solid #ef4444' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Low Stock</span>
            <div className="kpi-icon-pill" style={{ color: '#ef4444', borderColor: 'rgba(239, 68, 68, 0.3)', backgroundColor: 'rgba(239, 68, 68, 0.1)' }}>
              <AlertTriangle size={17} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: derivedKPIs.lowStock.value > 0 ? '#ef4444' : 'inherit' }}>
            {derivedKPIs.lowStock.formatted}
          </div>
          <div className="kpi-trend negative">
            <span>{derivedKPIs.lowStock.subtext}</span>
          </div>
        </div>

        {/* 7. Outstanding Payments */}
        <div className="kpi-card" onClick={() => onNavigateTab('payments')} style={{ cursor: 'pointer', borderTop: '2px solid #f59e0b' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Outstanding Payments</span>
            <div className="kpi-icon-pill" style={{ color: '#f59e0b', borderColor: 'rgba(245, 158, 11, 0.3)', backgroundColor: 'rgba(245, 158, 11, 0.1)' }}>
              <WalletCards size={17} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#f59e0b' }}>{derivedKPIs.outstandingPayments.formatted}</div>
          <div className="kpi-trend negative">
            <span>{derivedKPIs.outstandingPayments.trend}</span>
          </div>
        </div>

        {/* 8. Orders */}
        <div className="kpi-card" onClick={() => onNavigateTab('sales')} style={{ cursor: 'pointer', borderTop: '2px solid #3b82f6' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Total Orders</span>
            <div className="kpi-icon-pill" style={{ color: '#3b82f6', borderColor: 'rgba(59, 130, 246, 0.3)', backgroundColor: 'rgba(59, 130, 246, 0.1)' }}>
              <ClipboardList size={17} />
            </div>
          </div>
          <div className="kpi-value">{derivedKPIs.orders.formatted}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>{derivedKPIs.orders.trend}</span>
          </div>
        </div>
      </div>

      {/* ====================================================================
          SECTION 2: SALES TREND (CHART) WITH CYBER GRADIENTS
          ==================================================================== */}
      <section className="dashboard-card">
        <div className="card-title-bar">
          <div>
            <h2 className="card-heading">Sales Trend & Revenue Curve</h2>
            <p className="card-subheading">Historical revenue and net profit performance across recent billing cycles (in ₹ INR)</p>
          </div>

          <div style={{ display: 'flex', gap: '16px', fontSize: '12.5px', color: 'var(--text-muted)' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
              <span style={{ width: '12px', height: '12px', background: 'linear-gradient(135deg, #00f0ff, #0284c7)', borderRadius: '3px', boxShadow: '0 0 8px rgba(0, 229, 255, 0.5)' }}></span>
              <strong style={{ color: 'var(--text-primary)' }}>Gross Revenue</strong>
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
              <span style={{ width: '12px', height: '12px', background: 'linear-gradient(135deg, #34d399, #10b981)', borderRadius: '3px', boxShadow: '0 0 8px rgba(16, 185, 129, 0.5)' }}></span>
              <strong style={{ color: 'var(--text-primary)' }}>Net Profit</strong>
            </span>
          </div>
        </div>

        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={salesTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="cyberRevenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00f0ff" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity={0.35} />
                </linearGradient>
                <linearGradient id="cyberProfitGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34d399" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.3} />
                </linearGradient>
              </defs>
              <XAxis dataKey="period" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `₹${Math.round(v / 100000)}L`} />
              <Tooltip 
                formatter={(val) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Amount']}
                contentStyle={{ 
                  backgroundColor: 'var(--bg-card)', 
                  borderColor: 'rgba(255, 255, 255, 0.15)', 
                  borderRadius: '10px', 
                  fontSize: '12px',
                  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4)',
                  backdropFilter: 'blur(16px)'
                }}
              />
              <Bar dataKey="revenue" fill="url(#cyberRevenueGrad)" radius={[5, 5, 0, 0]} />
              <Bar dataKey="profit" fill="url(#cyberProfitGrad)" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ====================================================================
          SECTION 3 & 4: TOP PRODUCTS + LOW STOCK PRODUCTS (2-COLUMN GRID)
          ==================================================================== */}
      <div className="dashboard-content-split">
        {/* SECTION 3: TOP PRODUCTS */}
        <section className="dashboard-card">
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading">Top Products</h2>
              <p className="card-subheading">Highest grossing inventory items this cycle</p>
            </div>
            <button className="btn-secondary" onClick={() => onNavigateTab('sales')} style={{ fontSize: '12px', padding: '4px 10px' }}>
              View All
            </button>
          </div>

          <div className="modern-table-container">
            <table className="modern-table">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Units Sold</th>
                  <th>Revenue</th>
                  <th>Customer</th>
                </tr>
              </thead>
              <tbody>
                {sales.slice(0, 5).map((sale, idx) => (
                  <tr key={idx}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{sale.product}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{sale.category || 'General'}</div>
                    </td>
                    <td><strong>{sale.quantity}</strong></td>
                    <td style={{ fontWeight: 600 }}>₹{Number(sale.revenue || (sale.quantity * sale.sellingPrice)).toLocaleString('en-IN')}</td>
                    <td>
                      <span className="badge badge-info">{sale.customer}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* SECTION 4: LOW STOCK PRODUCTS */}
        <section className="dashboard-card">
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <AlertTriangle size={16} color="#ef4444" />
                <span>Low Stock Products</span>
              </h2>
              <p className="card-subheading">Items below designated safety buffer</p>
            </div>
            <button className="btn-secondary" onClick={() => onNavigateTab('inventory')} style={{ fontSize: '12px', padding: '4px 10px' }}>
              Manage Stock
            </button>
          </div>

          <div className="modern-table-container">
            <table className="modern-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Stock / Min</th>
                  <th>Supplier</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {lowStockItems.slice(0, 5).map((item, idx) => (
                  <tr key={idx}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{item.product}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>SKU: {item.sku || 'N/A'}</div>
                    </td>
                    <td>
                      <span style={{ fontWeight: 700, color: '#ef4444' }}>{item.currentStock} pcs</span>
                      <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}> / {item.reorderLevel || 10}</span>
                    </td>
                    <td>
                      <div>{item.supplier || 'Primary Distributor'}</div>
                    </td>
                    <td>
                      <span className="badge badge-danger">Reorder</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {/* ====================================================================
          SECTION 5 & 6: RECENT ACTIVITY + AI INSIGHTS
          ==================================================================== */}
      <div className="dashboard-content-split">
        {/* SECTION 5: RECENT ACTIVITY */}
        <section className="dashboard-card">
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading">Recent Activity</h2>
              <p className="card-subheading">Latest transactions and billing updates</p>
            </div>
            <button className="btn-secondary" onClick={() => onNavigateTab('sales')} style={{ fontSize: '12px', padding: '4px 10px' }}>
              All Activity
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {sales.slice(0, 5).map((act, idx) => (
              <div 
                key={idx} 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'space-between',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  backgroundColor: 'var(--bg-card-subtle)',
                  border: '1px solid var(--border-color)'
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '13.5px', fontWeight: 700, color: 'var(--text-primary)' }}>{act.customer}</span>
                    <span className="badge badge-info" style={{ fontSize: '10.5px' }}>{act.product}</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginTop: '2px' }}>
                    Invoice: {act.invoiceId || `#INV-${idx + 101}`} • Date: {act.date}
                  </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '14.5px', fontWeight: 800, color: 'var(--text-primary)' }}>
                    ₹{Number(act.revenue || (act.quantity * act.sellingPrice)).toLocaleString('en-IN')}
                  </div>
                  <span className="badge badge-success" style={{ fontSize: '10.5px' }}>
                    Paid
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 6: AI INSIGHTS */}
        <section className="dashboard-card" style={{ borderColor: 'rgba(0, 229, 255, 0.3)', background: 'linear-gradient(180deg, rgba(0, 229, 255, 0.03) 0%, transparent 100%)' }}>
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Sparkles size={16} color="var(--brand-saffron)" />
                <span>AI Insights</span>
              </h2>
              <p className="card-subheading">Data-driven business recommendations</p>
            </div>
            <button className="btn-primary" onClick={() => onNavigateTab('ai-advisor')} style={{ fontSize: '12px', padding: '4px 10px' }}>
              Open Advisor
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {aiInsights.map((insight) => (
              <div 
                key={insight.id} 
                style={{ 
                  padding: '12px 14px', 
                  borderRadius: '10px', 
                  border: '1px solid var(--border-color)',
                  backgroundColor: 'var(--bg-card)' 
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span className="badge badge-warning" style={{ fontSize: '11px' }}>{insight.tag}</span>
                  <button 
                    className="action-pill-btn"
                    style={{ fontSize: '11.5px', padding: '3px 8px' }}
                    onClick={() => onNavigateTab(insight.tag.includes('Inventory') ? 'inventory' : insight.tag.includes('Khata') ? 'payments' : 'ai-advisor')}
                  >
                    <span>{insight.actionText}</span>
                    <ChevronRight size={12} />
                  </button>
                </div>
                <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {insight.title}
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px', lineHeight: '1.4' }}>
                  {insight.detail}
                </div>
                <div style={{ fontSize: '11.5px', color: 'var(--brand-saffron)', marginTop: '6px', fontWeight: 600 }}>
                  💡 Sujhav: {insight.recommendation}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
