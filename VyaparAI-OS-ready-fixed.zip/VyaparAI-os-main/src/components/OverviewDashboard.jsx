import React, { useState } from 'react';
import { 
  IndianRupee, 
  TrendingUp, 
  AlertCircle, 
  Package, 
  Users, 
  ArrowUpRight, 
  Sparkles,
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
} from 'recharts';

export const OverviewDashboard = ({ 
  business, 
  onNavigateToAdvisor, 
  onNavigateToKhata,
  onNavigateToInventory,
  _onOpenWhatsApp 
}) => {
  const [activeSubTab, setActiveSubTab] = useState('overview');

  // Compute live metrics
  const totalRevenue = business.transactions.reduce((sum, t) => sum + t.total, 0);
  const totalProfit = business.transactions.reduce((sum, t) => sum + (t.profit || 0), 0);
  const grossMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
  const totalPendingUdhar = business.customers.reduce((sum, c) => sum + c.pendingAmount, 0);
  const criticalDebtorsCount = business.customers.filter(c => c.overdueDays >= 30).length;
  const lowStockCount = business.inventory.filter(i => i.stock <= i.minStock).length;
  const totalInventoryValue = business.inventory.reduce((sum, i) => sum + (i.stock * i.costPrice), 0);

  // Compute payment mode distribution
  const paymentModes = business.transactions.reduce((acc, t) => {
    const mode = t.paymentMode || 'Other';
    acc[mode] = (acc[mode] || 0) + t.total;
    return acc;
  }, {});

  const pieData = Object.entries(paymentModes).map(([name, value]) => ({ name, value }));
  const PIE_COLORS = ['#00e5ff', '#10b981', '#38bdf8', '#8b5cf6', '#06b6d4'];

  return (
    <div className="page-container">
      {/* Page Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Real-time overview of financial performance, stock levels, and receivables.</p>
        </div>

        {/* Sub-tabs like the shadcn image */}
        <div className="tabs-navigation-bar">
          <button 
            className={`tab-nav-btn ${activeSubTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveSubTab('overview')}
          >
            Overview
          </button>
          <button 
            className={`tab-nav-btn ${activeSubTab === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveSubTab('analytics')}
          >
            Analytics
          </button>
          <button 
            className={`tab-nav-btn ${activeSubTab === 'alerts' ? 'active' : ''}`}
            onClick={() => setActiveSubTab('alerts')}
          >
            AI Alerts ({lowStockCount + criticalDebtorsCount})
          </button>
        </div>
      </div>

      {/* AI Proactive Banner */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(0, 229, 255, 0.08) 0%, rgba(2, 132, 199, 0.03) 100%)',
        border: '1px solid rgba(0, 229, 255, 0.25)',
        borderRadius: '12px',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            width: '38px',
            height: '38px',
            borderRadius: '9px',
            backgroundColor: 'var(--brand-saffron)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Sparkles size={20} />
          </div>
          <div>
            <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>
              AI Business Alert: {lowStockCount} fast-selling SKUs require restocking before weekend rush
            </div>
            <div style={{ fontSize: '12.5px', color: 'var(--text-muted)' }}>
              Total uncollected Khata is ₹{totalPendingUdhar.toLocaleString('en-IN')}, with {criticalDebtorsCount} parties overdue by &gt;30 days.
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          <button className="btn-primary" onClick={onNavigateToAdvisor} style={{ padding: '7px 14px', fontSize: '12.5px' }}>
            <Sparkles size={14} />
            <span>Open AI Advisor</span>
          </button>
        </div>
      </div>

      {/* 4 Top KPI Cards Matching Shadcn Reference */}
      <div className="kpi-grid">
        {/* KPI 1: Total Revenue */}
        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Total Revenue</span>
            <div className="kpi-icon-pill">
              <IndianRupee size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(totalRevenue)}</div>
          <div className="kpi-trend positive">
            <ArrowUpRight size={14} />
            <span>+20.1% from last month</span>
          </div>
        </div>

        {/* KPI 2: Gross Profit & Margin */}
        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Gross Profit (Margin)</span>
            <div className="kpi-icon-pill">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(totalProfit)}</div>
          <div className="kpi-trend positive">
            <span style={{ fontWeight: 700 }}>{grossMargin.toFixed(1)}%</span>
            <span>overall gross margin</span>
          </div>
        </div>

        {/* KPI 3: Pending Udhar (Receivables) */}
        <div className="kpi-card" onClick={onNavigateToKhata} style={{ cursor: 'pointer' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Pending Udhar / Khata</span>
            <div className="kpi-icon-pill">
              <Users size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: '#ef4444' }}>{formatINR(totalPendingUdhar)}</div>
          <div className="kpi-trend negative">
            <AlertCircle size={14} />
            <span>{criticalDebtorsCount} accounts overdue &gt;30 days</span>
          </div>
        </div>

        {/* KPI 4: Inventory & Stock Value */}
        <div className="kpi-card" onClick={onNavigateToInventory} style={{ cursor: 'pointer' }}>
          <div className="kpi-card-header">
            <span className="kpi-title">Active Stock Value</span>
            <div className="kpi-icon-pill">
              <Package size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(totalInventoryValue)}</div>
          <div className="kpi-trend" style={{ color: lowStockCount > 0 ? '#f59e0b' : 'var(--brand-green)' }}>
            <Package size={14} />
            <span>{lowStockCount > 0 ? `${lowStockCount} items low stock` : 'Healthy stock levels'}</span>
          </div>
        </div>
      </div>

      {/* Split Grid: Bar Chart Overview + Recent Sales */}
      <div className="dashboard-content-split">
        {/* Left Column: Revenue & Profit Bar Chart */}
        <div className="dashboard-card">
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading">Revenue & Profit Overview</h2>
              <p className="card-subheading">Monthly trajectory of sales vs. net profit (in ₹ INR)</p>
            </div>
            <div style={{ display: 'flex', gap: '12px', fontSize: '12px', color: 'var(--text-muted)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <span style={{ width: '10px', height: '10px', backgroundColor: 'var(--accent-primary)', borderRadius: '2px' }}></span>
                Revenue
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <span style={{ width: '10px', height: '10px', backgroundColor: 'var(--brand-green)', borderRadius: '2px' }}></span>
                Profit
              </span>
            </div>
          </div>

          <div style={{ width: '100%', height: 320 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={business.monthlyTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `₹${val / 1000}k`} />
                <Tooltip 
                  formatter={(val) => formatINR(val)} 
                  contentStyle={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', borderRadius: '8px', color: 'var(--text-primary)', fontSize: '12px' }}
                />
                <Bar dataKey="revenue" fill="var(--accent-primary)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="profit" fill="var(--brand-green)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Payment Split Preview */}
          <div style={{ marginTop: '20px', paddingTop: '18px', borderTop: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
            <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-secondary)' }}>
              Payment Mode Breakdown:
            </div>
            <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
              {pieData.map((item, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12.5px' }}>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }}></span>
                  <span style={{ color: 'var(--text-muted)' }}>{item.name}:</span>
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{formatINR(item.value, { compact: true })}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Recent Sales & Transactions (Like reference image) */}
        <div className="dashboard-card" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-title-bar">
            <div>
              <h2 className="card-heading">Recent Transactions</h2>
              <p className="card-subheading">You made {business.transactions.length} sales this cycle.</p>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', flex: 1, overflowY: 'auto' }}>
            {business.transactions.slice(0, 6).map((txn) => {
              const initials = txn.customer.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
              const isUdhar = txn.paymentMode.includes('Udhar') || txn.paymentMode.includes('Credit');

              return (
                <div key={txn.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 0' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      backgroundColor: 'var(--bg-card-subtle)',
                      border: '1px solid var(--border-color)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '12px',
                      fontWeight: 700,
                      color: 'var(--text-primary)'
                    }}>
                      {initials}
                    </div>
                    <div>
                      <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-primary)' }}>
                        {txn.customer}
                      </div>
                      <div style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>
                        {txn.item} • {txn.qty} pcs • {formatDate(txn.date)}
                      </div>
                    </div>
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)' }}>
                      +{formatINR(txn.total)}
                    </div>
                    <span className={`badge ${isUdhar ? 'badge-danger' : 'badge-success'}`} style={{ fontSize: '10.5px' }}>
                      {txn.paymentMode}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Action */}
          <div style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
            <button 
              className="btn-secondary" 
              style={{ width: '100%', justifyContent: 'center', fontSize: '12.5px' }}
              onClick={onNavigateToKhata}
            >
              <span>View All Customer Ledgers</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
