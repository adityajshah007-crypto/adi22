import React, { useState } from 'react';
import { 
  Package, 
  AlertTriangle, 
  Search, 
  FileText, 
  Clock
} from 'lucide-react';
import { formatINR } from '../utils/formatters';

export const InventoryView = ({ business, onGeneratePO }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all'); // all, low, dead, fast

  const lowStockItems = business.inventory.filter(i => i.stock <= i.minStock);
  const deadStockItems = business.inventory.filter(i => 
    i.salesVelocity.toLowerCase().includes('dead') || i.salesVelocity.toLowerCase().includes('slow')
  );

  const filteredItems = business.inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.supplier.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;

    if (filterType === 'low') return item.stock <= item.minStock;
    if (filterType === 'dead') return item.salesVelocity.toLowerCase().includes('dead') || item.salesVelocity.toLowerCase().includes('slow');
    if (filterType === 'fast') return item.salesVelocity.toLowerCase().includes('high');
    return true;
  });

  const totalInventoryValue = business.inventory.reduce((sum, i) => sum + (i.stock * i.costPrice), 0);
  const reorderUrgentValue = lowStockItems.reduce((sum, i) => sum + (Math.max(i.minStock * 2 - i.stock, 5) * i.costPrice), 0);

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Inventory & Stock Management</h1>
          <p className="page-subtitle">Track stock velocity, safety buffers, dead inventory, and generate purchase orders.</p>
        </div>

        <div className="page-actions-group">
          <button 
            className="btn-primary"
            onClick={() => onGeneratePO(lowStockItems)}
          >
            <FileText size={15} />
            <span>Generate Reorder PO ({lowStockItems.length})</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Total Active SKUs</span>
            <div className="kpi-icon-pill">
              <Package size={16} />
            </div>
          </div>
          <div className="kpi-value">{business.inventory.length} Items</div>
          <div className="kpi-trend positive">Across {new Set(business.inventory.map(i => i.category)).size} categories</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Total Stock Valuation</span>
            <div className="kpi-icon-pill">
              <Package size={16} />
            </div>
          </div>
          <div className="kpi-value">{formatINR(totalInventoryValue)}</div>
          <div className="kpi-trend neutral">At wholesale cost price</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Low Stock Warnings</span>
            <div className="kpi-icon-pill" style={{ color: '#ef4444' }}>
              <AlertTriangle size={16} />
            </div>
          </div>
          <div className="kpi-value" style={{ color: lowStockItems.length > 0 ? '#ef4444' : 'inherit' }}>
            {lowStockItems.length} Products
          </div>
          <div className="kpi-trend negative">Requires approx. {formatINR(reorderUrgentValue)} to restock</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-card-header">
            <span className="kpi-title">Dead / Slow Stock</span>
            <div className="kpi-icon-pill">
              <Clock size={16} />
            </div>
          </div>
          <div className="kpi-value">{deadStockItems.length} Products</div>
          <div className="kpi-trend neutral">No movement in &gt;60 days</div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="dashboard-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '14px', marginBottom: '16px' }}>
          <div className="tabs-navigation-bar">
            <button 
              className={`tab-nav-btn ${filterType === 'all' ? 'active' : ''}`}
              onClick={() => setFilterType('all')}
            >
              All Items ({business.inventory.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterType === 'low' ? 'active' : ''}`}
              onClick={() => setFilterType('low')}
            >
              Low Stock Alerts ({lowStockItems.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterType === 'dead' ? 'active' : ''}`}
              onClick={() => setFilterType('dead')}
            >
              Dead Stock ({deadStockItems.length})
            </button>
            <button 
              className={`tab-nav-btn ${filterType === 'fast' ? 'active' : ''}`}
              onClick={() => setFilterType('fast')}
            >
              Fast Moving
            </button>
          </div>

          <div style={{ position: 'relative', width: '260px' }}>
            <Search size={15} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }} />
            <input 
              type="text"
              placeholder="Search product or supplier..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="ai-input"
              style={{ paddingLeft: '32px', fontSize: '13px' }}
            />
          </div>
        </div>

        {/* Table */}
        <div className="modern-table-container">
          <table className="modern-table">
            <thead>
              <tr>
                <th>Item & SKU</th>
                <th>Category</th>
                <th>In Stock / Safety</th>
                <th>Cost Price</th>
                <th>Selling Price</th>
                <th>Profit Margin</th>
                <th>Supplier & Lead Time</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item) => {
                const isLow = item.stock <= item.minStock;
                const margin = ((item.sellingPrice - item.costPrice) / item.sellingPrice) * 100;

                return (
                  <tr key={item.id}>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{item.name}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{item.id}</div>
                    </td>
                    <td>
                      <span className="badge badge-info">{item.category}</span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ fontWeight: 700, color: isLow ? '#ef4444' : 'var(--text-primary)' }}>
                          {item.stock} pcs
                        </span>
                        <span style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>
                          (min: {item.minStock})
                        </span>
                      </div>
                    </td>
                    <td>{formatINR(item.costPrice)}</td>
                    <td style={{ fontWeight: 600 }}>{formatINR(item.sellingPrice)}</td>
                    <td>
                      <span className="badge badge-success">
                        {margin.toFixed(1)}%
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '13px', color: 'var(--text-primary)' }}>{item.supplier}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{item.leadTimeDays} days transit</div>
                    </td>
                    <td>
                      {isLow ? (
                        <span className="badge badge-danger">Reorder Alert</span>
                      ) : item.salesVelocity.toLowerCase().includes('dead') ? (
                        <span className="badge badge-warning">Dead Stock</span>
                      ) : (
                        <span className="badge badge-success">Healthy</span>
                      )}
                    </td>
                    <td>
                      <button 
                        className="btn-secondary" 
                        style={{ padding: '4px 10px', fontSize: '12px' }}
                        onClick={() => onGeneratePO([item])}
                      >
                        Reorder
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
