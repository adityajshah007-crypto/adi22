// ==========================================================================
// VYAPARAI OS — AUTHENTICATION CONTEXT
// Manages Business Owner Sessions, JWT Tokens & Business Tenant Scope
// ==========================================================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import { loginUser, registerUser, fetchCurrentUser } from '../services/apiClient';

const AuthContext = createContext(null);

const STORAGE_KEYS = {
  TOKEN: 'vyapar_auth_token',
  USER: 'vyapar_auth_user',
  BUSINESS: 'vyapar_auth_business'
};

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(() => localStorage.getItem(STORAGE_KEYS.TOKEN) || null);
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    return saved ? JSON.parse(saved) : null;
  });
  const [business, setBusiness] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BUSINESS);
    return saved ? JSON.parse(saved) : null;
  });
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  // Validate or refresh session on mount
  useEffect(() => {
    const verifySession = async () => {
      const savedToken = localStorage.getItem(STORAGE_KEYS.TOKEN);
      if (savedToken) {
        try {
          const profile = await fetchCurrentUser();
          if (profile && profile.user && profile.business) {
            setUser(profile.user);
            setBusiness(profile.business);
            localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile.user));
            localStorage.setItem(STORAGE_KEYS.BUSINESS, JSON.stringify(profile.business));
          }
        } catch (err) {
          console.warn('Session sync note:', err.message);
          // If the token is definitively invalid, we can clear it
          if (err.message.includes('401') || err.message.includes('expired')) {
            setToken(null);
            setUser(null);
            setBusiness(null);
            localStorage.removeItem(STORAGE_KEYS.TOKEN);
            localStorage.removeItem(STORAGE_KEYS.USER);
            localStorage.removeItem(STORAGE_KEYS.BUSINESS);
          }
        }
      }
      setIsLoading(false);
    };

    verifySession();
  }, []);

  const saveAuthSession = (authToken, authUser, authBusiness) => {
    setToken(authToken);
    setUser(authUser);
    setBusiness(authBusiness);
    setAuthError(null);

    localStorage.setItem(STORAGE_KEYS.TOKEN, authToken);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(authUser));
    localStorage.setItem(STORAGE_KEYS.BUSINESS, JSON.stringify(authBusiness));
  };

  const DEMO_USER = {
    id: "USER-DEMO-001",
    full_name: "Rajesh Sharma",
    email: "rajesh@bharat.com",
    role: "owner",
    business_id: "BIZ-BHARAT-001",
    is_active: true
  };

  const DEMO_BUSINESS = {
    id: "BIZ-BHARAT-001",
    name: "Bharat Enterprises & Retail",
    owner: "Rajesh Sharma",
    business_type: "Supermart & Wholesale FMCG",
    type: "Supermart & Wholesale FMCG",
    location: "Chandni Chowk, Delhi",
    gstin: "07AAAAA0000A1Z5",
    upi_id: "bharatenterprises@upi",
    currency: "INR"
  };

  const login = async (email, password) => {
    setIsLoading(true);
    setAuthError(null);
    try {
      const data = await loginUser(email, password);
      saveAuthSession(data.access_token, data.user, data.business);
      return data;
    } catch (err) {
      // If user is trying demo credentials and backend is unreachable, activate demo session
      if (email.toLowerCase().trim() === 'rajesh@bharat.com' && password === 'admin123') {
        console.info('Backend unreachable, logging in with local demo fallback.');
        const fallbackToken = 'demo-jwt-bharat-enterprises';
        saveAuthSession(fallbackToken, DEMO_USER, DEMO_BUSINESS);
        return { access_token: fallbackToken, user: DEMO_USER, business: DEMO_BUSINESS };
      }
      setAuthError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (registrationData) => {
    setIsLoading(true);
    setAuthError(null);
    try {
      const data = await registerUser(registrationData);
      saveAuthSession(data.access_token, data.user, data.business);
      return data;
    } catch (err) {
      setAuthError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    setBusiness(null);
    setAuthError(null);
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.BUSINESS);
  };

  const loginWithDemo = async () => {
    setIsLoading(true);
    setAuthError(null);
    try {
      return await login('rajesh@bharat.com', 'admin123');
    } catch (err) {
      console.warn('Demo login direct note:', err.message);
      const fallbackToken = 'demo-jwt-bharat-enterprises';
      saveAuthSession(fallbackToken, DEMO_USER, DEMO_BUSINESS);
      return { access_token: fallbackToken, user: DEMO_USER, business: DEMO_BUSINESS };
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      token,
      user,
      business,
      isAuthenticated: Boolean(token && user),
      isLoading,
      authError,
      setAuthError,
      login,
      register,
      logout,
      loginWithDemo
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
