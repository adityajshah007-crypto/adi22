// ==========================================================================
// VYAPARAI OS — CENTRAL DATA STORE & NORMALIZED PERSISTENCE
// Powers Command Center, Sales, Inventory, Customers, and Payments
// Prepared for seamless PostgreSQL backend synchronization
// ==========================================================================

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { DATASET_TYPES } from '../data/schemas';
import { 
  mockBusinessProfile, 
  mockKPIs, 
  mockSalesTrend, 
  mockAIInsights 
} from '../data/mockData';
import { useAuth } from './AuthContext';

const DataStoreContext = createContext(null);

const STORAGE_KEYS = {
  SALES: 'vyapar_sales_data',
  INVENTORY: 'vyapar_inventory_data',
  CUSTOMERS: 'vyapar_customers_data',
  PROFILE: 'vyapar_business_profile'
};

export const DataStoreProvider = ({ children }) => {
  const auth = useAuth();
  const authBusiness = auth?.business;

  // 1. Business Profile State
  const [businessProfile, setBusinessProfile] = useState(() => {
    if (authBusiness) {
      return {
        ...mockBusinessProfile,
        ...authBusiness,
        type: authBusiness.business_type || authBusiness.type || mockBusinessProfile.type,
        upiId: authBusiness.upi_id || authBusiness.upiId || mockBusinessProfile.upiId
      };
    }
    const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return saved ? JSON.parse(saved) : mockBusinessProfile;
  });

  // Sync when authenticated business changes
  useEffect(() => {
    if (authBusiness) {
      setBusinessProfile(prev => ({
        ...prev,
        ...authBusiness,
        type: authBusiness.business_type || authBusiness.type || prev.type,
        upiId: authBusiness.upi_id || authBusiness.upiId || prev.upiId
      }));
    }
  }, [authBusiness]);

  // 2. Normalized Relational State
  const [sales, setSales] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SALES);
    if (saved) return JSON.parse(saved);
    // Seed initial mock sales
    return [
      { date: '2026-09-08', invoiceId: 'INV-108', product: 'Fortune Sunlite Sunflower Oil (5L)', category: 'Edible Oils', quantity: 6, sellingPrice: 650, revenue: 3900, cost: 3360, profit: 540, customer: 'Sharmaji Caterers' },
      { date: '2026-09-08', invoiceId: 'INV-107', product: 'India Gate Basmati Rice (10kg)', category: 'Grains & Staples', quantity: 4, sellingPrice: 1150, revenue: 4600, cost: 3680, profit: 920, customer: 'Deepak Sweet House' },
      { date: '2026-09-07', invoiceId: 'INV-106', product: 'Aashirvaad Shudh Chakki Atta (10kg)', category: 'Grains & Staples', quantity: 8, sellingPrice: 485, revenue: 3880, cost: 3280, profit: 600, customer: 'Verma PG Mess' },
      { date: '2026-09-07', invoiceId: 'INV-105', product: 'Tata Salt Vacuum Evaporated (1kg)', category: 'Spices & Essentials', quantity: 20, sellingPrice: 28, revenue: 560, cost: 420, profit: 140, customer: 'Aggarwal Bakers' },
      { date: '2026-09-06', invoiceId: 'INV-104', product: 'Amul Butter Salted (500g)', category: 'Dairy & Cold', quantity: 5, sellingPrice: 285, revenue: 1425, cost: 1225, profit: 200, customer: 'Gupta Store' }
    ];
  });

  const [inventory, setInventory] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVENTORY);
    if (saved) return JSON.parse(saved);
    // Seed initial mock inventory
    return [
      { product: 'Fortune Sunlite Sunflower Oil (5L)', sku: 'SKU-102', category: 'Edible Oils', currentStock: 8, costPrice: 560, sellingPrice: 650, supplier: 'Adani Wilmar Agency', reorderLevel: 25 },
      { product: 'India Gate Basmati Rice (10kg)', sku: 'SKU-101', category: 'Grains & Staples', currentStock: 14, costPrice: 920, sellingPrice: 1150, supplier: 'KRBL Mandi Dist', reorderLevel: 30 },
      { product: 'Aashirvaad Shudh Chakki Atta (10kg)', sku: 'SKU-104', category: 'Grains & Staples', currentStock: 12, costPrice: 410, sellingPrice: 485, supplier: 'ITC Hub Delhi', reorderLevel: 30 },
      { product: 'Amul Butter Salted (500g)', sku: 'SKU-105', category: 'Dairy & Cold', currentStock: 5, costPrice: 245, sellingPrice: 285, supplier: 'Delhi Milk Union', reorderLevel: 15 },
      { product: 'Tata Salt Vacuum Evaporated (1kg)', sku: 'SKU-103', category: 'Spices & Essentials', currentStock: 65, costPrice: 21, sellingPrice: 28, supplier: 'Tata Consumer Local', reorderLevel: 30 }
    ];
  });

  const [customers, setCustomers] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (saved) return JSON.parse(saved);
    // Seed initial mock customers
    return [
      { customerName: 'Sharmaji Caterers', phone: '+91 98112 34567', email: 'sharma@caterers.in', totalPurchases: 485000, amountPaid: 460500, amountDue: 24500, dueDate: '2026-09-15' },
      { customerName: 'Aggarwal Sweets & Dairy', phone: '+91 99104 88712', email: 'aggarwal@sweets.com', totalPurchases: 610000, amountPaid: 571800, amountDue: 38200, dueDate: '2026-09-10' },
      { customerName: 'Deepak Sweet House', phone: '+91 98731 22890', email: 'deepak@sweethouse.in', totalPurchases: 340000, amountPaid: 325200, amountDue: 14800, dueDate: '2026-09-22' },
      { customerName: 'Verma PG Mess', phone: '+91 93120 77419', email: 'vermapg@outlook.com', totalPurchases: 195000, amountPaid: 186100, amountDue: 8900, dueDate: '2026-09-18' },
      { customerName: 'Gupta Kirana Store', phone: '+91 98211 44520', email: 'guptastore@gmail.com', totalPurchases: 260000, amountPaid: 254400, amountDue: 5600, dueDate: '2026-09-25' }
    ];
  });

  // Persist whenever state changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(businessProfile));
  }, [businessProfile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  // Import Handler that ingests validated normalized rows
  const importDataset = (datasetType, normalizedRows, options = {}) => {
    const { overwrite = false } = options;

    if (datasetType === DATASET_TYPES.SALES) {
      setSales(prev => (overwrite ? normalizedRows : [...normalizedRows, ...prev]));
    } else if (datasetType === DATASET_TYPES.INVENTORY) {
      setInventory(prev => {
        if (overwrite) return normalizedRows;
        // Merge or append by SKU/Product
        const existingKeys = new Set(prev.map(i => (i.sku || i.product).toLowerCase()));
        const newItems = normalizedRows.filter(i => !existingKeys.has((i.sku || i.product).toLowerCase()));
        return [...newItems, ...prev];
      });
    } else if (datasetType === DATASET_TYPES.CUSTOMERS) {
      setCustomers(prev => (overwrite ? normalizedRows : [...normalizedRows, ...prev]));
    }
  };

  // Efficiently derive Command Center Dynamic KPIs from live data with useMemo
  const derivedKPIs = useMemo(() => {
    const totalRev = sales.reduce((sum, s) => sum + (Number(s.revenue) || 0), 0) || mockKPIs.revenue.value;
    const totalProf = sales.reduce((sum, s) => sum + (Number(s.profit) || 0), 0) || mockKPIs.profit.value;
    const totalQty = sales.reduce((sum, s) => sum + (Number(s.quantity) || 0), 0) || mockKPIs.sales.value;
    const totalStockVal = inventory.reduce((sum, i) => sum + ((Number(i.currentStock) || 0) * (Number(i.costPrice) || 0)), 0) || mockKPIs.inventoryValue.value;
    const lowStockCount = inventory.filter(i => (Number(i.currentStock) || 0) <= (Number(i.reorderLevel) || 10)).length;
    const totalOutstanding = customers.reduce((sum, c) => sum + (Number(c.amountDue) || 0), 0) || mockKPIs.outstandingPayments.value;

    return {
      revenue: {
        value: totalRev,
        formatted: `₹${totalRev.toLocaleString('en-IN')}`,
        trend: 'Live',
        trendPositive: true,
        subtext: 'cumulative revenue'
      },
      profit: {
        value: totalProf,
        formatted: `₹${totalProf.toLocaleString('en-IN')}`,
        trend: 'Live',
        trendPositive: true,
        subtext: 'net earnings'
      },
      profitMargin: {
        value: totalRev > 0 ? ((totalProf / totalRev) * 100).toFixed(1) : mockKPIs.profitMargin.value,
        formatted: totalRev > 0 ? `${((totalProf / totalRev) * 100).toFixed(1)}%` : mockKPIs.profitMargin.formatted,
        trend: 'Live',
        trendPositive: true,
        subtext: 'target: 24.0%'
      },
      sales: {
        value: totalQty,
        formatted: `${totalQty.toLocaleString('en-IN')} units`,
        trend: 'Live',
        trendPositive: true,
        subtext: 'units moved'
      },
      inventoryValue: {
        value: totalStockVal,
        formatted: `₹${totalStockVal.toLocaleString('en-IN')}`,
        trend: 'Healthy',
        trendPositive: true,
        subtext: `${inventory.length} active SKUs`
      },
      lowStock: {
        value: lowStockCount,
        formatted: `${lowStockCount} items`,
        trend: 'Action Required',
        trendPositive: false,
        subtext: 'below safety buffer'
      },
      outstandingPayments: {
        value: totalOutstanding,
        formatted: `₹${totalOutstanding.toLocaleString('en-IN')}`,
        trend: `${customers.filter(c => Number(c.amountDue) > 10000).length} parties >₹10k`,
        trendPositive: false,
        subtext: 'uncollected Udhar'
      },
      orders: {
        value: sales.length || mockKPIs.orders.value,
        formatted: `${sales.length || mockKPIs.orders.value} orders`,
        trend: 'Live',
        trendPositive: true,
        subtext: 'recorded'
      }
    };
  }, [sales, inventory, customers]);

  const lowStockItems = useMemo(() => {
    return inventory.filter(i => (Number(i.currentStock) || 0) <= (Number(i.reorderLevel) || 10));
  }, [inventory]);

  // Record payment against customer's Udhar
  const recordCustomerPayment = (customerIdentifier, amountPaid) => {
    setCustomers(prev => prev.map(c => {
      const match = (c.customerName || c.name || '').toLowerCase() === customerIdentifier.toLowerCase();
      if (!match) return c;
      const currentDue = Number(c.amountDue) || 0;
      const newDue = Math.max(0, currentDue - Number(amountPaid));
      const newPaid = (Number(c.amountPaid) || 0) + Number(amountPaid);
      return { ...c, amountDue: newDue, amountPaid: newPaid };
    }));
  };

  // Adjust stock for inventory item
  const adjustStock = (productIdentifier, quantityDelta) => {
    setInventory(prev => prev.map(item => {
      const match = (item.product || item.name || '').toLowerCase() === productIdentifier.toLowerCase();
      if (!match) return item;
      const current = Number(item.currentStock || item.stock) || 0;
      const updated = Math.max(0, current + Number(quantityDelta));
      return { ...item, currentStock: updated, stock: updated };
    }));
  };

  const contextValue = useMemo(() => ({
    businessProfile,
    setBusinessProfile,
    sales,
    inventory,
    customers,
    importDataset,
    derivedKPIs,
    lowStockItems,
    recordCustomerPayment,
    adjustStock,
    salesTrend: mockSalesTrend,
    aiInsights: mockAIInsights
  }), [businessProfile, sales, inventory, customers, derivedKPIs, lowStockItems]);

  return (
    <DataStoreContext.Provider value={contextValue}>
      {children}
    </DataStoreContext.Provider>
  );
};

export const useDataStore = () => {
  const context = useContext(DataStoreContext);
  if (!context) {
    throw new Error('useDataStore must be used within a DataStoreProvider');
  }
  return context;
};
