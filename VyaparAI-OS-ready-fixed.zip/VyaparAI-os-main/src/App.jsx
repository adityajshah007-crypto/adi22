import React, { useState, useEffect, Suspense, lazy } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataStoreProvider, useDataStore } from './context/DataStore';
import { AuthView } from './views/AuthView';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ImportDataModal } from './components/ImportDataModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { MarketSimulatorModal } from './components/MarketSimulatorModal';
import { WhatsAppModal, PurchaseOrderModal, CommandPaletteModal } from './components/Modals';
import { InvoiceModal } from './components/InvoiceModal';
import { QuickSaleModal } from './components/QuickSaleModal';
import { Toast } from './components/Toast';

// Lazy-loaded Views for High-Performance Code-Splitting & Minimal Initial Bundle Size
const CommandCenter = lazy(() => import('./components/CommandCenter').then(m => ({ default: m.CommandCenter })));
const ImportDataView = lazy(() => import('./views/ImportDataView').then(m => ({ default: m.ImportDataView })));
const AIAdvisorView = lazy(() => import('./views/AIAdvisorView').then(m => ({ default: m.AIAdvisorView })));
const SalesView = lazy(() => import('./views/SalesView').then(m => ({ default: m.SalesView })));
const InventoryView = lazy(() => import('./views/InventoryView').then(m => ({ default: m.InventoryView })));
const CustomersView = lazy(() => import('./views/CustomersView').then(m => ({ default: m.CustomersView })));
const PaymentsView = lazy(() => import('./views/PaymentsView').then(m => ({ default: m.PaymentsView })));
const ForecastsView = lazy(() => import('./views/ForecastsView').then(m => ({ default: m.ForecastsView })));
const ActionsView = lazy(() => import('./views/ActionsView').then(m => ({ default: m.ActionsView })));
const ReportsView = lazy(() => import('./views/ReportsView').then(m => ({ default: m.ReportsView })));
const SettingsView = lazy(() => import('./views/SettingsView').then(m => ({ default: m.SettingsView })));
const PitchDeckView = lazy(() => import('./views/PitchDeckView').then(m => ({ default: m.PitchDeckView })));

function ViewLoadingFallback() {
  return (
    <div className="page-container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '55vh', flexDirection: 'column', gap: '14px' }}>
      <div style={{
        width: '32px',
        height: '32px',
        borderRadius: '50%',
        border: '3px solid var(--border-color)',
        borderTopColor: 'var(--brand-saffron)',
        animation: 'spin 0.7s linear infinite'
      }} />
      <span style={{ fontSize: '13px', color: 'var(--text-muted)', fontWeight: 600 }}>Loading workspace module...</span>
    </div>
  );
}

function MainAppContent({ theme, toggleTheme }) {
  // Main navigation state (defaults to Command Center)
  const [activeTab, setActiveTab] = useState('command-center');

  const { businessProfile, lowStockItems, customers } = useDataStore();

  // Modals state
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [whatsAppCustomer, setWhatsAppCustomer] = useState(null);
  const [poItems, setPoItems] = useState(null);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [marketSimulatorModalOpen, setMarketSimulatorModalOpen] = useState(false);
  const [activeInvoice, setActiveInvoice] = useState(null);
  const [quickSaleModalOpen, setQuickSaleModalOpen] = useState(false);

  // Micro-feedback toast state
  const [toast, setToast] = useState(null);

  // Global keyboard shortcut for Cmd/Ctrl + K
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleOpenImportPage = () => {
    setActiveTab('import-data');
    setMobileMenuOpen(false);
  };

  return (
    <div className="app-container">
      {/* Mobile Sidebar Backdrop Overlay */}
      {mobileMenuOpen && (
        <div 
          className="sidebar-overlay" 
          onClick={() => setMobileMenuOpen(false)}
          aria-label="Close navigation overlay"
        />
      )}

      {/* 1. Sidebar with exact 10 navigation items + prominent Import Data button */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        businessProfile={businessProfile}
        onOpenImportModal={handleOpenImportPage}
        lowStockCount={lowStockItems.length}
        pendingUdharCount={customers.filter(c => Number(c.amountDue) > 0).length}
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
      />

      {/* 2. Main Content Area */}
      <main className="app-main">
        {/* Header */}
        <Header 
          activeTab={activeTab} 
          businessProfile={businessProfile} 
          theme={theme} 
          toggleTheme={toggleTheme}
          onOpenImportModal={handleOpenImportPage}
          onOpenCommandPalette={() => setCommandPaletteOpen(true)}
          onNavigateTab={(tab) => setActiveTab(tab)}
          onOpenSandbox={() => setMarketSimulatorModalOpen(true)}
          onOpenSubscriptionModal={() => setSubscriptionModalOpen(true)}
          onOpenWhatsApp={(cust) => setWhatsAppCustomer(cust)}
          onOpenPOModal={(items) => setPoItems(items)}
          onToggleMobileMenu={() => setMobileMenuOpen(prev => !prev)}
        />

        {/* 3. Dynamic Lazy Navigation Views with Suspense */}
        <Suspense fallback={<ViewLoadingFallback />}>
          {activeTab === 'command-center' && (
            <CommandCenter 
              onNavigateTab={(tab) => setActiveTab(tab)}
              onOpenImportModal={handleOpenImportPage}
            />
          )}

          {activeTab === 'pitch-deck' && (
            <PitchDeckView 
              onNavigateTab={(tab) => setActiveTab(tab)}
              onOpenSandbox={() => setMarketSimulatorModalOpen(true)}
            />
          )}

          {activeTab === 'import-data' && (
            <ImportDataView 
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'ai-advisor' && (
            <AIAdvisorView 
              onOpenWhatsApp={(cust) => setWhatsAppCustomer(cust)}
              onOpenPOModal={(items) => setPoItems(items)}
              onNavigateTab={(tab) => setActiveTab(tab)}
              onShowToast={(t) => setToast(t)}
            />
          )}

          {activeTab === 'sales' && (
            <SalesView 
              onOpenQuickSale={() => setQuickSaleModalOpen(true)}
              onViewInvoice={(sale) => setActiveInvoice(sale)}
            />
          )}

          {activeTab === 'inventory' && (
            <InventoryView 
              onOpenPOModal={(items) => setPoItems(items)}
              onShowToast={(t) => setToast(t)}
            />
          )}

          {activeTab === 'customers' && (
            <CustomersView 
              onOpenWhatsApp={(cust) => setWhatsAppCustomer(cust)}
              onShowToast={(t) => setToast(t)}
            />
          )}

          {activeTab === 'payments' && (
            <PaymentsView 
              onOpenWhatsApp={(cust) => setWhatsAppCustomer(cust)}
              onShowToast={(t) => setToast(t)}
            />
          )}

          {activeTab === 'forecasts' && (
            <ForecastsView />
          )}

          {activeTab === 'actions' && (
            <ActionsView 
              onOpenWhatsApp={(cust) => setWhatsAppCustomer(cust)}
              onOpenPOModal={(items) => setPoItems(items)}
              onShowToast={(t) => setToast(t)}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView />
          )}

          {activeTab === 'settings' && (
            <SettingsView 
              onOpenSubscriptionModal={() => setSubscriptionModalOpen(true)}
              onShowToast={(t) => setToast(t)}
            />
          )}
        </Suspense>
      </main>

      {/* 4. Global Modals */}
      <ImportDataModal 
        isOpen={importModalOpen}
        onClose={() => setImportModalOpen(false)}
        onFileImported={() => {
          setActiveTab('command-center');
          setToast({ message: 'Dataset imported and KPIs refreshed successfully!', type: 'success' });
        }}
      />

      <WhatsAppModal 
        isOpen={Boolean(whatsAppCustomer)} 
        onClose={() => setWhatsAppCustomer(null)}
        customer={whatsAppCustomer}
        business={businessProfile}
      />

      <PurchaseOrderModal 
        isOpen={Boolean(poItems)} 
        onClose={() => setPoItems(null)}
        items={poItems || []}
        business={businessProfile}
        onOrderConfirmed={(msg) => setToast({ message: msg, type: 'success' })}
      />

      <CommandPaletteModal 
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onNavigate={(tab) => setActiveTab(tab)}
        onAskAI={(_q) => setActiveTab('ai-advisor')}
        business={businessProfile}
      />

      <SubscriptionModal 
        isOpen={subscriptionModalOpen}
        onClose={() => setSubscriptionModalOpen(false)}
      />

      <MarketSimulatorModal 
        isOpen={marketSimulatorModalOpen}
        onClose={() => setMarketSimulatorModalOpen(false)}
      />

      {/* New GST Invoice / Cash Memo Modal */}
      <InvoiceModal
        isOpen={Boolean(activeInvoice)}
        onClose={() => setActiveInvoice(null)}
        sale={activeInvoice}
        business={businessProfile}
      />

      {/* New Quick Counter Sale Modal */}
      <QuickSaleModal
        isOpen={quickSaleModalOpen}
        onClose={() => setQuickSaleModalOpen(false)}
        onSaleRecorded={(sale) => {
          setToast({ message: `Recorded invoice for ${sale.customer}: ₹${sale.revenue.toLocaleString('en-IN')}`, type: 'success' });
        }}
      />

      {/* Toast Notification Micro-Feedback */}
      <Toast 
        message={toast?.message}
        type={toast?.type}
        onClose={() => setToast(null)}
      />
    </div>
  );
}

function AppRouter() {
  const [theme, setTheme] = useState('dark');
  const { isAuthenticated, isLoading } = useAuth();

  // Sync theme with body class
  useEffect(() => {
    document.body.className = theme === 'light' ? 'theme-light' : 'theme-dark';
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  if (isLoading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-body)',
        color: 'var(--text-primary)',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          width: '38px',
          height: '38px',
          borderRadius: '50%',
          border: '3px solid var(--border-color)',
          borderTopColor: 'var(--brand-saffron)',
          animation: 'spin 0.8s linear infinite'
        }}></div>
        <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-muted)' }}>
          Loading VyaparAI OS Workspace...
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthView theme={theme} toggleTheme={toggleTheme} />;
  }

  return (
    <DataStoreProvider>
      <MainAppContent theme={theme} toggleTheme={toggleTheme} />
    </DataStoreProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}
