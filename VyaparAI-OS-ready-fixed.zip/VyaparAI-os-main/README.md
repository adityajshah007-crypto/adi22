# VyaparAI OS

AI-powered business operating system for Indian SMBs.

> A digital dashboard that helps small shop owners run their business without spreadsheets — sales, stock, customer credit (khata), and payments in one place, with AI-driven suggestions on top. Think of it as the notebook and ledger a kirana store owner already keeps, digitized and made a lot smarter.

## What it does

- **Sales tracking** — log and review daily sales as they happen
- **Inventory management** — track stock levels and get alerted on what's running low or moving slowly
- **Customer khata (credit ledger)** — keep track of who owes what, and follow up on receivables
- **Payments** — record and reconcile customer payments
- **Bulk data import** — upload an existing Excel/CSV sheet and the app parses, validates, and merges it in, duplicate-safe
- **AI business advisor** — get plain-language suggestions on restocking, collections, and demand trends
- **Forecasting** — see demand estimates for upcoming periods (e.g. festive season surges)

## Tech stack

- **Frontend:** React 19 + Vite, Recharts, Lucide React
- **Backend:** FastAPI + SQLAlchemy 2, JWT authentication, bcrypt password hashing
- **Database:** PostgreSQL in production, with automatic SQLite fallback for local development — no database setup required to run it locally

## Engineering notes

A few things worth calling out beyond "it has the features":

- **Tenant isolation** — API requests are scoped to the authenticated user's business; a user cannot pull another business's data by tampering with request headers.
- **Deterministic IDs** — record IDs are generated with SHA-256 rather than Python's process-random `hash()`, so they're stable and collision-safe across runs.
- **Password security** — user passwords are hashed with bcrypt, not stored or compared in plaintext.
- **Graceful degradation** — the frontend keeps working in a local demo mode even if the backend API is offline, so imports and navigation don't hard-crash.

## Run locally

### 1. Frontend

```bash
npm install
npm run dev
```

Frontend: `http://localhost:5173`

### 2. Backend

Open a second terminal:

```bash
cd backend
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Backend API: `http://localhost:8000/api/v1`
Health check: `http://localhost:8000/health`

The backend automatically falls back to a local SQLite database when PostgreSQL is not available, so you can develop without installing PostgreSQL.

## Demo account

- Email: `rajesh@bharat.com`
- Password: `admin123`

The frontend also has a local demo fallback so the UI remains usable when the API is offline. For production, use a registered account and a real database.

## Environment

Copy `.env.example` to `.env` for the frontend if you need a custom API URL.

Copy `backend/.env.example` to `backend/.env` and **change `SECRET_KEY` before deployment**.

## Production checklist

- Set a strong random `SECRET_KEY`.
- Use PostgreSQL instead of SQLite.
- Put the API behind HTTPS/reverse proxy.
- Restrict `CORS_ORIGINS` to the real frontend domain.
- Do not use the demo credentials in production.
- Run `npm run build` and serve the generated `dist/` directory.
- Keep database credentials and environment files out of source control.

## Build

```bash
npm run lint
npm run build
```
