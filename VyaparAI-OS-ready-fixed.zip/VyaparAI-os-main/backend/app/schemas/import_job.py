from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime

class ImportProcessRequest(BaseModel):
    dataset_type: str = Field(..., description="sales, inventory, or customers")
    file_name: str
    rows: List[Dict[str, Any]]
    overwrite: Optional[bool] = False

class ImportErrorDetail(BaseModel):
    row_number: int
    field_name: str
    error_type: str
    error_message: str
    raw_value: Optional[str] = None

class ImportProcessResponse(BaseModel):
    job_id: str
    business_id: str
    dataset_type: str
    file_name: str
    total_rows: int
    valid_rows: int
    invalid_rows: int
    status: str
    errors: List[ImportErrorDetail] = []
    message: str

class ImportJobOut(BaseModel):
    id: str
    business_id: str
    dataset_type: str
    file_name: str
    total_rows: int
    valid_rows: int
    invalid_rows: int
    status: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
