from pydantic import BaseModel, Field
from typing import Optional
from datetime import date, datetime
from decimal import Decimal

class CustomerBase(BaseModel):
    name: str = Field(..., min_length=1)
    phone: Optional[str] = None
    email: Optional[str] = None
    total_purchases: Optional[Decimal] = Decimal("0.00")
    amount_paid: Optional[Decimal] = Decimal("0.00")
    amount_due: Optional[Decimal] = Decimal("0.00")
    due_date: Optional[date] = None
    trust_score: Optional[str] = "Good"
    notes: Optional[str] = None

class CustomerCreate(CustomerBase):
    pass

class CustomerOut(CustomerBase):
    id: str
    business_id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
