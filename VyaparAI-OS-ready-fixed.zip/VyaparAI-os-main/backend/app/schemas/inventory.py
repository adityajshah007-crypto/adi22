from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from decimal import Decimal

class InventoryBase(BaseModel):
    product_id: str
    current_stock: int = Field(0, ge=0)
    reorder_level: int = Field(10, ge=0)
    cost_price: Decimal = Field(..., ge=0)
    selling_price: Decimal = Field(..., ge=0)
    supplier_name: Optional[str] = "Primary Supplier"
    lead_time_days: Optional[int] = 3

class InventoryCreate(InventoryBase):
    pass

class InventoryOut(InventoryBase):
    id: str
    business_id: str
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
