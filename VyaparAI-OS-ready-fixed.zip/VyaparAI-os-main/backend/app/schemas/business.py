from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class BusinessBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    owner: str = Field(..., min_length=2, max_length=255)
    business_type: Optional[str] = "Retail & Wholesale SMB"
    gstin: Optional[str] = None
    upi_id: Optional[str] = None
    location: Optional[str] = None
    currency: Optional[str] = "INR"

class BusinessCreate(BusinessBase):
    id: Optional[str] = None

class BusinessOut(BusinessBase):
    id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
