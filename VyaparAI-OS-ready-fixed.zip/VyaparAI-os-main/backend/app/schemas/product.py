from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class ProductBase(BaseModel):
    name: str = Field(..., min_length=1)
    sku: Optional[str] = None
    category: Optional[str] = "General"
    description: Optional[str] = None

class ProductCreate(ProductBase):
    pass

class ProductOut(ProductBase):
    id: str
    business_id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
