from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime

class UserBase(BaseModel):
    full_name: str = Field(..., min_length=2)
    email: EmailStr
    role: Optional[str] = "owner"

class UserCreate(UserBase):
    password: str = Field(..., min_length=6)

class UserOut(UserBase):
    id: str
    business_id: str
    is_active: bool
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
