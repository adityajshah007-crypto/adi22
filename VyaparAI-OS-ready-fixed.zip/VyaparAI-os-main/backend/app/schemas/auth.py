from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from app.schemas.user import UserOut
from app.schemas.business import BusinessOut

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1)

class RegisterRequest(BaseModel):
    # User Details
    full_name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=128)
    
    # Business Details
    business_name: str = Field(..., min_length=2, max_length=255)
    business_type: Optional[str] = "Retail & Wholesale SMB"
    gstin: Optional[str] = None
    upi_id: Optional[str] = None
    location: Optional[str] = None
    currency: Optional[str] = "INR"

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut
    business: BusinessOut

class AuthMeResponse(BaseModel):
    user: UserOut
    business: BusinessOut
