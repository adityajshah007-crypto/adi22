from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date, datetime
from decimal import Decimal

class SaleItemBase(BaseModel):
    product_name: str
    product_id: Optional[str] = None
    quantity: int = Field(1, ge=1)
    selling_price: Decimal = Field(..., ge=0)
    cost_price: Optional[Decimal] = Decimal("0.00")
    revenue: Optional[Decimal] = None
    profit: Optional[Decimal] = None

class SaleItemCreate(SaleItemBase):
    pass

class SaleItemOut(SaleItemBase):
    id: str
    sale_id: str

    class Config:
        from_attributes = True

class SaleBase(BaseModel):
    sale_date: date
    invoice_id: Optional[str] = None
    customer_id: Optional[str] = None
    payment_mode: Optional[str] = "UPI"
    payment_status: Optional[str] = "Paid"
    total_amount: Decimal = Field(..., ge=0)
    total_cost: Optional[Decimal] = Decimal("0.00")
    total_profit: Optional[Decimal] = Decimal("0.00")

class SaleCreate(SaleBase):
    items: List[SaleItemCreate] = []

class SaleOut(SaleBase):
    id: str
    business_id: str
    created_at: Optional[datetime] = None
    items: List[SaleItemOut] = []

    class Config:
        from_attributes = True
