from pydantic import BaseModel, Field
from typing import Optional
from datetime import date, datetime
from decimal import Decimal

class PaymentBase(BaseModel):
    customer_id: Optional[str] = None
    sale_id: Optional[str] = None
    amount: Decimal = Field(..., gt=0)
    payment_date: date
    payment_mode: Optional[str] = "UPI"
    reference_number: Optional[str] = None

class PaymentCreate(PaymentBase):
    pass

class PaymentOut(PaymentBase):
    id: str
    business_id: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
