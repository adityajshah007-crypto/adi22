from sqlalchemy import Column, String, Integer, Numeric, Date, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class Sale(Base):
    __tablename__ = "sales"

    id = Column(String(100), primary_key=True, index=True) # e.g. SALE-101
    business_id = Column(String(100), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    customer_id = Column(String(100), ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True)
    invoice_id = Column(String(100), nullable=True, index=True)
    sale_date = Column(Date, nullable=False, index=True)
    total_amount = Column(Numeric(14, 2), nullable=False, default=0.0)
    total_cost = Column(Numeric(14, 2), nullable=False, default=0.0)
    total_profit = Column(Numeric(14, 2), nullable=False, default=0.0)
    payment_mode = Column(String(50), default="UPI") # UPI, Cash, Udhar / Credit, Card
    payment_status = Column(String(50), default="Paid") # Paid, Pending, Partial
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    business = relationship("Business", back_populates="sales")
    customer = relationship("Customer", back_populates="sales")
    items = relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="sale")

class SaleItem(Base):
    __tablename__ = "sale_items"

    id = Column(String(100), primary_key=True, index=True)
    sale_id = Column(String(100), ForeignKey("sales.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(String(100), ForeignKey("products.id", ondelete="SET NULL"), nullable=True, index=True)
    product_name = Column(String(255), nullable=False)
    quantity = Column(Integer, nullable=False, default=1)
    selling_price = Column(Numeric(12, 2), nullable=False, default=0.0)
    cost_price = Column(Numeric(12, 2), nullable=False, default=0.0)
    revenue = Column(Numeric(14, 2), nullable=False, default=0.0)
    profit = Column(Numeric(14, 2), nullable=False, default=0.0)

    # Relationships
    sale = relationship("Sale", back_populates="items")
    product = relationship("Product", back_populates="sale_items")
