from sqlalchemy import Column, String, DateTime, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class Business(Base):
    __tablename__ = "businesses"

    id = Column(String(100), primary_key=True, index=True) # e.g. BIZ-BHARAT-001
    name = Column(String(255), nullable=False)
    owner = Column(String(255), nullable=False)
    business_type = Column(String(100), nullable=True, default="Retail & Wholesale SMB")
    gstin = Column(String(50), nullable=True)
    upi_id = Column(String(100), nullable=True)
    location = Column(String(255), nullable=True)
    currency = Column(String(10), default="INR")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    users = relationship("User", back_populates="business", cascade="all, delete-orphan")
    products = relationship("Product", back_populates="business", cascade="all, delete-orphan")
    sales = relationship("Sale", back_populates="business", cascade="all, delete-orphan")
    inventories = relationship("Inventory", back_populates="business", cascade="all, delete-orphan")
    customers = relationship("Customer", back_populates="business", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="business", cascade="all, delete-orphan")
    imports = relationship("ImportJob", back_populates="business", cascade="all, delete-orphan")
