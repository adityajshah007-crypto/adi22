from sqlalchemy import Column, String, Integer, Numeric, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class Inventory(Base):
    __tablename__ = "inventories"

    id = Column(String(100), primary_key=True, index=True) # e.g. INV-101
    business_id = Column(String(100), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(String(100), ForeignKey("products.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    current_stock = Column(Integer, nullable=False, default=0)
    reorder_level = Column(Integer, nullable=False, default=10)
    cost_price = Column(Numeric(12, 2), nullable=False, default=0.0)
    selling_price = Column(Numeric(12, 2), nullable=False, default=0.0)
    supplier_name = Column(String(255), nullable=True, default="Primary Supplier")
    lead_time_days = Column(Integer, default=3)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    business = relationship("Business", back_populates="inventories")
    product = relationship("Product", back_populates="inventory")
