from sqlalchemy import Column, String, Numeric, DateTime, Date, ForeignKey, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class Payment(Base):
    __tablename__ = "payments"

    id = Column(String(100), primary_key=True, index=True) # e.g. PAY-101
    business_id = Column(String(100), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    customer_id = Column(String(100), ForeignKey("customers.id", ondelete="SET NULL"), nullable=True, index=True)
    sale_id = Column(String(100), ForeignKey("sales.id", ondelete="SET NULL"), nullable=True, index=True)
    amount = Column(Numeric(14, 2), nullable=False)
    payment_date = Column(Date, nullable=False, index=True)
    payment_mode = Column(String(50), default="UPI") # UPI, Cash, Bank Transfer
    reference_number = Column(String(100), nullable=True) # UPI Ref / Cheque No
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    business = relationship("Business", back_populates="payments")
    customer = relationship("Customer", back_populates="payments")
    sale = relationship("Sale", back_populates="payments")
