from sqlalchemy import Column, String, Numeric, Date, DateTime, ForeignKey, Text, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class Customer(Base):
    __tablename__ = "customers"

    id = Column(String(100), primary_key=True, index=True) # e.g. CUST-101
    business_id = Column(String(100), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False, index=True)
    phone = Column(String(50), nullable=True, index=True)
    email = Column(String(255), nullable=True)
    total_purchases = Column(Numeric(14, 2), default=0.0)
    amount_paid = Column(Numeric(14, 2), default=0.0)
    amount_due = Column(Numeric(14, 2), default=0.0)
    due_date = Column(Date, nullable=True)
    trust_score = Column(String(50), default="Good") # Good, Moderate, High Risk
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    business = relationship("Business", back_populates="customers")
    sales = relationship("Sale", back_populates="customer")
    payments = relationship("Payment", back_populates="customer")
