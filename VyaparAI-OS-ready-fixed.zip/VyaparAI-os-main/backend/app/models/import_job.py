from sqlalchemy import Column, String, Integer, DateTime, ForeignKey, Text, func
from sqlalchemy.orm import relationship
from app.db.base import Base

class ImportJob(Base):
    __tablename__ = "imports"

    id = Column(String(100), primary_key=True, index=True) # e.g. IMP-2026-001
    business_id = Column(String(100), ForeignKey("businesses.id", ondelete="CASCADE"), nullable=False, index=True)
    dataset_type = Column(String(50), nullable=False) # sales, inventory, customers
    file_name = Column(String(255), nullable=False)
    total_rows = Column(Integer, default=0)
    valid_rows = Column(Integer, default=0)
    invalid_rows = Column(Integer, default=0)
    status = Column(String(50), default="COMPLETED") # PROCESSING, COMPLETED, FAILED
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    business = relationship("Business", back_populates="imports")
    errors = relationship("ImportErrorRecord", back_populates="import_job", cascade="all, delete-orphan")

class ImportErrorRecord(Base):
    __tablename__ = "import_errors"

    id = Column(Integer, primary_key=True, autoincrement=True)
    import_id = Column(String(100), ForeignKey("imports.id", ondelete="CASCADE"), nullable=False, index=True)
    row_number = Column(Integer, nullable=False)
    field_name = Column(String(100), nullable=False)
    error_type = Column(String(100), nullable=False) # MISSING_REQUIRED, INVALID_NUMBER, etc.
    error_message = Column(Text, nullable=False)
    raw_value = Column(Text, nullable=True)

    # Relationships
    import_job = relationship("ImportJob", back_populates="errors")
