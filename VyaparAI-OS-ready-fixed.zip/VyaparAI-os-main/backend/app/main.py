from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.core.config import settings
from app.db.session import engine, SessionLocal
from app.db.base import Base
from app.models import (
    Business, 
    User, 
    Product, 
    Sale, 
    SaleItem, 
    Inventory, 
    Customer, 
    Payment, 
    ImportJob, 
    ImportErrorRecord
)
from app.api.v1.router import api_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("vyapar_ai")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure all database tables exist
    logger.info("Initializing database schemas...")
    Base.metadata.create_all(bind=engine)
    
    # Seed default SMB business if not present
    db = SessionLocal()
    try:
        from app.core.security import hash_password
        default_biz = db.query(Business).filter(Business.id == settings.DEFAULT_BUSINESS_ID).first()
        if not default_biz:
            default_biz = Business(
                id=settings.DEFAULT_BUSINESS_ID,
                name="Bharat Enterprises & Retail",
                owner="Rajesh Sharma",
                business_type="Supermart & Wholesale FMCG",
                gstin="07AAAAA0000A1Z5",
                upi_id="bharatenterprises@upi",
                location="Chandni Chowk, Delhi",
                currency="INR"
            )
            db.add(default_biz)
            db.commit()
            logger.info("Default SMB business seeded successfully.")

        # Seed default business owner user if not present
        demo_user = db.query(User).filter(User.email == "rajesh@bharat.com").first()
        if not demo_user:
            demo_user = User(
                id="USER-DEMO-001",
                business_id=settings.DEFAULT_BUSINESS_ID,
                full_name="Rajesh Sharma",
                email="rajesh@bharat.com",
                hashed_password=hash_password("admin123"),
                role="owner",
                is_active=True
            )
            db.add(demo_user)
            db.commit()
            logger.info("Default demo business owner seeded: rajesh@bharat.com / admin123")
    except Exception as e:
        logger.warning(f"Seeding check: {e}")
    finally:
        db.close()

    yield
    # Shutdown
    logger.info("Shutting down VyaparAI OS Backend.")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Enterprise REST APIs for VyaparAI OS — AI Operating System for Indian SMBs",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Router
app.include_router(api_router, prefix=settings.API_V1_STR)

@app.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "database": str(engine.url).split("://")[0]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
