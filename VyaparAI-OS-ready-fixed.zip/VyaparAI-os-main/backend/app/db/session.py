from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
import logging
from app.core.config import settings

logger = logging.getLogger("vyapar_ai.db")

def get_engine():
    """
    Initializes SQLAlchemy engine.
    Attempts primary PostgreSQL connection; if unreachable, falls back to SQLite.
    """
    if settings.DATABASE_URL and settings.DATABASE_URL.startswith("postgresql"):
        try:
            # Quick timeout check so local dev does not hang if Postgres is not running
            engine = create_engine(
                settings.DATABASE_URL,
                pool_pre_ping=True,
                connect_args={"connect_timeout": 2}
            )
            with engine.connect() as conn:
                logger.info("Connected successfully to PostgreSQL database.")
                return engine
        except Exception as e:
            logger.warning(f"PostgreSQL server not detected locally ({e}). Using local database: {settings.FALLBACK_SQLITE_URL}")

    # Fallback SQLite database
    return create_engine(
        settings.FALLBACK_SQLITE_URL,
        connect_args={"check_same_thread": False}
    )

engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """
    FastAPI dependency that yields a scoped database session per request.
    """
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()
