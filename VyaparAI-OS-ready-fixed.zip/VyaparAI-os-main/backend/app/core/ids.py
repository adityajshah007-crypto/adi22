"""Deterministic application identifiers.

Python's built-in hash() is randomized between interpreter processes, so it is
not suitable for persistent database IDs. This helper keeps generated IDs
stable across restarts and deployments.
"""

import hashlib


def stable_id(prefix: str, *parts: object, length: int = 10) -> str:
    value = "|".join(str(part or "").strip().lower() for part in parts)
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest().upper()
    return f"{prefix}-{digest[:length]}"
