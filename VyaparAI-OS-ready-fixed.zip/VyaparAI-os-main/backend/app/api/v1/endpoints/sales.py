from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.sale import Sale, SaleItem
from app.schemas.sale import SaleCreate, SaleOut
from app.core.ids import stable_id

router = APIRouter()

@router.get("/", response_model=List[SaleOut])
def list_sales(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(Sale).filter(Sale.business_id == tenant_id).order_by(Sale.sale_date.desc()).all()

@router.post("/", response_model=SaleOut, status_code=status.HTTP_201_CREATED)
def record_sale(
    sale_in: SaleCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    sale_id = stable_id('SALE', tenant_id, sale_in.invoice_id or sale_in.sale_date, length=10)
    
    db_sale = Sale(
        id=sale_id,
        business_id=tenant_id,
        customer_id=sale_in.customer_id,
        invoice_id=sale_in.invoice_id,
        sale_date=sale_in.sale_date,
        total_amount=sale_in.total_amount,
        total_cost=sale_in.total_cost,
        total_profit=sale_in.total_profit,
        payment_mode=sale_in.payment_mode,
        payment_status=sale_in.payment_status
    )
    db.add(db_sale)
    db.flush()

    for item in sale_in.items:
        item_id = stable_id('ITEM', sale_id, item.product_name, length=10)
        db_item = SaleItem(
            id=item_id,
            sale_id=sale_id,
            product_id=item.product_id,
            product_name=item.product_name,
            quantity=item.quantity,
            selling_price=item.selling_price,
            cost_price=item.cost_price,
            revenue=item.revenue or (item.quantity * item.selling_price),
            profit=item.profit or ((item.quantity * item.selling_price) - (item.quantity * item.cost_price))
        )
        db.add(db_item)

    db.commit()
    db.refresh(db_sale)
    return db_sale
