from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.product import Product
from app.schemas.product import ProductCreate, ProductOut

router = APIRouter()

@router.get("/", response_model=List[ProductOut])
def list_products(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(Product).filter(Product.business_id == tenant_id).all()

@router.post("/", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
def create_product(
    product_in: ProductCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    prod_id = stable_id('PROD', tenant_id, product_in.name, length=10)
    existing = db.query(Product).filter(Product.business_id == tenant_id, Product.id == prod_id).first()
    if existing:
        return existing

    db_prod = Product(
        id=prod_id,
        business_id=tenant_id,
        name=product_in.name,
        sku=product_in.sku,
        category=product_in.category,
        description=product_in.description
    )
    db.add(db_prod)
    db.commit()
    db.refresh(db_prod)
    return db_prod
