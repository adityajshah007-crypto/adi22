from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.models.business import Business
from app.schemas.business import BusinessCreate, BusinessOut
from app.core.security import get_current_active_user
from app.core.ids import stable_id

router = APIRouter()

@router.get("/", response_model=List[BusinessOut])
def list_businesses(db: Session = Depends(get_db), current_user = Depends(get_current_active_user)):
    return db.query(Business).all()

@router.post("/", response_model=BusinessOut, status_code=status.HTTP_201_CREATED)
def create_business(business_in: BusinessCreate, db: Session = Depends(get_db), current_user = Depends(get_current_active_user)):
    biz_id = business_in.id or stable_id('BIZ', business_in.name, length=10)
    existing = db.query(Business).filter(Business.id == biz_id).first()
    if existing:
        return existing

    db_biz = Business(
        id=biz_id,
        name=business_in.name,
        owner=business_in.owner,
        business_type=business_in.business_type,
        gstin=business_in.gstin,
        upi_id=business_in.upi_id,
        location=business_in.location,
        currency=business_in.currency
    )
    db.add(db_biz)
    db.commit()
    db.refresh(db_biz)
    return db_biz

@router.get("/{business_id}", response_model=BusinessOut)
def get_business(business_id: str, db: Session = Depends(get_db), current_user = Depends(get_current_active_user)):
    if business_id != current_user.business_id:
        raise HTTPException(status_code=403, detail="Business scope does not match the authenticated account.")
    biz = db.query(Business).filter(Business.id == business_id).first()
    if not biz:
        raise HTTPException(status_code=404, detail="Business not found")
    return biz
