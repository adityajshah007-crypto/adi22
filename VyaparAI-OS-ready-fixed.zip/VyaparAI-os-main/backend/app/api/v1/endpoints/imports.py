from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime, date
from decimal import Decimal
import uuid
from app.core.ids import stable_id

from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.business import Business
from app.models.product import Product
from app.models.customer import Customer
from app.models.sale import Sale, SaleItem
from app.models.inventory import Inventory
from app.models.import_job import ImportJob, ImportErrorRecord
from app.schemas.import_job import (
    ImportProcessRequest, 
    ImportProcessResponse, 
    ImportErrorDetail, 
    ImportJobOut
)

router = APIRouter()

@router.get("/history", response_model=List[ImportJobOut])
def get_import_history(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(ImportJob).filter(ImportJob.business_id == tenant_id).order_by(ImportJob.created_at.desc()).all()

@router.post("/process", response_model=ImportProcessResponse)
def process_data_import(
    payload: ImportProcessRequest,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    # Ensure tenant business exists or auto-create default
    biz = db.query(Business).filter(Business.id == tenant_id).first()
    if not biz:
        biz = Business(
            id=tenant_id,
            name="Bharat Enterprises & Retail",
            owner="Rajesh Sharma",
            business_type="Retail & Wholesale SMB",
            currency="INR"
        )
        db.add(biz)
        db.flush()

    job_id = f"IMP-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:4].upper()}"
    import_job = ImportJob(
        id=job_id,
        business_id=tenant_id,
        dataset_type=payload.dataset_type,
        file_name=payload.file_name,
        total_rows=len(payload.rows),
        valid_rows=0,
        invalid_rows=0,
        status="PROCESSING"
    )
    db.add(import_job)
    db.flush()

    valid_count = 0
    invalid_count = 0
    error_details: List[ImportErrorDetail] = []

    # =========================================================================
    # PROCESS SALES DATASET
    # =========================================================================
    if payload.dataset_type == "sales":
        for idx, row in enumerate(payload.rows):
            row_num = idx + 1
            row_errors = []

            # Server validation
            product_name = str(row.get("product") or "").strip()
            customer_name = str(row.get("customer") or "").strip()
            raw_date = row.get("date")
            raw_qty = row.get("quantity")
            raw_sp = row.get("sellingPrice")

            if not product_name:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Product", error_type="EMPTY_PRODUCT", error_message="Product name cannot be empty"))
            if not customer_name:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Customer", error_type="MISSING_REQUIRED", error_message="Customer name is required"))
            if not raw_date:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Date", error_type="MISSING_REQUIRED", error_message="Sale date is required"))

            try:
                qty = int(raw_qty) if raw_qty is not None else 1
                if qty <= 0:
                    row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Quantity", error_type="NUMBER_OUT_OF_RANGE", error_message="Quantity must be >= 1"))
            except (ValueError, TypeError):
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Quantity", error_type="INVALID_NUMBER", error_message="Quantity must be an integer"))
                qty = 1

            try:
                sp = Decimal(str(raw_sp)) if raw_sp is not None else Decimal("0.00")
                if sp < 0:
                    row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Selling Price", error_type="NUMBER_OUT_OF_RANGE", error_message="Price cannot be negative"))
            except Exception:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Selling Price", error_type="INVALID_NUMBER", error_message="Invalid selling price number"))
                sp = Decimal("0.00")

            if row_errors:
                invalid_count += 1
                error_details.extend(row_errors)
                for err in row_errors:
                    db_err = ImportErrorRecord(
                        import_id=job_id,
                        row_number=err.row_number,
                        field_name=err.field_name,
                        error_type=err.error_type,
                        error_message=err.error_message,
                        raw_value=str(row.get(err.field_name.lower()) or "")
                    )
                    db.add(db_err)
                continue

            # Row is valid -> Insert into Database models
            valid_count += 1
            
            # Upsert Product
            prod_id = stable_id('PROD', tenant_id, product_name, length=10)
            prod = db.query(Product).filter(Product.business_id == tenant_id, Product.id == prod_id).first()
            if not prod:
                prod = Product(
                    id=prod_id,
                    business_id=tenant_id,
                    name=product_name,
                    category=str(row.get("category") or "General")
                )
                db.add(prod)
                db.flush()

            # Upsert Customer
            cust_id = stable_id('CUST', tenant_id, customer_name, length=10)
            cust = db.query(Customer).filter(Customer.business_id == tenant_id, Customer.id == cust_id).first()
            if not cust:
                cust = Customer(
                    id=cust_id,
                    business_id=tenant_id,
                    name=customer_name
                )
                db.add(cust)
                db.flush()

            # Parse date
            try:
                parsed_date = datetime.strptime(str(raw_date)[:10], "%Y-%m-%d").date()
            except Exception:
                parsed_date = date.today()

            revenue = Decimal(str(row.get("revenue") or (qty * sp)))
            cost = Decimal(str(row.get("cost") or (revenue * Decimal("0.75"))))
            profit = Decimal(str(row.get("profit") or (revenue - cost)))

            invoice_id = str(row.get("invoiceId") or f"INV-{job_id[-4:]}-{row_num}")
            sale_id = stable_id('SALE', tenant_id, invoice_id, row_num, length=10)

            sale = Sale(
                id=sale_id,
                business_id=tenant_id,
                customer_id=cust.id,
                invoice_id=invoice_id,
                sale_date=parsed_date,
                total_amount=revenue,
                total_cost=cost,
                total_profit=profit,
                payment_mode="UPI",
                payment_status="Paid"
            )
            db.add(sale)
            db.flush()

            sale_item = SaleItem(
                id=stable_id('ITEM', sale_id, prod.id, row_num, length=10),
                sale_id=sale_id,
                product_id=prod.id,
                product_name=prod.name,
                quantity=qty,
                selling_price=sp,
                cost_price=cost / qty if qty > 0 else Decimal("0.00"),
                revenue=revenue,
                profit=profit
            )
            db.add(sale_item)

    # =========================================================================
    # PROCESS INVENTORY DATASET
    # =========================================================================
    elif payload.dataset_type == "inventory":
        for idx, row in enumerate(payload.rows):
            row_num = idx + 1
            row_errors = []

            product_name = str(row.get("product") or "").strip()
            raw_stock = row.get("currentStock")
            raw_cp = row.get("costPrice")
            raw_sp = row.get("sellingPrice")

            if not product_name:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Product", error_type="EMPTY_PRODUCT", error_message="Product name cannot be empty"))

            try:
                stock = int(raw_stock) if raw_stock is not None else 0
                if stock < 0:
                    row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Current Stock", error_type="NUMBER_OUT_OF_RANGE", error_message="Stock cannot be negative"))
            except Exception:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Current Stock", error_type="INVALID_NUMBER", error_message="Invalid stock number"))
                stock = 0

            try:
                cp = Decimal(str(raw_cp)) if raw_cp is not None else Decimal("0.00")
            except Exception:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Cost Price", error_type="INVALID_NUMBER", error_message="Invalid cost price"))
                cp = Decimal("0.00")

            try:
                sp = Decimal(str(raw_sp)) if raw_sp is not None else Decimal("0.00")
            except Exception:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Selling Price", error_type="INVALID_NUMBER", error_message="Invalid selling price"))
                sp = Decimal("0.00")

            if row_errors:
                invalid_count += 1
                error_details.extend(row_errors)
                for err in row_errors:
                    db_err = ImportErrorRecord(
                        import_id=job_id,
                        row_number=err.row_number,
                        field_name=err.field_name,
                        error_type=err.error_type,
                        error_message=err.error_message,
                        raw_value=str(row.get(err.field_name.lower()) or "")
                    )
                    db.add(db_err)
                continue

            valid_count += 1
            prod_id = stable_id('PROD', tenant_id, product_name, length=10)
            prod = db.query(Product).filter(Product.business_id == tenant_id, Product.id == prod_id).first()
            if not prod:
                prod = Product(
                    id=prod_id,
                    business_id=tenant_id,
                    name=product_name,
                    sku=str(row.get("sku") or f"SKU-{row_num}"),
                    category=str(row.get("category") or "General Store")
                )
                db.add(prod)
                db.flush()

            # Upsert Inventory
            inv = db.query(Inventory).filter(Inventory.business_id == tenant_id, Inventory.product_id == prod.id).first()
            if inv:
                inv.current_stock = stock
                inv.cost_price = cp
                inv.selling_price = sp
                inv.reorder_level = int(row.get("reorderLevel") or 10)
                inv.supplier_name = str(row.get("supplier") or "Primary Distributor")
            else:
                inv = Inventory(
                    id=stable_id('INV', tenant_id, prod.id, length=10),
                    business_id=tenant_id,
                    product_id=prod.id,
                    current_stock=stock,
                    cost_price=cp,
                    selling_price=sp,
                    reorder_level=int(row.get("reorderLevel") or 10),
                    supplier_name=str(row.get("supplier") or "Primary Distributor")
                )
                db.add(inv)

    # =========================================================================
    # PROCESS CUSTOMERS DATASET
    # =========================================================================
    elif payload.dataset_type == "customers":
        for idx, row in enumerate(payload.rows):
            row_num = idx + 1
            row_errors = []

            customer_name = str(row.get("customerName") or "").strip()
            if not customer_name:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Customer Name", error_type="MISSING_REQUIRED", error_message="Customer name cannot be empty"))

            try:
                due = Decimal(str(row.get("amountDue") or "0.00"))
            except Exception:
                row_errors.append(ImportErrorDetail(row_number=row_num, field_name="Amount Due", error_type="INVALID_NUMBER", error_message="Invalid amount due number"))
                due = Decimal("0.00")

            if row_errors:
                invalid_count += 1
                error_details.extend(row_errors)
                continue

            valid_count += 1
            cust_id = stable_id('CUST', tenant_id, customer_name, length=10)
            cust = db.query(Customer).filter(Customer.business_id == tenant_id, Customer.id == cust_id).first()
            if cust:
                cust.phone = str(row.get("phone") or cust.phone)
                cust.email = str(row.get("email") or cust.email)
                cust.amount_due = due
                cust.total_purchases = Decimal(str(row.get("totalPurchases") or cust.total_purchases))
                cust.amount_paid = Decimal(str(row.get("amountPaid") or cust.amount_paid))
            else:
                cust = Customer(
                    id=cust_id,
                    business_id=tenant_id,
                    name=customer_name,
                    phone=str(row.get("phone") or "+91 98000 00000"),
                    email=str(row.get("email") or ""),
                    total_purchases=Decimal(str(row.get("totalPurchases") or "0.00")),
                    amount_paid=Decimal(str(row.get("amountPaid") or "0.00")),
                    amount_due=due,
                    trust_score="Good"
                )
                db.add(cust)

    # Update job stats
    import_job.valid_rows = valid_count
    import_job.invalid_rows = invalid_count
    import_job.status = "COMPLETED" if invalid_count == 0 else ("PARTIAL" if valid_count > 0 else "FAILED")

    db.commit()

    return ImportProcessResponse(
        job_id=job_id,
        business_id=tenant_id,
        dataset_type=payload.dataset_type,
        file_name=payload.file_name,
        total_rows=len(payload.rows),
        valid_rows=valid_count,
        invalid_rows=invalid_count,
        status=import_job.status,
        errors=error_details,
        message=f"Import completed with {valid_count} valid records stored in PostgreSQL database."
    )
