from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.customer import Customer
from app.schemas.customer import CustomerCreate, CustomerOut

router = APIRouter()

@router.get("/", response_model=List[CustomerOut])
def list_customers(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(Customer).filter(Customer.business_id == tenant_id).all()

@router.post("/", response_model=CustomerOut, status_code=status.HTTP_201_CREATED)
def create_customer(
    customer_in: CustomerCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    cust_id = stable_id('CUST', tenant_id, customer_in.name, length=10)
    existing = db.query(Customer).filter(Customer.business_id == tenant_id, Customer.id == cust_id).first()
    if existing:
        return existing

    db_cust = Customer(
        id=cust_id,
        business_id=tenant_id,
        name=customer_in.name,
        phone=customer_in.phone,
        email=customer_in.email,
        total_purchases=customer_in.total_purchases,
        amount_paid=customer_in.amount_paid,
        amount_due=customer_in.amount_due,
        due_date=customer_in.due_date,
        trust_score=customer_in.trust_score,
        notes=customer_in.notes
    )
    db.add(db_cust)
    db.commit()
    db.refresh(db_cust)
    return db_cust
