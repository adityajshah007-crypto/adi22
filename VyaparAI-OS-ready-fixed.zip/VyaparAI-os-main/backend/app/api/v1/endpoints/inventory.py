from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.inventory import Inventory
from app.schemas.inventory import InventoryCreate, InventoryOut
from app.core.ids import stable_id

router = APIRouter()

@router.get("/", response_model=List[InventoryOut])
def list_inventory(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(Inventory).filter(Inventory.business_id == tenant_id).all()

@router.post("/", response_model=InventoryOut, status_code=status.HTTP_201_CREATED)
def update_or_create_inventory(
    inv_in: InventoryCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    existing = db.query(Inventory).filter(
        Inventory.business_id == tenant_id,
        Inventory.product_id == inv_in.product_id
    ).first()

    if existing:
        existing.current_stock = inv_in.current_stock
        existing.reorder_level = inv_in.reorder_level
        existing.cost_price = inv_in.cost_price
        existing.selling_price = inv_in.selling_price
        existing.supplier_name = inv_in.supplier_name
        existing.lead_time_days = inv_in.lead_time_days
        db.commit()
        db.refresh(existing)
        return existing

    inv_id = stable_id('INV', tenant_id, inv_in.product_id, length=10)
    db_inv = Inventory(
        id=inv_id,
        business_id=tenant_id,
        product_id=inv_in.product_id,
        current_stock=inv_in.current_stock,
        reorder_level=inv_in.reorder_level,
        cost_price=inv_in.cost_price,
        selling_price=inv_in.selling_price,
        supplier_name=inv_in.supplier_name,
        lead_time_days=inv_in.lead_time_days
    )
    db.add(db_inv)
    db.commit()
    db.refresh(db_inv)
    return db_inv
