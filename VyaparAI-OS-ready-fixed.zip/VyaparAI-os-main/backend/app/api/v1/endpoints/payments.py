from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.payment import Payment
from app.schemas.payment import PaymentCreate, PaymentOut
from app.core.ids import stable_id

router = APIRouter()

@router.get("/", response_model=List[PaymentOut])
def list_payments(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(Payment).filter(Payment.business_id == tenant_id).order_by(Payment.payment_date.desc()).all()

@router.post("/", response_model=PaymentOut, status_code=status.HTTP_201_CREATED)
def record_payment(
    payment_in: PaymentCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    pay_id = stable_id('PAY', tenant_id, payment_in.payment_date, payment_in.amount, length=10)
    db_payment = Payment(
        id=pay_id,
        business_id=tenant_id,
        customer_id=payment_in.customer_id,
        sale_id=payment_in.sale_id,
        amount=payment_in.amount,
        payment_date=payment_in.payment_date,
        payment_mode=payment_in.payment_mode,
        reference_number=payment_in.reference_number
    )
    db.add(db_payment)
    db.commit()
    db.refresh(db_payment)
    return db_payment
