import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.session import get_db
from app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_active_user
)
from app.models.user import User
from app.models.business import Business
from app.schemas.auth import LoginRequest, RegisterRequest, TokenResponse, AuthMeResponse

router = APIRouter()

@router.post("/login", response_model=TokenResponse)
def login(login_data: LoginRequest, db: Session = Depends(get_db)):
    """
    Authenticate business owner/user with email and password.
    Returns JWT access token with business profile.
    """
    email_clean = login_data.email.lower().strip()
    user = db.query(User).filter(func.lower(User.email) == email_clean).first()
    
    if not user or not verify_password(login_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive. Please contact support."
        )
        
    business = db.query(Business).filter(Business.id == user.business_id).first()
    if not business:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Associated business not found for this user."
        )
        
    access_token = create_access_token(
        subject=user.id,
        extra_claims={
            "email": user.email,
            "business_id": user.business_id,
            "business_name": business.name,
            "role": user.role
        }
    )
    
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=user,
        business=business
    )

@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register(register_data: RegisterRequest, db: Session = Depends(get_db)):
    """
    Register a new business owner and automatically provision their business profile.
    Returns JWT access token and logged-in business workspace details.
    """
    email_clean = register_data.email.lower().strip()
    
    # Check if user already exists
    existing_user = db.query(User).filter(func.lower(User.email) == email_clean).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists. Please sign in instead."
        )
        
    # Generate unique IDs
    biz_id = f"BIZ-{uuid.uuid4().hex[:8].upper()}"
    user_id = f"USR-{uuid.uuid4().hex[:8].upper()}"
    
    # 1. Create Business
    new_business = Business(
        id=biz_id,
        name=register_data.business_name.strip(),
        owner=register_data.full_name.strip(),
        business_type=register_data.business_type or "Retail & Wholesale SMB",
        gstin=register_data.gstin.strip().upper() if register_data.gstin else None,
        upi_id=register_data.upi_id.strip() if register_data.upi_id else None,
        location=register_data.location.strip() if register_data.location else "India",
        currency=register_data.currency or "INR"
    )
    db.add(new_business)
    db.flush()
    
    # 2. Create Owner User
    hashed_pwd = hash_password(register_data.password)
    new_user = User(
        id=user_id,
        business_id=biz_id,
        full_name=register_data.full_name.strip(),
        email=email_clean,
        hashed_password=hashed_pwd,
        role="owner",
        is_active=True
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_business)
    db.refresh(new_user)
    
    # 3. Generate token
    access_token = create_access_token(
        subject=new_user.id,
        extra_claims={
            "email": new_user.email,
            "business_id": new_business.id,
            "business_name": new_business.name,
            "role": new_user.role
        }
    )
    
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=new_user,
        business=new_business
    )

@router.get("/me", response_model=AuthMeResponse)
def get_current_authenticated_profile(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Get profile information for the currently authenticated user and business.
    """
    business = db.query(Business).filter(Business.id == current_user.business_id).first()
    if not business:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Business profile not found"
        )
    return AuthMeResponse(user=current_user, business=business)
