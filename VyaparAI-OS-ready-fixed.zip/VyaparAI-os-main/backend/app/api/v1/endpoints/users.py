from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.core.security import get_tenant_id
from app.models.user import User
from app.schemas.user import UserCreate, UserOut
from app.core.ids import stable_id
from app.core.security import hash_password

router = APIRouter()

@router.get("/", response_model=List[UserOut])
def list_users(
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return db.query(User).filter(User.business_id == tenant_id).all()

@router.post("/", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    user_in: UserCreate,
    db: Session = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    user_id = stable_id('USER', tenant_id, user_in.email, length=10)
    existing = db.query(User).filter(User.business_id == tenant_id, User.email == user_in.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="User email already exists for this business")

    db_user = User(
        id=user_id,
        business_id=tenant_id,
        full_name=user_in.full_name,
        email=user_in.email,
        hashed_password=hash_password(user_in.password),
        role=user_in.role
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user
