from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth,
    businesses,
    users,
    products,
    sales,
    inventory,
    customers,
    payments,
    imports
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])

api_router.include_router(businesses.router, prefix="/businesses", tags=["Businesses"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(products.router, prefix="/products", tags=["Products"])
api_router.include_router(sales.router, prefix="/sales", tags=["Sales"])
api_router.include_router(inventory.router, prefix="/inventory", tags=["Inventory"])
api_router.include_router(customers.router, prefix="/customers", tags=["Customers"])
api_router.include_router(payments.router, prefix="/payments", tags=["Payments"])
api_router.include_router(imports.router, prefix="/imports", tags=["Data Imports"])
