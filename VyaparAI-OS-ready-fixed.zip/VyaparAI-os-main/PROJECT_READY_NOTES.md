# VyaparAI OS — Project Ready Notes

## Completed

1. Fixed the frontend `API_BASE_URL` runtime bug.
2. Centralized API requests and backend error handling.
3. Removed hard-coded localhost API URLs from normal requests.
4. Added environment examples for frontend and backend.
5. Added Windows and Unix startup helpers.
6. Fixed inventory import merging so duplicate SKU/product rows are not duplicated.
7. Replaced Python process-random `hash()` identifiers with deterministic SHA-256 identifiers.
8. Enforced authenticated tenant scope for business data APIs.
9. Prevented `X-Business-ID` from switching an authenticated user into another business.
10. Replaced the user-creation placeholder password hash with bcrypt hashing.
11. Kept import functionality usable when the backend is offline by falling back to the browser DataStore.
12. Removed misleading fixed KPI growth percentages and marked dashboard values as live.
13. Updated the README with setup, environment, security and deployment guidance.

## Validation performed

- Python backend source successfully passed `python -m compileall -q backend/app`.
- Static search confirms the old undefined `API_BASE_URL` usage is gone.
- Static search confirms the old process-random `abs(hash(...))` ID generation is gone.

## Environment limitation during this build

The execution environment had no network access, so npm packages and the missing Python `bcrypt` package could not be downloaded here. Run `npm install` and `pip install -r backend/requirements.txt` on a normal development machine before starting the project.
